#!/bin/bash
initialized=/root/.dbsinit

config=/etc/info.dbs
aws_cli='/usr/local/bin/aws'
AWS_USER='ec2-user'
AWS_GROUP='ec2-user'

# copy user data to file
if [ -f /root/config ]; then
        cat /root/config > $config
else
        curl http://169.254.169.254/latest/user-data > $config
fi
echo >> $config

logger "[PWEB: Bootstrap] Stop puppet before performing the bootstrap steps"
/opt/puppetlabs/bin/puppet resource service puppet ensure=stopped enable=false

echo "[PWEB: Bootstrap] copying metadata to /etc/info.dbs"

DOMAIN=`grep "^DOMAIN=" $config | awk -F"=" '{print $2}'`
HOSTNAMEPREFIX=`grep "^HOSTNAMEPREFIX=" $config | awk -F"=" '{print $2}'`
HOSTED_ZONE_ID=`grep "^HOSTED_ZONE_ID=" $config | awk -F"=" '{print $2}'`

logger "[PWEB: Bootstrap] Bootstraping pweb instance Domain: $DOMAIN hostnameprefix: $HOSTNAMEPREFIX hostedzoneid: $HOSTED_ZONE_ID"

# Collection of instance details
REGION=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document|grep region|awk -F\" '{print $4}')
INSTANCE_ID=`/usr/bin/curl -s http://169.254.169.254/latest/meta-data/instance-id`
PRIVATEIP=`/usr/bin/curl http://169.254.169.254/latest/meta-data/local-ipv4`
INSTANCE_NAME=$($aws_cli ec2 describe-instances --instance-id $INSTANCE_ID --region $REGION --query 'Reservations[].Instances[].Tags[?Key==`Name`].Value[]' --output text)

logger "[PWEB: Bootstrap] Instance Details: Region - $REGION Instance Id - $INSTANCE_ID Private Ip - $PRIVATEIP"

# Collection of AutoScale details
AGNAME=$($aws_cli autoscaling describe-auto-scaling-instances --instance-ids $INSTANCE_ID --region $REGION --query AutoScalingInstances[].AutoScalingGroupName --output text)
INSTANCES=$($aws_cli autoscaling describe-auto-scaling-groups --region $REGION --auto-scaling-group-name ${AGNAME} --query AutoScalingGroups[].Instances[].InstanceId --output text)
INSTANCEHOSTNAMES=$($aws_cli ec2 describe-instances --instance-ids $INSTANCES --region $REGION --query 'Reservations[].Instances[].Tags[?Key==`Name`].Value[]' --output text)
hosts=($INSTANCEHOSTNAMES)
MAXINSTANCE=$($aws_cli autoscaling describe-auto-scaling-groups --region $REGION --auto-scaling-group-name ${AGNAME}  --query AutoScalingGroups[].MaxSize  --output text)

logger "[PWEB: Bootstrap] AutoScale Details: AutoScaleGroupName - $AGNAME Instances - $INSTANCES Instance Host Names - $INSTANCEHOSTNAMES"

# remove the hostname without domain prefix and sort the element
temphosts=()
for host in ${hosts[@]}; do
   echo "[PWEB: Bootstrap] checking if $host contains $DOMAIN"
   if [[ $host == *"$DOMAIN"* ]]; then
     echo "[PWEB: Bootstrap] $host contains $DOMAIN hence adding to the temphosts list"
     temphosts+=("$host")
   fi
done
IFS=$'\n' sanitizedhosts=($(sort <<<"${temphosts[*]}"))
unset IFS
echo "[PWEB: Bootstrap] sanitized and sorted host list: ${sanitizedhosts[@]}"

# generating current instances hostname.
hostname=$INSTANCE_NAME
i=0
while [ "$i" -lt "$MAXINSTANCE" ]; do
    let num=i+1
    num=`printf "%02d" $num`
    newhostname=$HOSTNAMEPREFIX$num
    fqdn="$newhostname.$DOMAIN"
    logger "[PWEB: Bootstrap] checking if $fqdn equal to ${sanitizedhosts[i]}, in loop $i"
    if [ "$MAXINSTANCE" -eq 1 ]; then
       logger "[PWEB: Bootstrap] MaxInstance is 1, hence setting hostname to $fqdn"
       hostname=$fqdn
       break
    elif [ "${sanitizedhosts[i]}" != "$fqdn" ]; then
        # set hostname and break
        logger "[PWEB: Bootstrap] $fqdn NOT equal to ${sanitizedhosts[i]}, hence setting hostname as $fqdn"
        hostname=$fqdn
        break
    fi
    let i+=1
done

# set hostname as "Name" tag
logger "[PWEB: Bootstrap] changing Name tag of EC2"
$aws_cli ec2 create-tags --region=$REGION --resources=$INSTANCE_ID --tags Key=Name,Value=$hostname

#add tags to volumes
volumes_attached=$($aws_cli ec2 describe-volumes --region $REGION --filters --filters Name=attachment.instance-id,Values=$INSTANCE_ID --query 'Volumes[*].{ID:VolumeId}' --output text)
APPCODE=$($aws_cli ec2 describe-instances --instance-ids $INSTANCE_ID --region $REGION --query 'Reservations[].Instances[].Tags[?Key==`App-code`].Value[]' --output text)
PCCODE=$($aws_cli ec2 describe-instances --instance-ids $INSTANCE_ID --region $REGION --query 'Reservations[].Instances[].Tags[?Key==`PC-code`].Value[]' --output text)
for i in ${volumes_attached};
do
   $aws_cli ec2 create-tags --region $REGION --resources $i --tags Key=App-code,Value=$APPCODE  Key=PC-code,Value=$PCCODE  Key=Name,Value=$hostname
done

sleep 3

# change hostname
logger "Setting hostname: $hostname"
if [ "$hostname" != "" ]; then
    echo "$hostname" > /etc/hostname
    ip=`ifconfig eth0 | head -2 | tail -1 | awk '{print $2}'`
    grep "^HOSTNAME=$hostname" /etc/sysconfig/network > /dev/null
    if [ $? -eq 1 ]; then
            echo "HOSTNAME=$hostname" >> /etc/sysconfig/network
    fi
    if [ -f /etc/cloud/cloud.cfg ]; then
            grep "^preserve_hostname: true" /etc/cloud/cloud.cfg > /dev/null
            if [ $? -eq 1 ]; then
                    echo "preserve_hostname: true" >> /etc/cloud/cloud.cfg
            fi
    fi
    /bin/hostnamectl set-hostname $hostname
    /bin/hostname $hostname
    rm /var/log/.route53.log
fi

# /etc/hosts change
logger "[PWEB: Bootstrap] Changing hostname in /etc/hosts with entry \"$PRIVATEIP $hostname\""
grep -v "$hostname" /etc/hosts > /tmp/tmp.$$
mv /tmp/tmp.$$ /etc/hosts
echo "$PRIVATEIP $hostname" >> /etc/hosts

sleep 3

# cleanup CloudWatch cache
logger "[PWEB: Bootstrap] cleanup CloudWatch cache"
rm -rf /var/tmp/aws-mon

sleep 3

# Registring Route 53
logger "[PWEB: Bootstrap] changing route 53 entry"
RECORDSET=$hostname.
TTL=300
COMMENT="Update R53 for Deployment Server"
TYPE="A"
TMPFILE=$(mktemp /tmp/temporary-ip.XXXXXX)
cat > ${TMPFILE} << EOF
{
    "Comment": "$COMMENT",
    "Changes": [{
        "Action": "UPSERT",
        "ResourceRecordSet": {
            "ResourceRecords": [{
                "Value": "$PRIVATEIP"
            }],
            "Name": "$RECORDSET",
            "Type": "$TYPE",
            "TTL": $TTL
        }
    }]
}
EOF
$aws_cli route53 change-resource-record-sets --hosted-zone-id $HOSTED_ZONE_ID --change-batch file://"$TMPFILE"
rm -rf $TMPFILE

sleep 3

# Tectia server reconfig
if [ -e /etc/ssh2/ssh-server-config.xml ]; then
    logger "[PWEB: Bootstrap] changing ssh config entry"
    oldIP=`grep "listener id=\"port61022\"" /etc/ssh2/ssh-server-config.xml | cut -d"=" -f4 | cut -d"\"" -f2`
    PRIVATEIP=`curl http://169.254.169.254/latest/meta-data/local-ipv4`
    sed -i -e "s/$oldIP/$PRIVATEIP/g" /etc/ssh2/ssh-server-config.xml
    chkconfig ssh-server-g3 on
    /etc/init.d/ssh-server-g3 restart
fi

sleep 2 

# Injecting Ec2 ssh key
logger "[PWEB: Bootstrap] Injecting Ec2 key"
mkdir /home/$AWS_USER/.ssh
chown $AWS_USER.$AWS_GROUP /home/$AWS_USER/.ssh
chmod 700 /home/$AWS_USER/.ssh
rm -f /home/$AWS_USER/.ssh/authorized_keys
curl http://169.254.169.254/latest/meta-data/public-keys/0/openssh-key -o /home/$AWS_USER/.ssh/authorized_keys
chmod 600 /home/$AWS_USER/.ssh/authorized_keys
chown $AWS_USER.$AWS_GROUP /home/$AWS_USER/.ssh/authorized_keys
curl http://repo/aws/common/$AWS_USER.sudo -o /etc/sudoers.d/90-$AWS_USER
chmod 440 /etc/sudoers.d/90-$AWS_USER
chmod 640 /etc/sudoers
grep "^#includedir /etc/sudoers.d" /etc/sudoers > /dev/null
if [ $? -eq 1 ]; then
    echo "## Read drop-in files from /etc/sudoers.d (the \# here does not mean a comment)" >> /etc/sudoers
    echo "#includedir /etc/sudoers.d" >> /etc/sudoers
fi
chmod 440 /etc/sudoers


# changing the jmxtrans config to include the new hostname
logger "[PWEB: Bootstrap] Jmxtrans config"
ls /var/lib/jmxtrans/*.json
if [ $? -eq 0 ]; then
  jmxjsonlist=(`ls /var/lib/jmxtrans/*.json`)
  for file in ${jmxjsonlist[@]}; do
    echo "[PWEB: Bootstrap] changing hostname in jmxtrans file: $file"
    sed -i "s/.*\"host\".*/\"host\":\"$hostname\",/" $file
  done
fi

# cleanup ITM software and let puppet install it again
logger "[PWEB: Bootstrap] Cleaning up of IBM ITM"
/opt/IBM/ITM/bin/itmcmd agent stop all
/opt/IBM/ITM/bin/uninstall.sh REMOVE EVERYTHING
[ -d /opt/IBM/ITM ] && rm -rf /opt/IBM/ITM
rm -f /var/log/.itm_install.log

# changes for iscd and eocl compliance
chown -R root:root /usr/share/jmxtrans
chown root:root /usr/share/jmxtrans/bin/jmxtrans
chown root:root /usr/bin/yaml2jmxtrans
chown root:mail /var/spool/mail
chown puppet:puppet /var/lib/puppet/ssl
chown -R root:root /var/awslogs
chmod -R 750 /opt/puppetlabs/puppet/cache/clientbucket
chmod 444 /etc/hosts
chown -R root:root /opt/tivoli/cit/bin
chmod -R 755 /opt/tivoli/cit/bin
chmod 755 /opt/tivoli/cit/cache_data
chmod 755 /var/tmp/contentdeploy

## Puppet master cert cleanup 
logger "[PWEB: Bootstrap] Cleaning up puppet master certs for hostname $hostname"
curl --connect-timeout 60 --max-time 30  http://repo/bin/postcleanup_pweb.sh?$hostname
logger "[PWEB: Bootstrap] waiting 10sec for puppet master cert cleanup"
sleep 10

# puppet client cert removal
logger "[PWEB: Bootstrap] Removal of old client cert and stopping puppet"
crontab -l | grep -v watchdog.sh | grep -v mon-put-instance-data.sh | grep -v "^# Puppet" | crontab -
/opt/puppetlabs/bin/puppet resource service puppet ensure=stopped enable=false
crontab -l | grep -v watchdog.sh | grep -v mon-put-instance-data.sh | grep -v "^# Puppet" | crontab -
rm -rf /etc/puppetlabs/puppet/ssl
rm -f /opt/puppetlabs/puppet/cache/client_data/catalog/*.json

# invoke Puppet agent
logger "[PWEB: Bootstrap] starting puppet"
nopuppet=false
puppetconf="/etc/puppetlabs/puppet/puppet.conf"
env=`echo "$DOMAIN" | sed "s/\./_/g"`
echo -e "[agent]\nserver=puppet\nenvironment=$env" > $puppetconf
chmod 644 $puppetconf
chown root.root $puppetconf
if [ "$nopuppet" = "false" ]; then
    /opt/puppetlabs/bin/puppet resource service puppet ensure=running enable=true
fi

logger "[PWEB: Bootstrap] Initalization completed"
touch $initialized
