#!/bin/bash

# Initialize variables
KEYFILE=/var/lib/awx/.ssh2/pweb-admin-brian.pem
AWS_BINARYBUCKET=s3://dbs-pweb-binaries/cf-templates/pweb-stack/
ENVIRONMENTNAME=spweb01
INVENTORY=staging_spweb01
EXTRAVARS=$2

#Select the stack
stack_security=true
stack_awsbase=true
stack_anas=true
stack_ets=true
stack_alsds=true
stack_elsds=true
stack_adps=true
stack_edps=true
stack_alscs=true
stack_elscs=true


export AWS_ACCESS_KEY_ID='AKIAJUCUIELRVPPZEUEA'
export AWS_SECRET_ACCESS_KEY='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'

export ANSIBLE_HOSTS=./inventory/$INVENTORY/ec2.py
export EC2_INI_PATH=./inventory/$INVENTORY/ec2.ini

# Extract all files in dbs_ansible to ansible project location.
echo "Copying all cloudformation templates to : $AWS_BINARYBUCKET"
/usr/local/bin/aws s3 sync ./pweb-stack/ $AWS_BINARYBUCKET --delete

#Change permission for dynamic inventory file
chmod 775 ./inventory/$INVENTORY/ec2.py
chmod 775 ./inventory/$INVENTORY/ec2.ini

echo " Running Playbooks"
#ansible-playbook --private-key=$KEYFILE -i inventory/$INVENTORY pweb-provision.yml --extra-vars \"environmentname=$ENVIRONMENTNAME $EXTRAVARS\" --flush-cache

# --- examples ---
# ansible-playbook -i inventory/$INVENTORY pweb-delete-stack.yml --extra-vars "environmentname=spweb01 pweb_security_groups=true"
#ansible-playbook -i inventory/$INVENTORY pweb-delete-stack.yml --extra-vars "environmentname=spweb01 pweb_lsdssg_stack=pweb-lsdssg-spweb01 pweb_prvlsdssg_stack=pweb-prvlsdssg-spweb01 pweb_dps_stack=pweb-dps-spweb01 pweb_lscs_stack=pweb-lscs-spweb01 pweb_ts_stack=pweb-ts-spweb01 pweb_prvdps_stack=pweb-prvdps-spweb01 pweb_prvlscs_stack=pweb-prvlscs-spweb01"

#ansible-playbook -i inventory/$INVENTORY pweb-delete-stack.yml --extra-vars "environmentname=spweb01 pweb_nas_stack=pweb-nas-spweb01 pweb_base_stack=pweb-base-spweb01"

ansible-playbook --private-key=$KEYFILE -i inventory/$INVENTORY pweb-provision.yml --extra-vars "environmentname=spweb01 pweb_use_ami=golden stack_ets=$stack_ets stack_alsds=$stack_alsds stack_elsds=$stack_elsds stack_adps=$stack_adps stack_edps=$stack_edps stack_alscs=$stack_alscs stack_elscs=$stack_elscs stack_security=$stack_security stack_awsbase=$stack_awsbase stack_anas=$stack_anas ansible_ssh_user=ec2-user" --flush-cache

#ansible-playbook --private-key=$KEYFILE -i inventory/$INVENTORY pweb-install.yml --extra-vars "environmentname=spweb01 pweb_use_ami=golden ansible_ssh_user=ec2-user" --flush-cache

#ansible-playbook --private-key=$KEYFILE -i inventory/$INVENTORY pweb-config.yml --extra-vars "environmentname=spweb01 stack_ets=$stack_ets stack_alsds=$stack_alsds stack_elsds=$stack_elsds stack_adps=$stack_adps stack_edps=$stack_edps stack_alscs=$stack_alscs stack_elscs=$stack_elscs ansible_ssh_user=ec2-user" --flush-cache
