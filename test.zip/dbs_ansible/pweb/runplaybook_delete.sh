#!/bin/bash

# Initialize variables
KEYFILE=/var/lib/awx/.ssh2/pweb-admin-brian.pem
AWS_BINARYBUCKET=s3://dbs-pweb-binaries/cf-templates/pweb-stack/
ENVIRONMENTNAME=spweb02
INVENTORY=staging_spweb02
EXTRAVARS=$2

# Location of log file
timestamp=$(date +%s)
LOG_FILE=/var/lib/awx/projects/pweb_log/pweb_delete_$ENVIRONMENTNAME-$timestamp.log
exec > >(tee -i $LOG_FILE) 2>&1
set -x

#Select the stack
stack_security=false
stack_awsbase=false
stack_anas=true
stack_ets=false
stack_alsds=false
stack_elsds=false
stack_adps=false
stack_edps=false
stack_alscs=false
stack_elscs=false


export AWS_ACCESS_KEY_ID='AKIAJUCUIELRVPPZEUEA'
export AWS_SECRET_ACCESS_KEY='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'

export ANSIBLE_HOSTS=./inventory/$INVENTORY/ec2.py
export EC2_INI_PATH=./inventory/$INVENTORY/ec2.ini

# Extract all files in dbs_ansible to ansible project location.
echo "Copying all cloudformation templates to : $AWS_BINARYBUCKET"
/usr/local/bin/aws s3 sync ./pweb-stack/ $AWS_BINARYBUCKET --delete

#Change permission for dynamic inventory file
chmod 775 ./inventory/$INVENTORY/ec2.py
chmod 775 ./inventory/$INVENTORY/ec2.ini

echo " Running Playbooks for delete"

#ansible-playbook -i inventory/$INVENTORY pweb-delete-stack.yml --extra-vars "environmentname=$ENVIRONMENTNAME pweb_lsdssg_stack=pweb-lsdssg-$ENVIRONMENTNAME pweb_prvlsdssg_stack=pweb-prvlsdssg-$ENVIRONMENTNAME pweb_dps_stack=pweb-dps-$ENVIRONMENTNAME pweb_lscs_stack=pweb-lscs-$ENVIRONMENTNAME pweb_ts_stack=pweb-ts-$ENVIRONMENTNAME pweb_prvdps_stack=pweb-prvdps-$ENVIRONMENTNAME pweb_prvlscs_stack=pweb-prvlscs-$ENVIRONMENTNAME"

#ansible-playbook -i inventory/$INVENTORY pweb-delete-stack.yml --extra-vars "environmentname=$ENVIRONMENTNAME use_env=$ENVIRONMENTNAME pweb_nas_stack=pweb-nas-$ENVIRONMENTNAME pweb_security_groups=false"

# ansible-playbook -i inventory/$INVENTORY pweb-delete-stack.yml --extra-vars "environmentname=$ENVIRONMENTNAME pweb_security_groups=true"
#ansible-playbook -i inventory/$INVENTORY pweb-delete-stack.yml --extra-vars "environmentname=$ENVIRONMENTNAME pweb_nas_stack=pweb-nas-$ENVIRONMENTNAME pweb_base_stack=pweb-base-$ENVIRONMENTNAME"


## Full stack
ansible-playbook -i inventory/$INVENTORY pweb-delete-stack.yml --extra-vars "environmentname=$ENVIRONMENTNAME use_env=$ENVIRONMENTNAME pweb_nas_stack=pweb-nas-$ENVIRONMENTNAME pweb_security_groups=true pweb_lsdssg_stack=pweb-lsdssg-$ENVIRONMENTNAME pweb_prvlsdssg_stack=pweb-prvlsdssg-$ENVIRONMENTNAME pweb_dps_stack=pweb-dps-$ENVIRONMENTNAME pweb_lscs_stack=pweb-lscs-$ENVIRONMENTNAME pweb_ts_stack=pweb-ts-$ENVIRONMENTNAME pweb_prvdps_stack=pweb-prvdps-$ENVIRONMENTNAME pweb_prvlscs_stack=pweb-prvlscs-$ENVIRONMENTNAME pweb_base_stack=pweb-base-$ENVIRONMENTNAME"

