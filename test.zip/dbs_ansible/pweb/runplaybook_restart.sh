#!/bin/bash

# Initialize variables
KEYFILE=/var/lib/awx/.ssh2/pweb-admin-brian.pem
AWS_BINARYBUCKET=s3://dbs-pweb-binaries/cf-templates/pweb-stack/
ENVIRONMENTNAME=spweb02
INVENTORY=staging_spweb02
EXTRAVARS=$2

# Location of log file
timestamp=$(date +%s)
LOG_FILE=/var/lib/awx/projects/pweb_log/pweb_restart_$ENVIRONMENTNAME-$timestamp.log
exec > >(tee -i $LOG_FILE) 2>&1
set -x

#Select the ec2 stack
ets_stop=false
ets_start=false
adps_stop=false
adps_start=false
edps_stop=false
edps_start=false
alscs_stop=false
alscs_start=false
elscs_stop=false
elscs_start=false
alsds_stop=false
alsds_start=false
elsds_stop=false
elsds_start=false

export AWS_ACCESS_KEY_ID='AKIAJUCUIELRVPPZEUEA'
export AWS_SECRET_ACCESS_KEY='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'

export ANSIBLE_HOSTS=./inventory/$INVENTORY/ec2.py
export EC2_INI_PATH=./inventory/$INVENTORY/ec2.ini

# Extract all files in dbs_ansible to ansible project location.
echo "Copying all cloudformation templates to : $AWS_BINARYBUCKET"
/usr/local/bin/aws s3 sync ./pweb-stack/ $AWS_BINARYBUCKET --delete

#Change permission for dynamic inventory file
chmod 775 ./inventory/$INVENTORY/ec2.py
chmod 775 ./inventory/$INVENTORY/ec2.ini

echo " Running Playbooks for restart"

# restart teamsite
ansible-playbook --private-key=$KEYFILE -i inventory/$INVENTORY pweb-restart.yml --extra-vars "
environmentname=$ENVIRONMENTNAME 
use_env=$ENVIRONMENTNAME
ets_stop=false
ets_start=false
adps_stop=true
adps_start=true
edps_stop=true
edps_start=true
alscs_stop=true
alscs_start=true
elscs_stop=true
elscs_start=true
alsds_stop=false
alsds_start=false
elsds_stop=false
elsds_start=false
appname=lscs
ansible_ssh_user=ec2-user
" --flush-cache

# restart adps
ansible-playbook --private-key=$KEYFILE -i inventory/$INVENTORY pweb-restart.yml --extra-vars "
environmentname=$ENVIRONMENTNAME 
use_env=$ENVIRONMENTNAME
ets_stop=false
ets_start=false
adps_stop=false
adps_start=false
edps_stop=false
edps_start=false
alscs_stop=false
alscs_start=false
elscs_stop=false
elscs_start=false
alsds_stop=true
alsds_start=true
elsds_stop=true
elsds_start=true
appname=sg
ansible_ssh_user=ec2-user
" --flush-cache

