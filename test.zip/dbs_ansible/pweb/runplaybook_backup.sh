#!/bin/bash

# Initialize variables
KEYFILE=/var/lib/awx/.ssh2/pweb-admin-brian.pem
AWS_BINARYBUCKET=s3://dbs-pweb-binaries/cf-templates/pweb-stack/
ENVIRONMENTNAME=spweb02
INVENTORY=staging_spweb02
EXTRAVARS=$2

# Location of log file
timestamp=$(date +%s)
LOG_FILE=/var/lib/awx/projects/pweb_log/pweb_backup_$ENVIRONMENTNAME-$timestamp.log
exec > >(tee -i $LOG_FILE) 2>&1
set -x

#Select the ec2 stack
stack_ets=false
stack_alsds=false
stack_elsds=false
stack_adps=false
stack_edps=false
stack_alscs=false
stack_elscs=false
stack_anas=false

#Select the rds stack
stack_tsdb=false
stack_appdb=false
stack_prvdb=false

#Select the s3 source
stack_asgs3=true
stack_esgs3=true
stack_aposbs3=true
stack_eposbs3=true

export AWS_ACCESS_KEY_ID='AKIAJUCUIELRVPPZEUEA'
export AWS_SECRET_ACCESS_KEY='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'

export ANSIBLE_HOSTS=./inventory/$INVENTORY/ec2.py
export EC2_INI_PATH=./inventory/$INVENTORY/ec2.ini

# Extract all files in dbs_ansible to ansible project location.
echo "Copying all cloudformation templates to : $AWS_BINARYBUCKET"
/usr/local/bin/aws s3 sync ./pweb-stack/ $AWS_BINARYBUCKET --delete

#Change permission for dynamic inventory file
chmod 775 ./inventory/$INVENTORY/ec2.py
chmod 775 ./inventory/$INVENTORY/ec2.ini

echo " Running Playbooks for backup"

ansible-playbook --private-key=$KEYFILE -i inventory/$INVENTORY pweb-backup.yml --extra-vars "environmentname=$ENVIRONMENTNAME use_env=$ENVIRONMENTNAME stack_ets=$stack_ets stack_alsds=$stack_alsds stack_elsds=$stack_elsds stack_adps=$stack_adps stack_edps=$stack_edps stack_alscs=$stack_alscs stack_elscs=$stack_elscs stack_security=$stack_security stack_awsbase=$stack_awsbase stack_anas=$stack_anas ansible_ssh_user=ec2-user stack_tsdb=$stack_tsdb stack_appdb=$stack_appdb stack_prvdb=$stack_prvdb stack_asgs3=$stack_asgs3 stack_esgs3=$stack_esgs3 stack_aposbs3=$stack_aposbs3 stack_eposbs3=$stack_eposbs3" --flush-cache
