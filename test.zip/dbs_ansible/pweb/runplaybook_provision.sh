#!/bin/bash

# Initialize variables
KEYFILE=/var/lib/awx/.ssh2/pweb-admin-brian.pem
AWS_BINARYBUCKET=s3://dbs-pweb-binaries/cf-templates/pweb-stack/
ENVIRONMENTNAME=spweb02
INVENTORY=staging_spweb02
EXTRAVARS=$2

# Location of log file
timestamp=$(date +%s)
LOG_FILE=/var/lib/awx/projects/pweb_log/pweb_provision_$ENVIRONMENTNAME-$timestamp.log
exec > >(tee -i $LOG_FILE) 2>&1
set -x

#Select the stack
stack_security=false
stack_awsbase=true
stack_anas=false
stack_ets=false
stack_alsds=false
stack_elsds=false
stack_adps=false
stack_edps=false
stack_alscs=false
stack_elscs=true

#provision is always with autoscale 1min and 1max
lsdssg_ec2_instancetype=t2.medium
lsdssg_ec2_asginstancemin=1
lsdssg_ec2_asginstancemax=1
lsdssg_ec2_asginstancedesired=1

#provision is always with autoscale 1min and 1max
prvlsdssg_ec2_instancetype=t2.medium
prvlsdssg_ec2_asginstancemin=1
prvlsdssg_ec2_asginstancemax=1
prvlsdssg_ec2_asginstancedesired=1

#provision is always with autoscale 1min and 1max
lscs_ec2_instancetype=t2.medium
lscs_ec2_asginstancemin=1
lscs_ec2_asginstancemax=1
lscs_ec2_asginstancedesired=1

#provision is always with autoscale 1min and 1max
prvlscs_ec2_instancetype=t2.medium
prvlscs_ec2_asginstancemin=1
prvlscs_ec2_asginstancemax=1
prvlscs_ec2_asginstancedesired=1

#Password details
tsdb_dev_user=pwebtsuser
tsdb_dev_password_enc=WRBapUQAzyRlWRfDLmPVOrvmBmEQ2D42
tsdb_dev_password=manage123

tsdb_prd_user=pwebtsuser
tsdb_prd_password_enc=WRBapUQAzyRlWRfDLmPVOrvmBmEQ2D42
tsdb_prd_password=manage123

appdb_user=pweblsuser
appdb_password_enc=WRBapUQAzyRlWRfDLmPVOrvmBmEQ2D42
appdb_password=manage123

lsdb_prd_user=pweblsuser
lsdb_prd_password_enc=WRBapUQAzyRlWRfDLmPVOrvmBmEQ2D42

prvdb_user=pweblsuser
prvdb_password_enc=WRBapUQAzyRlWRfDLmPVOrvmBmEQ2D42
prvdb_password=manage123

# App DB
appdbmasterusername=dbs
appdbmasteruserpassword=Manage1234

# Teamsite RDS
tsdbmasterusername=dbs
tsdbmasteruserpassword=Manage1234

# Preview RDS
previewdbmasterusername=dbs
previewdbmasteruserpassword=Manage1234

# Application user detials for Preview LiveSite
previewdbusername=pweblsprvuser
previewdbpassword=WRBapUQAzyRlWRfDLmPVOrvmBmEQ2D42

# Application user detials for Runtime LiveSite
appdbusername=pweblsuser
appdbpassword=WRBapUQAzyRlWRfDLmPVOrvmBmEQ2D42

# Teamsite user detials for Runtime LiveSite
tsdbusername=pwebtsuser
tsdbpassword=WRBapUQAzyRlWRfDLmPVOrvmBmEQ2D42


export AWS_ACCESS_KEY_ID='AKIAJUCUIELRVPPZEUEA'
export AWS_SECRET_ACCESS_KEY='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'

export ANSIBLE_HOSTS=./inventory/$INVENTORY/ec2.py
export EC2_INI_PATH=./inventory/$INVENTORY/ec2.ini

# Extract all files in dbs_ansible to ansible project location.
echo "Copying all cloudformation templates to : $AWS_BINARYBUCKET"
/usr/local/bin/aws s3 sync ./pweb-stack/ $AWS_BINARYBUCKET --delete

#Change permission for dynamic inventory file
chmod 775 ./inventory/$INVENTORY/ec2.py
chmod 775 ./inventory/$INVENTORY/ec2.ini

echo " Running Playbooks for provision"

ansible-playbook --private-key=$KEYFILE -i inventory/$INVENTORY pweb-provision.yml --extra-vars "
environmentname=$ENVIRONMENTNAME
stack_ets=$stack_ets
stack_alsds=$stack_alsds
stack_elsds=$stack_elsds
stack_adps=$stack_adps
stack_edps=$stack_edps
stack_alscs=$stack_alscs
stack_elscs=$stack_elscs
stack_security=$stack_security
stack_awsbase=$stack_awsbase 
stack_anas=$stack_anas 
ansible_ssh_user=ec2-user 
tsdb_dev_user=$tsdb_dev_user
tsdb_dev_password_enc=$tsdb_dev_password_enc
tsdb_dev_password=$tsdb_dev_password
tsdb_prd_user=$tsdb_prd_user
tsdb_prd_password_enc=$tsdb_prd_password_enc
tsdb_prd_password=$tsdb_prd_password
appdb_user=$appdb_user
appdb_password_enc=$appdb_password_enc
appdb_password=$appdb_password
lsdb_prd_user=$lsdb_prd_user
lsdb_prd_password_enc=$lsdb_prd_password_enc
prvdb_user=$prvdb_user
prvdb_password_enc=$prvdb_password_enc
prvdb_password=$prvdb_password
appdbmasterusername=$appdbmasterusername
appdbmasteruserpassword=$appdbmasteruserpassword
tsdbmasterusername=$tsdbmasterusername
tsdbmasteruserpassword=$tsdbmasteruserpassword
previewdbmasterusername=$previewdbmasterusername
previewdbmasteruserpassword=$previewdbmasteruserpassword
previewdbusername=$previewdbusername
previewdbpassword=$previewdbpassword
appdbusername=$appdbusername
appdbpassword=$appdbpassword
tsdbusername=$tsdbusername
tsdbpassword=$tsdbpassword 
" --flush-cache
