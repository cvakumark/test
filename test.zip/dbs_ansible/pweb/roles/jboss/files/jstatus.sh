#!/bin/ksh

. /opt/jboss/scripts/bin/env.sh $1 $2
echo "==========================================="
echo "           JBOSS CURRENT STATUS               "
echo "==========================================="
/bin/ps auwwwx |grep java| grep jboss | grep -v grep >> /tmp/rjj.$$

   cat /tmp/rjj.$$|while read i
        do
          pid=`echo $i|awk '{print $2}'`
          echo $i|/bin/sed 's/ / \\\\n\ /g'|xargs echo -e|grep jboss.node.name | cut -d "=" -f2 |uniq >  /tmp/ServerName.$$
          echo $i|/bin/sed 's/ / \\\\n\ /g'|xargs echo -e|grep jboss.server.base.dir | cut -d "=" -f2 | uniq >  /tmp/dir.$$
          echo "PID=$pid DIR=`cat /tmp/dir.$$` ServerName=`cat /tmp/ServerName.$$`"
          rm /tmp/ServerName.$$ /tmp/dir.$$
        done
          rm /tmp/rjj.$$
echo "==========================================="
