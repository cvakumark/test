#!/bin/sh

. /opt/jboss/scripts/bin/jstatus.sh $1 $2


ps -ef | grep java | grep "SERVER=$SERVER_NAME" | awk {'print "kill -9 " $2'} | sh -x
