#!/bin/bash

instance_id=$1
appcode=$2
pccode=$3
region_name=$4
temp_volume_id=''

name=($(aws ec2 describe-instances --instance-id $instance_id --region $region_name --output text --query 'Reservations[].Instances[].Tags[?Key==`Name`].Value[]') )

volumes=( $(aws ec2 describe-instances --instance-id $instance_id --region $region_name --output text --query 'Reservations[0].Instances[0].BlockDeviceMappings[*].Ebs.VolumeId') )
volumes_length=${#volumes[@]}

echo "Taging Volumes"

for (( i=0; i<$volumes_length; i++ )); do
    temp_volume_id=${volumes[$i]}
    echo "Taging volume: "$temp_volume_id
    aws ec2 create-tags --region $region_name --resource $temp_volume_id --tags Key=App-code,Value=$appcode
    aws ec2 create-tags --region $region_name --resource $temp_volume_id --tags Key=PC-code,Value=$pccode
    aws ec2 create-tags --region $region_name --resource $temp_volume_id --tags Key=Name,Value=$name
done
