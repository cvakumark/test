#!/pwebcma/TeamSite/iw-perl/bin/iwperl 

use strict; 
use TeamSite::Config; 

(my $iwhome = TeamSite::Config::iwgethome()) =~ tr|\\|/|; 
(my $iwmount = TeamSite::Config::iwgetmount()) =~ tr|\\|/|; 

open (LIST, "/pwebcma/TeamSite/dbs_custom/scripts/conf/adduser.cfg") || debug("Cant open /pwebcma/TeamSite/dbs_custom/scripts/conf/adduser.cfg");
my @grouplist=<LIST>;
close(LIST); 

chomp($iwhome); 
chomp($iwmount);

my $debug_output = "/pwebcma/TeamSite/dbs_custom/scripts/logs/adduser.log"; 

foreach my $details (@grouplist) {

	$details =~ s/^\s*//gs; 
	$details =~ s/[\n\r\s]*$//gs;
	if ($details ne "")
	{
		my($maingroup,$userName)=split(/:/,$details);
		add_User_Group($maingroup,$userName);
	}
}

sub add_User_Group 
{ 

	my ($enadmingrp,$userName) =  @_; 	 

	my @users=split(/,/,$userName); 

	foreach my $user (@users) 
	{ 
		my $adduer=`$iwhome/bin/iwgroup add-users $enadmingrp $user 2>&1 1>&2`; 
		debug("Added user $user to $enadmingrp"); 
                #debug("$enadmingrp========$user"); 
	}
} 

#===================================================================== 
# simple debugging routine 
#===================================================================== 
sub debug 
{ 
    if ($debug_output) 
    { 
        open(OUT, ">>$debug_output") || print "cant open log file $debug_output\n"; 
        print OUT @_, "\n";
        close(OUT);
        `chmod 775 $debug_output`;
    }
}

