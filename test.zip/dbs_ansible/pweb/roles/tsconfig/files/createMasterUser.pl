#!/pwebcma/TeamSite/iw-perl/bin/iwperl -w

##################################################################################################################################
# Usage: This script will add users to teamSite and OD
# 1. if user-name is passed as argument, it will create that user as teamSite master and OD master
# 2. if user name filelist (one user-name in one line) is passed, it will create that teamsite and OD user.

# Input:
# 1. user name, OR
# 2. user list in file (one user-name in one line)

# Output:
# 1. Create TeamSite master & OD admin user.

# Command to execute this script:-
# /pwebcma/TeamSite/iw-perl/bin/iwperl /pwebcma/TeamSite/iw-perl/site/lib/createUsers.pl <user-name>
# OR
# /pwebcma/TeamSite/iw-perl/bin/iwperl /pwebcma/TeamSite/iw-perl/site/lib/createUsers.pl
##################################################################################################################################

#########################################
# packages for reference
#########################################
use warnings;
use TeamSite::Config;

#########################################
# teamSite install path
#########################################
my $iwhome = TeamSite::Config::iwgethome();
chomp $iwhome;

#########################################
# openDeploy install path
#########################################
my $ODHOMEFILE="/etc/defaultiwodhome";
my $IWOD60HOME=`cat $ODHOMEFILE`;
chomp $IWOD60HOME;

#########################################
# read argument
#########################################
my $user_name = $ARGV[0];


#########################################
# if argument is passed
#########################################
if (@ARGV) {
        #########################################
        # command to add user in teamSite
        #########################################
        my $addUserCommand = qq("$iwhome"/bin/iwuseradm add-user "$user_name" -db ext_src_1);
        my $executeaddUserCommand = qx($addUserCommand);

        #########################################
        # command to set preferred ui
        #########################################
        my $setPreferredUICommand = qq("$iwhome"/bin/iwuseradm set-preferred-ui "$user_name" ccpro);
        my $executesetPreferredUICommand = qx($setPreferredUICommand);

        #########################################
        # command to set user as master
        #########################################
        my $setMasterCommand = qq("$iwhome"/bin/iwuseradm set-master "$user_name" true);
        my $executesetMasterCommand = qx($setMasterCommand);

        #########################################
        # command to add user as OD admin
        #########################################
        my $addODUserCommand = qq("$IWOD60HOME"/bin/iwodauthorize -r add od-admin "$user_name");
        my $executeaddODUserCommand = qx($addODUserCommand);
}
#########################################
# if no argument is passed
#########################################
else{
        #########################################
        # File contain list of users
        #########################################
        my $userFile = "/pwebcma/TeamSite/conf/roles/sample_users.txt";
        my $user_name_file = "";
        #########################################
        # read above file and add user to TS & OD
        #########################################
        open(my $fh, '<:encoding(UTF-8)', $userFile) or die "Could not open file '$userFile' $!";
        while ($user_name_file = <$fh>) {
                chomp $user_name_file;
                print "$user_name_file";
                print "\n";
                $user_name_file =~ s/\n//g;
                $user_name_file =~ s/\r//g;
                #########################################
                # command to add user in teamSite
                #########################################
                my $addUserCommand = qq("$iwhome"/bin/iwuseradm add-user "$user_name_file" -db ext_src_1);
                print "$addUserCommand";
                my $executeaddUserCommand = qx($addUserCommand);

		        #########################################
		        # command to set user as master
		        #########################################
		        my $setMasterCommand = qq("$iwhome"/bin/iwuseradm set-master "$user_name_file" true);
		        my $executesetMasterCommand = qx($setMasterCommand);

                #########################################
                # command to set preferred ui
                #########################################
                my $setPreferredUICommand = qq("$iwhome"/bin/iwuseradm set-preferred-ui "$user_name_file" ccpro);
                print "$setPreferredUICommand";
                my $executesetPreferredUICommand = qx($setPreferredUICommand);

                #########################################
                # command to add as OD user
                #########################################
                my $addODUserCommand = qq("$IWOD60HOME"/bin/iwodauthorize -r add od-user "$user_name_file");
                print "$addODUserCommand";
                my $executeaddODUserCommand = qx($addODUserCommand);
        }
        close $fh;
}

#########################################
# command to add iwui to OD user
#########################################
my $addIWUIODUserCommand = qq("$IWOD60HOME"/bin/iwodauthorize -r add od-admin iwui);
print "$addIWUIODUserCommand";
my $executeaddIWUIODUserCommand = qx($addIWUIODUserCommand);
