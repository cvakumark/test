#!/bin/bash


#stop OD server if running
/etc/init.d/iwodserver stop

sleep 2

#start OD server if running
/etc/init.d/iwodserver start

sleep 2

#stop Teamsite server if running
/etc/init.d/iw.server stop

sleep 10

#start Teamsite server if running
/etc/init.d/iw.server start

sleep 5
