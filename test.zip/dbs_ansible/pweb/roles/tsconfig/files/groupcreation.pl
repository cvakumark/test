#!/pwebcma/TeamSite/iw-perl/bin/iwperl

use strict;
use TeamSite::Config;

(my $iwhome = TeamSite::Config::iwgethome()) =~ tr|\\|/|;
(my $iwmount = TeamSite::Config::iwgetmount()) =~ tr|\\|/|;

print "Running Group creation script ....\n";

my $debug_output = "/pwebcma/TeamSite/dbs_custom/scripts/groupcreation.log";

debug("Initiating group creation ..... ");

open (LIST, "/pwebcma/TeamSite/dbs_custom/scripts/conf/groupcreation.cfg") || debug("Cant open /pwebcma/TeamSite/dbs_custom/scripts/conf/groupcreation.cfg");
my @grouplist=<LIST>;
close(LIST);

my $ui ="iwui";

chomp($iwhome);
chomp($iwmount);



foreach my $details (@grouplist) {

	$details =~ s/^\s*//gs;
	$details =~ s/[\n\r\s]*$//gs;
	if ($details ne "")
	{
		my($maingroup,$subgroup)=split(/:/,$details);
		new_Group_Role_Creation($maingroup,$subgroup);
	}
}


print "Completed Group creation script ....\n";

sub new_Group_Role_Creation
{

	my ($enadmingrp,$group) =  @_;

	my $maingroupcreation=`$iwhome/bin/iwgroup create $enadmingrp 2>&1 1>&2`;

	debug("Main Group Creation is completed.");
	debug("Adding user iwui to $group");
	my $addui=`$iwhome/bin/iwgroup add-users $enadmingrp $ui 2>&1 1>&2`;

	my @subgrp=split(/,/,$group);

	foreach my $subgr (@subgrp)
	{

			my $groupcreation=`$iwhome/bin/iwgroup create $subgr 2>&1 1>&2`;
			debug("Sub Group $subgr Creation is completed.");
			my $maingroupaddgroup=`$iwhome/bin/iwgroup add-included-groups $enadmingrp $subgr 2>&1 1>&2`;
			debug("Adding group $subgr to $enadmingrp");
	}
}

#=====================================================================
# simple debugging routine
#=====================================================================
sub debug
{
    if ($debug_output)
    {
        open(OUT, ">>$debug_output") || print "cant open log file $debug_output\n";
        print OUT @_, "\n";
        close(OUT);
        `chmod 775 $debug_output`;
    }
}
