#!/bin/bash
#log ebs mount
df | grep /dev/xvdf
if [ $? -eq 1 ]; then
    mkfs -t ext4 /dev/xvdf
    sed '/\/dev\/xvdf/d' /etc/fstab
    echo "/dev/xvdf       /log            ext4       defaults,nofail      0 2" >> /etc/fstab
    mkdir -p /log    
    mount /dev/xvdf /log
    mkdir -p /log/teamsite
    mkdir -p /log/application
    mkdir -p /log/odlogs
fi

#pwebstore ebs mount
df | grep /dev/xvdg
if [ $? -eq 1 ]; then
    mkfs -t ext4 /dev/xvdg
    sed '/\/dev\/xvdg/d' /etc/fstab
    echo "/dev/xvdg       /pwebstore     ext4       defaults,nofail      0 2" >> /etc/fstab
    mkdir -p /pwebstore
    mount /dev/xvdg /pwebstore
fi

#pwebcma ebs mount
df | grep /dev/xvdh
if [ $? -eq 1 ]; then
    mkfs -t ext4 /dev/xvdh
    sed '/\/dev\/xvdh/d' /etc/fstab
    echo "/dev/xvdh       /pwebcma     ext4       defaults,nofail      0 2" >> /etc/fstab
    mkdir -p /pwebcma
    mount /dev/xvdh /pwebcma
fi
