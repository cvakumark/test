from __future__ import print_function
import boto3
import json
import datetime
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from aws_requests_auth.aws_auth import AWSRequestsAuth
from elasticsearch import Elasticsearch, RequestsHttpConnection
import requests
import os
from aws_requests_auth import boto_utils
from requests_aws_sign import AWSV4Sign
from boto3 import session
from elasticsearch.helpers import bulk, scan
import time
# Initialize  variables
session = session.Session()
credentials = session.get_credentials().get_frozen_credentials()
def datetime_convert(o):
    if isinstance(o, datetime.datetime):
        return o.__str__()
timestamp = datetime.datetime.now()
timestamp = timestamp.isoformat()
asg_cloudwatch = []
actions_status_data = []
actions = []
ins = []
# Main function.
def lambda_handler(event, context):

#Create Authentication
    service = 'es'
    es_url_env = os.environ['ELASTIC_SEARCH_URL']
    es_host = es_url_env
    awsauth = AWSRequestsAuth(
        aws_access_key=credentials.access_key,
        aws_secret_access_key=credentials.secret_key,
        aws_token=credentials.token,
        aws_host=es_host,
        aws_region=session.region_name,
        aws_service=service)
#Create Elastic Search Connection with auth
    es = Elasticsearch(
        hosts=[{'host': es_host, 'port': 80}],
        http_auth=awsauth,
        connection_class=RequestsHttpConnection)

    print(es.info())
    request_body = {
            'mappings': {
                'autoscaling': {
                    'properties': {
                        'InstanceId': {'index': 'not_analyzed', 'type': 'number'},
                        'AutoscalingGroupName': {'index': 'not_analyzed', 'type': 'string'},
                        'SystemStatus': {'index': 'not_analyzed', 'type': 'string'},
                        'InstanceStatus': {'index': 'not_analyzed', 'type': 'string'},

                    }}}

            }
    # Creating the autoscale index
    es.indices.create(index = 'autoscalinghealthcheck' ,body = request_body, ignore=[400,404])
    aws_account_id = os.environ['AWS_ACCOUNT_ID']
    resource_arn = 'arn:aws:lambda:ap-southeast-1:'+ aws_account_id +':function:lampwebautoscalingeventnotification'
    client = boto3.client('autoscaling')
    cloudwatch = boto3.client('cloudwatch')
    ec2 = boto3.resource('ec2')
    client_lambda = boto3.client('lambda')
    client_lambda.tag_resource(Resource=resource_arn, Tags={'App-code':'PWEB','PC-code':'259S'})
    # Get all autoscaling group name for PWEB.
    response = client.describe_auto_scaling_groups()
    paginator = client.get_paginator('describe_auto_scaling_groups')
    page_iterator = paginator.paginate(PaginationConfig={'PageSize': 100})
    filtered_asgs = page_iterator.search(
        'AutoScalingGroups[] | [?contains(Tags[?Key==`{}`].Value, `{}`)]'.format(
        'App-code', 'PWEB')
        )
    for asg in filtered_asgs:
        asg_name = (asg['AutoScalingGroupName'])
        asg_name = asg_name.strip()
        asg_cloudwatch.append(asg_name)
    bulk_deletes = []
    query_body={"query": {"range": {"current_time": {"lt" : "now"}}}}
    for result in scan(es,
                query=query_body,  # same as the search() body parameter
                index='autoscalinghealthcheck',
                doc_type='autoscaling',
                _source=False,
                track_scores=False,
                scroll='25m'):
        result['_op_type'] = 'delete'
        bulk_deletes.append(result)

    bulk(es, bulk_deletes)
    time.sleep(10)
    # Get all autoscale instances curretly running.
    res = client.describe_auto_scaling_instances()
    for asi in res['AutoScalingInstances']:
        for asg in asg_cloudwatch:
            if asi['AutoScalingGroupName'] == asg:
                instances_id = json.dumps(asi)
                instances_id = json.loads(instances_id)
                InstanceId = instances_id['InstanceId']
                asg_name = instances_id['AutoScalingGroupName']
                HealthStatus = instances_id['HealthStatus']
                LifecycleState = instances_id['LifecycleState']
                ec2instance = ec2.Instance(InstanceId)
                for tags in ec2instance.tags:
                    if tags["Key"] == 'Name':
                        instancename = tags["Value"]
                data = json.dumps({'AutoScalingGroupName': asg_name, 'InstanceId': InstanceId, 'InstanceName': instancename, 'HealthStatus': HealthStatus, 'LifecycleState': LifecycleState, 'current_time': timestamp
                })
                autoscalinginstancestatus_dict = {
                    "_index": 'autoscalinghealthcheck',
                    "_type": 'autoscaling',
                    "_id": str(datetime.datetime.now()),
                    "_source": data,

                }
        actions.append(autoscalinginstancestatus_dict)
        print(actions)
    helpers.bulk(es,actions)
