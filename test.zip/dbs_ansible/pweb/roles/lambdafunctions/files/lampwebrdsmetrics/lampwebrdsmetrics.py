# Collecting all RDS metrics and pushing into ES.
from __future__ import print_function
import boto3
import json
import datetime
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from aws_requests_auth.aws_auth import AWSRequestsAuth
from elasticsearch import Elasticsearch, RequestsHttpConnection
import requests
import os
from aws_requests_auth import boto_utils
from requests_aws_sign import AWSV4Sign
from boto3 import session
import re
# Intializing all variables.
session = session.Session()
credentials = session.get_credentials().get_frozen_credentials()
def datetime_convert(o):
    if isinstance(o, datetime.datetime):
        return o.__str__()
actions = []
all_rds_name = []

# Main function handler
def lambda_handler(event, context):
    #Create Authentication
    service = 'es'
    es_url_env = os.environ['ELASTIC_SEARCH_URL']
    es_host = es_url_env
    awsauth = AWSRequestsAuth(
        aws_access_key=credentials.access_key,
        aws_secret_access_key=credentials.secret_key,
        aws_token=credentials.token,
        aws_host=es_host,
        aws_region=session.region_name,
        aws_service=service)
#Create Elastic Search Connection with auth
    es = Elasticsearch(
        hosts=[{'host': es_host, 'port': 80}],
        http_auth=awsauth,
        connection_class=RequestsHttpConnection)

    print(es.info())
#Tagging Lambda Function
    aws_account_id = os.environ['AWS_ACCOUNT_ID']
    resource_arn = 'arn:aws:lambda:ap-southeast-1:'+ aws_account_id +':function:lampwebrdsmetrics'
    client_lambda = boto3.client('lambda')
    client_lambda.tag_resource(Resource=resource_arn, Tags={'App-code':'PWEB','PC-code':'259S'})
#Create ElasticSearch Index
    request_cpu = {
        'mappings': {
            'cpumetric': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
                        'Maximum': {'index': 'not_analyzed', 'type': 'float'},
                        'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_connections = {
        'mappings': {
            'connections': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
                        'Sum': {'index': 'not_analyzed', 'type': 'float'},
                        'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_writethroughput = {
        'mappings': {
            'writethroughput': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
                        'Sum': {'index': 'not_analyzed', 'type': 'float'},
                        'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_readthroughput = {
        'mappings': {
            'readthroughput': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
                        'Average': {'index': 'not_analyzed', 'type': 'float'},
                        'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_writeiops = {
        'mappings': {
            'writeiops': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
                        'Average': {'index': 'not_analyzed', 'type': 'float'},
                        'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_readiops = {
        'mappings': {
            'readiops': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
                        'Average': {'index': 'not_analyzed', 'type': 'float'},
                        'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }

    # Creating the Indexs for ELB dashboard.
    es.indices.create(index = 'rdscpumetrics' ,body = request_cpu, ignore=[400,404])
    es.indices.create(index = 'rdsconnectionsmetrics' ,body = request_connections, ignore=[400,404])
    es.indices.create(index = 'rdswritethroughputmetrics' ,body = request_writethroughput, ignore=[400,404])
    es.indices.create(index = 'rdsreadthroughputmetrics' ,body = request_readthroughput, ignore=[400,404])
    es.indices.create(index = 'rdswriteiopsmetrics' ,body = request_writeiops, ignore=[400,404])
    es.indices.create(index = 'rdsreadiopsmetrics' ,body = request_readiops, ignore=[400,404])


    client = boto3.client('rds')
    cloudwatch = boto3.client('cloudwatch')
    response = client.describe_db_instances()
    for rdsins in response['DBInstances']:
        rdsname = rdsins['DBInstanceIdentifier']
        arn = "arn:aws:rds:%s:%s:db:%s"%('ap-southeast-1',aws_account_id,rdsname)
        rdstags = client.list_tags_for_resource(ResourceName=arn)
        for tag in rdstags['TagList']:
            if tag['Key'] == 'Name':
                name = tag.get('Value')
                all_rds_name.append(name)
    r = re.compile(r"^.*(pweb).*$")
    #r = re.compile('rdsspweb*')
    pweb_rds_names = filter(r.match, all_rds_name)
    print(pweb_rds_names)

    # Collection CPUUtilization for RDS database
    for name in pweb_rds_names:
        try:
            response_cpu = cloudwatch.get_metric_statistics(
                Namespace='AWS/RDS',MetricName='CPUUtilization',
                StartTime=datetime.datetime.now() - datetime.timedelta(seconds=900),
                EndTime=datetime.datetime.now(), Period=900,
                Statistics=['Maximum'], Unit='Percent',
                Dimensions=[{'Name': 'DBInstanceIdentifier', 'Value': name}])
            cpu_metric = json.dumps(response_cpu['Datapoints'],default = datetime_convert)
            cpu_metric = cpu_metric.strip('[]')
            cpu_dict = {
                "_index": 'rdscpumetrics',
                    "_type": name,
                    "_id": str(datetime.datetime.now()),
                    "_source": cpu_metric
                }
            actions.append(cpu_dict)
            helpers.bulk(es,actions)
        except elasticsearch.ElasticsearchException as e:
            print(e)
            pass

    # Collection DatabaseConnections for RDS database
    for name in pweb_rds_names:
        try:
            response_connections = cloudwatch.get_metric_statistics(
                Namespace='AWS/RDS',MetricName='DatabaseConnections',
                StartTime=datetime.datetime.now() - datetime.timedelta(seconds=900),
                EndTime=datetime.datetime.now(), Period=900,
                Statistics=['Sum'], Unit='Count',
                Dimensions=[{'Name': 'DBInstanceIdentifier', 'Value': name}])
            db_connections_metric = json.dumps(response_cpu['Datapoints'],default = datetime_convert)
            db_connections_metric = db_connections_metric.strip('[]')
            connections_dict = {
                "_index": 'rdsconnectionsmetrics',
                "_type": name,
                "_id": str(datetime.datetime.now()),
                "_source": db_connections_metric
                }
            actions.append(connections_dict)
            helpers.bulk(es,actions)
        except elasticsearch.ElasticsearchException as e:
            print(e)
            pass


    # Collection WriteThroughput for RDS databases
    for name in pweb_rds_names:
        try:
            response_write_throughput = cloudwatch.get_metric_statistics(
                Namespace='AWS/RDS',MetricName='WriteThroughput',
                StartTime=datetime.datetime.now() - datetime.timedelta(seconds=900),
                EndTime=datetime.datetime.now(), Period=900,
                Statistics=['Sum'], Unit='Count',
                Dimensions=[{'Name': 'DBInstanceIdentifier', 'Value': name}])
            db_write_throughput = json.dumps(response_cpu['Datapoints'],default = datetime_convert)
            db_write_throughput = db_write_throughput.strip('[]')
            writethroughput_dict = {
                "_index": 'rdswritethroughputmetrics',
                    "_type": name,
                    "_id": str(datetime.datetime.now()),
                    "_source": db_write_throughput
                }
            actions.append(writethroughput_dict)
            helpers.bulk(es,actions)
        except elasticsearch.ElasticsearchException as e:
            print(e)
            pass
    # Collection WriteIOPS for RDS databases
    for name in pweb_rds_names:
        try:
            response_write_iops = cloudwatch.get_metric_statistics(
                Namespace='AWS/RDS',MetricName='WriteIOPS',
                StartTime=datetime.datetime.now() - datetime.timedelta(seconds=900),
                EndTime=datetime.datetime.now(), Period=900,
                Statistics=['Sum'], Unit='Count',
                Dimensions=[{'Name': 'DBInstanceIdentifier', 'Value': name}])
            db_write_iops = json.dumps(response_cpu['Datapoints'],default = datetime_convert)
            db_write_iops = db_write_iops.strip('[]')
            writeiops_dict = {
                "_index": 'rdswriteiopsmetrics',
                "_type": name,
                "_id": str(datetime.datetime.now()),
                "_source": db_write_iops
                }
            actions.append(writeiops_dict)
            helpers.bulk(es,actions)
        except elasticsearch.ElasticsearchException as e:
            print(e)
            pass

    # Collection ReadThroughput for RDS databases
    for name in pweb_rds_names:
        try:
            response_read_throughput = cloudwatch.get_metric_statistics(
                Namespace='AWS/RDS',MetricName='ReadThroughput',
                StartTime=datetime.datetime.now() - datetime.timedelta(seconds=900),
                EndTime=datetime.datetime.now(), Period=900,
                Statistics=['Sum'], Unit='Count',
                Dimensions=[{'Name': 'DBInstanceIdentifier', 'Value': name}])
            db_read_throughput = json.dumps(response_cpu['Datapoints'],default = datetime_convert)
            db_read_throughput = db_read_throughput.strip('[]')
            readthroughput_dict = {
                "_index": 'rdsreadthroughputmetrics',
                "_type": name,
                "_id": str(datetime.datetime.now()),
                "_source": db_read_throughput

            }
            actions.append(readthroughput_dict)
            helpers.bulk(es,actions)
        except elasticsearch.ElasticsearchException as e:
            print(e)
            pass

    # Collection ReadIOPS for RDS databases
    for name in pweb_rds_names:
        try:
            response_read_iops = cloudwatch.get_metric_statistics(
                Namespace='AWS/RDS',MetricName='ReadIOPS',
                StartTime=datetime.datetime.now() - datetime.timedelta(seconds=900),
                EndTime=datetime.datetime.now(), Period=900,
                Statistics=['Sum'], Unit='Count',
                Dimensions=[{'Name': 'DBInstanceIdentifier', 'Value': name}])
            db_read_iops = json.dumps(response_cpu['Datapoints'],default = datetime_convert)
            db_read_iops = db_read_iops.strip('[]')
            readiops_dict = {
                "_index": 'rdsreadiopsmetrics',
                "_type": name,
                "_id": str(datetime.datetime.now()),
                "_source": db_read_iops

            }
            actions.append(readiops_dict)
            helpers.bulk(es,actions)
        except elasticsearch.ElasticsearchException as e:
            print(e)
            pass