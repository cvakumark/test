 #This Lambda Function Will tag Untagged AMI and Snapshots
import boto3
import os
import json
import time
from botocore.exceptions import ClientError
import logging
##initializing variable
accountNumber = os.environ['AWS_ACCOUNT_ID']
#ec = boto3.client('ec2', 'ap-southeast-1')
logger = logging.getLogger()
logger.setLevel(logging.ERROR)
image_name = []
untagged_images = []
name_to_attach = []
untagged_ami = []
pweb_untagged_snapshots = []
tagged_pweb_ami = []
snap_tag = []
instance_with_no_tag = []
all_attached_volumes = []
volume_without_tags = []
def lambda_handler(event, context):
 
    ec2 = boto3.resource('ec2')
    ec = boto3.client('ec2')
    filters = [{'Name':'tag:App-code', 'Values':['PWEB']}]
    ## find instances which Don't have TAG
    instances = [id_of_instance for id_of_instance in ec2.instances.all()]
    for non_tag_instances in instances:
        try:
            for tag in non_tag_instances.tags:
                if tag['Key'] == 'Name':
                    name = tag.get('Value')
                    if 'pweb' in name:
                        print ">>Verifying instance which has name pweb in it: %s" % name
                        if 'App-code' not in [t['Key'] for t in non_tag_instances.tags]:
                            instance_tag = non_tag_instances.instance_id
                            instance_with_no_tag.append(instance_tag)
        except TypeError:
            continue
    print ">>Instance With No Tag %s" % instance_with_no_tag
    for instance in ec2.instances.filter(Filters=filters):
        inst_id = instance.id
        for volume in instance.volumes.all():
            pweb_volumes = volume.id
            all_attached_volumes.append(pweb_volumes)
    for all_pweb_volumes in all_attached_volumes:
        result_volumes = ec.describe_volumes(VolumeIds=[all_pweb_volumes])
        for non_tag_volumes in result_volumes['Volumes']:
            try:
                if non_tag_volumes['Tags'] != 0:
                    volume_already_tagged = non_tag_volumes['VolumeId']
                    print ">>Volumes In Use but Tagged %s" %(volume_already_tagged)
                    #volume_without_tags.append(volume_not_tagged)
            except KeyError:
                non_tag_volumes = non_tag_volumes['VolumeId']
                volume_without_tags.append(non_tag_volumes)
    print ">>Volumes In Use but No Tag %s" %(volume_without_tags)
    ##Find All active images of PWEB
    active_images = ec2.images.filter(Owners=[accountNumber])
    for images in active_images:
        if 'pweb' in images.name :
            image_id = images.id
            image_name.append(image_id)
    for image in image_name:
        image = ec2.Image(image)
        if not image.tags:
           untagged_img = image.id
           untagged_images.append(untagged_img)
        if image.tags is not None:
            pwebimg_tagged=image.id
            tagged_pweb_ami.append(pwebimg_tagged)
            time.sleep(1)
    print ">>Pweb AMI with tagging already  %s" % tagged_pweb_ami
    for tagged_image in tagged_pweb_ami:
        pwebimg_snapshots = ec.describe_snapshots(DryRun=False,OwnerIds=[accountNumber],Filters=[{'Name': 'description','Values': ['*'+tagged_image+'*']}]).get('Snapshots', [])
        for snapshot in pwebimg_snapshots:
            try:
                if snapshot['Tags'] != 0:
                    match = snapshot['SnapshotId']
            except KeyError:
                snap_without_tag = snapshot['SnapshotId']
                snap_tag.append(snap_without_tag) 

    print ">>Untagged AMIs %s" % untagged_images
    print ">>Untagged PWEB Snapshots but their AMIs are tagged %s " % snap_tag

    print "------------------------------------------"
    print "TAGGING THE UNTAGGED AMI AND ITS SNAPSHOTS"
    print "------------------------------------------"

## tag the AMI and its snapshots which are not tagged but Name contains pweb in it
    for img in untagged_images:
        try:
            ami_name = ec2.Image(img)
            ami_name = ami_name.name
            name_of_ami = ami_name
            print ">>Tagging image which name %s" % name_of_ami
            print ">>Tagging image which has id %s" % img
            #ec.create_tags(
                #Resources=[img],
                #Tags=[
                    #{'Key': 'App-code', 'Value': 'PWEB'},
                    #{'Key': 'PC-code', 'Value': '259S'},
                    #{'Key': 'Name', 'Value': name_of_ami}
                    #]
                    #)
        except ClientError as e:
            logger.error("Received error: %s", e, exc_info=True)
            pass
    for ami in untagged_images:
        time.sleep(1)
        snapshots = ec.describe_snapshots(DryRun=False,OwnerIds=[accountNumber],Filters=[{'Name': 'description','Values': ['*'+ami+'*']}]).get('Snapshots', [])
        snapnametag = ami + "-" + "created-by-tagging-lambda" 
        print ">>Tagging snapshots which belongs to %s" % ami
        for snapshot in snapshots:
            try:
                print "--tagging snapshot %s" % snapshot['SnapshotId']
                #ec.create_tags(
                    #Resources=[snapshot['SnapshotId']],
                    #Tags=[
                        #{'Key': 'App-code', 'Value': 'PWEB'},
                        #{'Key': 'PC-code', 'Value': '259S'},
                        #{'Key': 'Name', 'Value': snapnametag},
                        #]
                        #)
            except ClientError as e:
                logger.error("Received error: %s", e, exc_info=True)
                pass

    print "---------------------------------------------------------------"
    print "TAGGING THE UNTAGGED SNAPSHOTS BUT ITS AMI ARE ALREADY TAGGED"
    print "---------------------------------------------------------------"                
##Tag snapshots whose AMIs are tagged but snapshots not tagged
    for snap_name in snap_tag:
        try:
            print ">>tagging the untagged PWEB Snapshots %s" % snap_name
            #ec.create_tags(
                #Resources=[snap_name],
                #Tags=[
                    #{'Key': 'App-code', 'Value': 'PWEB'},
                    #{'Key': 'PC-code', 'Value': '259S'},
                    #{'Key': 'Name', 'Value': snapnametag},
                    #]
                    #)
        except ClientError as e:
            logger.error("Received error: %s", e, exc_info=True)
            pass
    ## tagging the untagged Volumes
    for volume_name in volume_without_tags:
        try:
            print ">>tagging the untagged Volumes %s" % volume_name
            #ec.create_tags(
                #Resources=[volume_name],
                #Tags=[
                    #{'Key': 'App-code', 'Value': 'PWEB'},
                    #{'Key': 'PC-code', 'Value': '259S'},
                    #{'Key': 'Name', 'Value': volume_name},
                    #]
                    #)
        except ClientError as e:
            logger.error("Received error: %s", e, exc_info=True)
            pass
    ## tagging the untagged Volumes
    for volume_name in volume_without_tags:
        try:
            print ">>tagging the untagged Volumes %s" % volume_name
            #ec.create_tags(
                #Resources=[volume_name],
                #Tags=[
                    #{'Key': 'App-code', 'Value': 'PWEB'},
                    #{'Key': 'PC-code', 'Value': '259S'},
                    #{'Key': 'Name', 'Value': volume_name},
                    #]
                    #)
        except ClientError as e:
            logger.error("Received error: %s", e, exc_info=True)
            pass