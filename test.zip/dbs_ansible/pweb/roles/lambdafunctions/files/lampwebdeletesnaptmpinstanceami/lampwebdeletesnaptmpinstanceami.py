### This script will delete all the AMI's and its attached snapshots based on their
### Delete on date tag.

import boto3
import datetime
import os
import re
import time
import json
import ast
from botocore.exceptions import ClientError
import logging
##initializing variable
accountNumber = os.environ['AWS_ACCOUNT_ID']
bucket_name_env = os.environ['S3_BUCKET_NAME']
static_ami_name = ['amipwebadpsec2','amipwebalscsec2','amipwebalsdsec2','amipwebedpsec2','amipwebelscsec2','amipwebelsdsec2','amipwebetsec2','snappwebanasid2','snappwebanasid1','amipwebanasec2','amipwebanasencryptec2']
image_name = []
golden_image = []
tag_pweb = []
skip_delete_on = []
image_of_active_instance = []
#ec = boto3.client('ec2', 'ap-southeast-1')

def lambda_handler(event, context):
    ##Attach tag to this function itself
    resource_arn = 'arn:aws:lambda:ap-southeast-1:'+ accountNumber +':function:lampwebdeletesnaptmpinstanceami'
    client_lambda = boto3.client('lambda')
    client_lambda.tag_resource(Resource=resource_arn, Tags={'App-code':'PWEB','PC-code':'259S'})
    ec2 = boto3.resource('ec2')
    ec = boto3.client('ec2')
    s3 = boto3.client('s3')
    filters = [{'Name':'tag:App-code', 'Values':['PWEB']}]
    reservations = ec.describe_instances(Filters=filters)['Reservations']
    for reservation in reservations:
        ec2_instances = reservation['Instances']
        for instance in ec2_instances:
            ImageId = instance['ImageId']
            image_of_active_instance.append(ImageId)
    print ">> List of AMI ids attached to running instance %s" % image_of_active_instance
    #active_images = ec2.images.filter(Owners=[accountNumber],Filters=[{'Name': 'tag:App-code', 'Values': ['PWEB']},{'Name': 'tag:PC-code', 'Values': ['259S']}])
    ##Find All active images of PWEB

    active_images = ec2.images.filter(Owners=[accountNumber],Filters=[{'Name': 'tag:App-code', 'Values': ['PWEB']},{'Name': 'tag:PC-code', 'Values': ['259S']}])
    for images in active_images:
        image_id = images.id
        image_name.append(image_id)
    delete_on_tag_images = ec.describe_images(Owners=[accountNumber],Filters=[{'Name': 'tag:App-code', 'Values': ['PWEB']},{'Name': 'tag:PC-code', 'Values': ['259S']}]).get('Images', [])
    for image in delete_on_tag_images:
        for tag in image['Tags']:
            if tag['Key'] == 'DeleteOn':
               DeleteOn = image['ImageId']
               skip_delete_on.append(DeleteOn)
    bucket_name = bucket_name_env
    ##Filter All temporary instances of pweb environments
    filters = [{'Name':'tag:App-code', 'Values':['PWEB']}]
    print "*** Begin cleaning up of tmp instances. Searching for tmp instances"
    for instance in ec2.instances.filter(Filters=filters):
        for tag in instance.tags:
                if tag['Key'] == 'Name':
                   name = tag.get('Value')
                   if 'tmp' in name:
                       inst = instance.id
                       tag_pweb.append(inst)
                       print ">>Found tmp instance: %s" % name
    if len(tag_pweb) != 0:
        print ">>Terminating the tmp instances: "
        print ', '.join(tag_pweb)
        ec2.instances.filter(InstanceIds=tag_pweb).terminate()
    else:
        print "No tmp instances to delete"
    print "*** Cleaning up of tmp instances completed.."
    print "--------------------------------------------"
    print "*** Begin looking for AMI ids which are not in env and snapshot files in s3.."
    #Get list of ami being use in different environments
    for key in s3.list_objects(Bucket=bucket_name,Prefix='vars/')['Contents']:
        key_var = key['Key']
        value = key_var.partition("/vars")[0].partition("/")[2]
        dir_name = value.rsplit('/',1)[0]
        file_name = value.rsplit('/',1)[1]
        key_value = 'vars' + '/' + dir_name + '/' + file_name
        file_name = file_name.split()
        for name in file_name:
            obj_file = s3.get_object(Bucket=bucket_name, Key=key_value)
            instance_data = json.dumps(obj_file['Body'].read())
            instance_data = json.loads(instance_data)
            data = ast.literal_eval(instance_data)
            for ami_id in static_ami_name:
                try:
                    ami_list = data[ami_id]
                    ami_list = ami_list.encode('utf8')
                    golden_image.append(ami_list)
                except KeyError:
                    print('no error')
    ##Compare both the list of Amis
    skip_golden = set(golden_image)
    filter_delete_on = set(skip_delete_on)
    filter_active_image = set(image_of_active_instance)
    skip_active_image = [x for x in image_name if x not in filter_active_image]
    skip_active = set(skip_active_image)
    skip_golden_image = [x for x in skip_active if x not in skip_golden]
    skip_delete_on_ami = [x for x in skip_golden_image if x not in filter_delete_on]
    print ">> List of AMI ids from the environment (FULL_LIST)"
    print ', '.join(image_name)    
    print ">> List of AMIs which are currently used by running pweb EC2 (LIST_1)"
    print ', '.join(filter_active_image)
    print ">> List of AMI ids from S3 bucket (LIST_2)"
    print ', '.join(golden_image)
    print ">> List of AMI ids that has Delete-on tag (LIST_3)"
    print ', '.join(filter_delete_on)    
    print ">> Final list for deletion = (FULL_LIST - (LIST_1 + LIST_2 + LIST_3))"
    print ', '.join(skip_delete_on_ami)
    ##Delete the unsed Amis
    for img in skip_delete_on_ami:
        try:
            snapshots = ec.describe_snapshots(DryRun=False,OwnerIds=[accountNumber],Filters=[{'Name': 'description','Values': ['*'+img+'*']}]).get('Snapshots', [])
            print "--------------------------------------"
            print ">>Cleaning up ami %s" % img
            time.sleep(5)
        except ClientError as e:
            logger.error("Received error: %s", e, exc_info=True)
        else:
            ec.deregister_image(DryRun=False,ImageId=img)
            for snapshot in snapshots:
                print ">>Deleting Snapshots %s" % snapshot['SnapshotId']
                ec.delete_snapshot(
                    DryRun = False,
                    SnapshotId = snapshot['SnapshotId']
                    )
                print ">>Delete completed snapshot id: %s" % snapshot['SnapshotId']