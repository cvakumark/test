# Collect CPU and memory utilization of each EC2 instance in PWEB and put in S3
from __future__ import print_function
import boto3
import json
import datetime
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from aws_requests_auth.aws_auth import AWSRequestsAuth
from elasticsearch import Elasticsearch, RequestsHttpConnection
import requests
import os
from aws_requests_auth import boto_utils
from requests_aws_sign import AWSV4Sign
from boto3 import session
# Intializing all variables.
session = session.Session()
credentials = session.get_credentials().get_frozen_credentials()
def datetime_convert(o):
    if isinstance(o, datetime.datetime):
        return o.__str__()

# Main function.
def lambda_handler(event, context):
    #Create Authentication
    service = 'es'
    es_url_env = os.environ['ELASTIC_SEARCH_URL']
    es_host = es_url_env
    awsauth = AWSRequestsAuth(
        aws_access_key=credentials.access_key,
        aws_secret_access_key=credentials.secret_key,
        aws_token=credentials.token,
        aws_host=es_host,
        aws_region=session.region_name,
        aws_service=service)
#Create Elastic Search Connection with auth
    es = Elasticsearch(
        hosts=[{'host': es_host, 'port': 80}],
        http_auth=awsauth,
        connection_class=RequestsHttpConnection)

    print(es.info())
    bucket_name_env = os.environ['S3_LOGS_BUCKETS']
    aws_account_id = os.environ['AWS_ACCOUNT_ID']
    resource_arn = 'arn:aws:lambda:ap-southeast-1:'+ aws_account_id +':function:lampwebec2instancemetrics'
    client_lambda = boto3.client('lambda')
    client_lambda.tag_resource(Resource=resource_arn, Tags={'App-code':'PWEB','PC-code':'259S'})

    # cleanup s3 folders before adding new CPU/Memory metrics
    s3 = boto3.resource('s3')
    bucket_name = s3.Bucket(bucket_name_env)
    for obj in bucket_name.objects.filter(Prefix='AWS/EC2/CPUUtilization'):
        s3.Object(bucket_name.name, obj.key).delete()

    # Get all PWEB EC2 instances.
    tag_pweb = []
    ec2 = boto3.resource('ec2')
    filters = [{'Name':'tag:App-code', 'Values':['PWEB']}]
    for instance in ec2.instances.filter(Filters=filters):
	    for tag in instance.tags:
                if tag['Key'] == 'Name':
                   name = tag.get('Value')
            inst = instance.id
            tag_pweb.append(inst)

            ## Put collected CPU metrics to S3 bucket
            for i in tag_pweb:
                bucket = bucket_name_env
                cw = boto3.client('cloudwatch')
                s3_client = boto3.client('s3')
                response_cpu = cw.get_metric_statistics(
                    Namespace='AWS/EC2',MetricName='CPUUtilization',
                    StartTime=datetime.datetime.utcnow() - datetime.timedelta(seconds=900),
                    EndTime=datetime.datetime.utcnow(), Period=900,
                    Statistics=['Average'], Unit='Percent',
                    Dimensions=[{'Name': 'InstanceId', 'Value': i}])
            key_name = 'AWS/EC2' + '/' + 'CPUUtilization' + '/' + name + '/' + 'CPUUtilization.json'
            request = {'Bucket' : bucket,'Key' : key_name,'Body' : json.dumps(response_cpu['Datapoints'],default = datetime_convert)}
            s3_client.put_object(**request)

            # Put collected Memory metrics to S3 bucket
            for i in tag_pweb:
                response_memory = cw.get_metric_statistics(
                    Namespace='System/Linux',MetricName='MemoryUtilization',
                    StartTime=datetime.datetime.now() - datetime.timedelta(seconds=900),
                    EndTime=datetime.datetime.now(), Period=900,
                    Statistics=['Maximum'], Unit='Percent',
                    Dimensions=[{'Name': 'InstanceId', 'Value': i}])
            mem_key_name = 'AWS/EC2' + '/' + 'CPUUtilization' + '/' + name + '/' + 'MemoryUtilization.json'
            request = {'Bucket' : bucket,'Key' : mem_key_name,'Body' : json.dumps(response_memory['Datapoints'],default = datetime_convert)}
            s3_client.put_object(**request)
