# Gather CPU and memory utilization for autoscaling instances.

from __future__ import print_function
import boto3
import json
import datetime
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from aws_requests_auth.aws_auth import AWSRequestsAuth
from elasticsearch import Elasticsearch, RequestsHttpConnection
import requests
import os
from aws_requests_auth import boto_utils
from requests_aws_sign import AWSV4Sign
from boto3 import session

# Initialize  variables.
session = session.Session()
credentials = session.get_credentials().get_frozen_credentials()
def datetime_convert(o):
    if isinstance(o, datetime.datetime):
        return o.__str__()
asg_cloudwatch = []
cpu_actions = []
mem_actions = []

# Main function.
def lambda_handler(event, context):
#Create Authentication
    service = 'es'
    es_url_env = os.environ['ELASTIC_SEARCH_URL']
    es_host = es_url_env
    awsauth = AWSRequestsAuth(
        aws_access_key=credentials.access_key,
        aws_secret_access_key=credentials.secret_key,
        aws_token=credentials.token,
        aws_host=es_host,
        aws_region=session.region_name,
        aws_service=service)
#Create Elastic Search Connection with auth
    es = Elasticsearch(
        hosts=[{'host': es_host, 'port': 80}],
        http_auth=awsauth,
        connection_class=RequestsHttpConnection)

    print(es.info())
    aws_account_id = os.environ['AWS_ACCOUNT_ID']
    resource_arn = 'arn:aws:lambda:ap-southeast-1:'+ aws_account_id +':function:lampwebautoscalingmetrics'
    client_lambda = boto3.client('lambda')
    client_lambda.tag_resource(Resource=resource_arn, Tags={'App-code':'PWEB','PC-code':'259S'})

    request_cpuutilization = {
        'mappings': {
            'cpuutilization': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
                        'Maximum': {'index': 'not_analyzed', 'type': 'float'},
                        'Minimum': {'index': 'not_analyzed', 'type': 'float'},
                        'Average': {'index': 'not_analyzed', 'type': 'float'},
                        'Sum': {'index': 'not_analyzed', 'type': 'float'},
                        'SampleCount': {'index': 'not_analyzed', 'type': 'float'},
                        'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_memorytilization = {
        'mappings': {
            'memorytilization': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
                        'Maximum': {'index': 'not_analyzed', 'type': 'float'},
                        'Minimum': {'index': 'not_analyzed', 'type': 'float'},
                        'Average': {'index': 'not_analyzed', 'type': 'float'},
                        'Sum': {'index': 'not_analyzed', 'type': 'float'},
                        'SampleCount': {'index': 'not_analyzed', 'type': 'float'},
                        'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

        }
    # Creating the autoscale cpu and memory indexs
    es.indices.create(index = 'autoscalingcpumetric' ,body = request_cpuutilization, ignore=[400,404])
    es.indices.create(index = 'autoscalingmemorymetric' ,body = request_memorytilization, ignore=[400,404])

    # Get all autoscaling group name for PWEB.
    client = boto3.client('autoscaling')
    cloudwatch = boto3.client('cloudwatch')
    response = client.describe_auto_scaling_groups()
    paginator = client.get_paginator('describe_auto_scaling_groups')
    page_iterator = paginator.paginate(PaginationConfig={'PageSize': 100})
    filtered_asgs = page_iterator.search(
        'AutoScalingGroups[] | [?contains(Tags[?Key==`{}`].Value, `{}`)]'.format(
        'App-code', 'PWEB')
        )
    for asg in filtered_asgs:
        asg_name = (asg['AutoScalingGroupName'])
        asg_name = asg_name.strip()
        asg_cloudwatch.append(asg_name)

    # Collect CPU metrics from cloudwatch for each Autoscale group. evey 300 sec.
    for name in asg_cloudwatch:
        response_mem = cloudwatch.get_metric_statistics(
            Namespace='AWS/EC2',MetricName='CPUUtilization',
            StartTime=datetime.datetime.now() - datetime.timedelta(seconds=600),
            EndTime=datetime.datetime.now(), Period=600,
            Statistics=['Maximum','Minimum','Average','Sum','SampleCount'], Unit='Percent',
            Dimensions=[{'Name': 'AutoScalingGroupName', 'Value': name}])
        cpu_metric = json.dumps(response_mem['Datapoints'],default = datetime_convert)
        cpu_metric = cpu_metric.strip('[]')
        cpu_dict = {
            "_index": 'autoscalingcpumetric',
                "_type": name,
                "_id": str(datetime.datetime.now()),
                "_source": cpu_metric

        }

    # Upload CPU actions to elasticsearch
        cpu_actions.append(cpu_dict)
    helpers.bulk(es,cpu_actions)

    # Collect Memory metrics from cloudwatch for each Autoscale group.
    for name in asg_cloudwatch:
        response_mem = cloudwatch.get_metric_statistics(
            Namespace='System/Linux',MetricName='MemoryUtilization',
            StartTime=datetime.datetime.now() - datetime.timedelta(seconds=600),
            EndTime=datetime.datetime.now(), Period=600,
            Statistics=['Maximum','Minimum','Average','Sum','SampleCount'], Unit='Percent',
            Dimensions=[{'Name': 'AutoScalingGroupName', 'Value': name}])
        mem_metric = json.dumps(response_mem['Datapoints'],default = datetime_convert)
        mem_metric = mem_metric.strip('[]')
        if len(mem_metric) > 0 :
            mem_dict = {
                "_index": 'autoscalingmemorymetric',
                    "_type": name,
                    "_id": str(datetime.datetime.now()),
                "_source": mem_metric

            }

    # Upload CPU actions to elasticsearch
            mem_actions.append(mem_dict)
    helpers.bulk(es,mem_actions)
