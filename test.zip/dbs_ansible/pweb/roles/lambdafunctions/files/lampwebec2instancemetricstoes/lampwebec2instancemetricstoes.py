# Collect CPU and memory utilization of each EC2 instance from S3 in PWEB and put in Elastic Search
from __future__ import print_function
import boto3
import json
import datetime
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from aws_requests_auth.aws_auth import AWSRequestsAuth
from elasticsearch import Elasticsearch, RequestsHttpConnection
import requests
import os
from aws_requests_auth import boto_utils
from requests_aws_sign import AWSV4Sign
from boto3 import session
# Initialize variables.
session = session.Session()
credentials = session.get_credentials().get_frozen_credentials()
actions_cpu = []
actions_memory = []
actions_system = []
def datetime_convert(o):
    if isinstance(o, datetime.datetime):
        return o.__str__()

# Main function.
def lambda_handler(event, context):
    #Create Authentication
    service = 'es'
    es_url_env = os.environ['ELASTIC_SEARCH_URL']
    es_host = es_url_env
    awsauth = AWSRequestsAuth(
        aws_access_key=credentials.access_key,
        aws_secret_access_key=credentials.secret_key,
        aws_token=credentials.token,
        aws_host=es_host,
        aws_region=session.region_name,
        aws_service=service)
#Create Elastic Search Connection with auth
    es = Elasticsearch(
        hosts=[{'host': es_host, 'port': 80}],
        http_auth=awsauth,
        connection_class=RequestsHttpConnection)

    print(es.info())
    
    bucket_name_env = os.environ['S3_LOGS_BUCKETS']
    aws_account_id = os.environ['AWS_ACCOUNT_ID']
    resource_arn = 'arn:aws:lambda:ap-southeast-1:'+ aws_account_id +':function:lampwebec2instancemetricstoes'
    client_lambda = boto3.client('lambda')
    client_lambda.tag_resource(Resource=resource_arn, Tags={'App-code':'PWEB','PC-code':'259S'})

    request_cpu = {
        'mappings': {
            'cpuutilization': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
	                'Average': {'index': 'not_analyzed', 'type': 'float'},
	                'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_memory = {
        'mappings': {
            'memoryutilization': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string', 'format': 'yyyy-MM-dd HH:mm:ss.SSS'},
	                'Mamimum': {'index': 'not_analyzed', 'type': 'float'},
	                'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }

    # Creating the CPU and Memory index
    es.indices.create(index = 'ec2cpuutilization' ,body = request_cpu, ignore=[400,404])
    es.indices.create(index = 'ec2memoryutilization' ,body = request_memory, ignore=[400,404])

    s3 = boto3.client('s3')
    client = boto3.resource('s3')
    bucket = bucket_name_env

    # Load CPU and Memory Json files and put into S3
    for key in s3.list_objects(Bucket=bucket,Prefix='AWS/')['Contents']:
        key_var = key['Key']
        value = key_var.partition("/CPUUtilization/")[2].partition("/")[0]
        key_cpu = 'AWS/EC2' + '/' + 'CPUUtilization' + '/' + value + '/' + 'CPUUtilization.json'
        obj_cpu = s3.get_object(Bucket=bucket, Key=key_cpu)
        cpu = json.loads(obj_cpu['Body'].read())
        if len(cpu) > 0 :
            cpu=cpu[0]
            cpu_dict = {
		        "_index": 'ec2cpuutilization',
			    "_type": value,
			    "_id": str(datetime.datetime.now()),
			    "_source": cpu

		    }
        actions_cpu.append(cpu_dict)
        helpers.bulk(es,actions_cpu)
        key_memory = 'AWS/EC2' + '/' + 'CPUUtilization' + '/' + value + '/' + 'MemoryUtilization.json'
        obj_memory = s3.get_object(Bucket=bucket, Key=key_memory)
        memory = json.loads(obj_memory['Body'].read())
        if len(memory) > 0 :
            memory=memory[0]
            memory_dict = {
                "_index": 'ec2memoryutilization',
                "_type": value,
                "_id": str(datetime.datetime.now()),
                "_source": memory
                }
            actions_memory.append(memory_dict)
        helpers.bulk(es,actions_memory)
