### This script will delete all the AMI's and its attached snapshots based on their
### Delete on date tag.

import boto3
import datetime
import os

accountNumber = os.environ['AWS_ACCOUNT_ID']

ec = boto3.client('ec2', 'ap-southeast-1')

def lambda_handler(event, context):
  resource_arn = 'arn:aws:lambda:ap-southeast-1:'+ accountNumber +':function:lampwebcleanupoldbackups'
  client_lambda = boto3.client('lambda')
  client_lambda.tag_resource(Resource=resource_arn, Tags={'App-code':'PWEB','PC-code':'259S'})
  imagesResponse = ec.describe_images(
    DryRun=False,
    Owners=[accountNumber],
    Filters=[
      {'Name': 'tag:App-code', 'Values': ['PWEB']},
      {'Name': 'tag:PC-code', 'Values': ['259S']}
    ]
  ).get(
    'Images', []
  )

  amiList = []
  currentDate = datetime.datetime.now().strftime('%m-%d-%Y')

  for image in imagesResponse:
    deleteOn = ''
    for tag in image['Tags']:
      if tag['Key'] == 'DeleteOn':
        deleteOn = tag['Value']
        break
    if deleteOn == '':
      continue
    if deleteOn == currentDate:
      print "\nCleaning up AMI %s" % (image['ImageId'])
      ec.deregister_image(
        DryRun=False,
        ImageId=image['ImageId']
      )
      amiList.append(image['ImageId'])
      snapshots = ec.describe_snapshots(
        DryRun=False,
        OwnerIds=[
          accountNumber
        ],
        Filters=[
          {
            'Name': 'description',
            'Values': [
              '*'+image['ImageId']+'*'
            ]
          }
        ]
      ).get(
        'Snapshots', []
      )
      for snapshot in snapshots:
        print ">>Cleaning up Snapshot %s" % (snapshot['SnapshotId'])
        ec.delete_snapshot(
          DryRun = False,
          SnapshotId = snapshot['SnapshotId']
        )
    else:
      print "\n%s not yet scheduled for cleanup" % (image['ImageId'])
  if len(amiList)==0:
    print "\n\nNo AMIs were deleted"
  else:
    print "\n\n%d AMIs were deleted\nDeleted the following:" %(len(amiList))
    for ami in amiList:
      print ami
