#This script will create ami and tag ami and snapshot

import boto3
import collections
import datetime
import os
import time

ec = boto3.client('ec2')

# Main handler function
def lambda_handler(event, context):

  accountNumber = os.environ['AWS_ACCOUNT_ID']
  retentionDays = int(os.environ['RETENTION_DAYS'])
  resource_arn = 'arn:aws:lambda:ap-southeast-1:'+ accountNumber +':function:lampwebbackupami'
  client_lambda = boto3.client('lambda')
  client_lambda.tag_resource(Resource=resource_arn, Tags={'App-code':'PWEB','PC-code':'259S'})
  # Retriving all PWEB EC2 instances
  reservations = ec.describe_instances(
    Filters=[
      {'Name': 'tag:App-code', 'Values': ['PWEB']},
      {'Name': 'tag:PC-code', 'Values': ['259S']}
    ]
  ).get(
    'Reservations', []
  )

  instances = sum(
    [
      [i for i in r['Instances']]
      for r in reservations
    ], [])

  print "Found %d instances that need backing up" % len(instances)

  #to_tag = collections.defaultdict(list)
  amiList = []
  # For each instance if they have Retention Tag, get the number of days from Instance tag else from lambda parameter
  for instance in instances:
    try:
      retention_days = [
        int(t.get('Value')) for t in instance['Tags']
        if t['Key'] == 'Retention'][0]
    except IndexError:
      retention_days = retentionDays

      create_time = datetime.datetime.now()
      create_fmt = create_time.strftime('%m-%d-%Y-%H-%M-%S')

      for tag in instance['Tags']:
        if tag['Key'] == 'Name':
          amiName = tag['Value']
          break

      nametag = amiName + "-" + "Lambda" + "-" + instance['InstanceId'] + create_fmt

      AMIid = ec.create_image(InstanceId=instance['InstanceId'], Name= nametag, Description="Lambda created AMI of instance " + instance['InstanceId'] + " on " + create_fmt, NoReboot=True, DryRun=False)

      delete_date = datetime.date.today() + datetime.timedelta(days=retention_days)
      delete_fmt = delete_date.strftime('%m-%d-%Y')
      print "Will delete %s AMIs on %s" % (AMIid['ImageId'], delete_fmt)

      ec.create_tags(
        Resources=[AMIid['ImageId']],
        Tags=[
          {'Key': 'DeleteOn', 'Value': delete_fmt},
          {'Key': 'App-code', 'Value': 'PWEB'},
          {'Key': 'PC-code', 'Value': '259S'},
          {'Key': 'Name', 'Value': nametag}
        ]
      )

      # to_tag[retention_days].append(AMIid['ImageId'])

      amiList.append(AMIid['ImageId'])
      print "Retaining AMI %s of instance %s for %d days" % (
        AMIid['ImageId'],
        instance['InstanceId'],
        int(retention_days),
      )

  snapshotMaster = []
  time.sleep(10)
  print amiList
  for ami in amiList:
    print ami
    snapshots = ec.describe_snapshots(
      DryRun=False,
      OwnerIds=[
        accountNumber
      ],
      Filters=[{
        'Name': 'description',
        'Values': [
          '*'+ami+'*'
        ]
      }]
    ).get(
      'Snapshots', []
    )
    print "****************"
    delete_date = datetime.date.today() + datetime.timedelta(days=retention_days)
    delete_fmt = delete_date.strftime('%m-%d-%Y')
    snapnametag = ami + "-" + "Lambda-created"

    for snapshot in snapshots:
      print snapshot['SnapshotId']
      ec.create_tags(
        Resources=[snapshot['SnapshotId']],
        Tags=[
          {'Key': 'DeleteOn', 'Value': delete_fmt},
          {'Key': 'App-code', 'Value': 'PWEB'},
          {'Key': 'PC-code', 'Value': '259S'},
          {'Key': 'Name', 'Value': snapnametag},
        ]
      )
