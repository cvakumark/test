# Collecting metrics for all PWEB ELB's
from __future__ import print_function
import boto3
import json
import datetime
from elasticsearch import Elasticsearch
from elasticsearch import helpers
from aws_requests_auth.aws_auth import AWSRequestsAuth
from elasticsearch import Elasticsearch, RequestsHttpConnection
import requests
import os
from aws_requests_auth import boto_utils
from requests_aws_sign import AWSV4Sign
from boto3 import session
import re
# Intializing variables
session = session.Session()
credentials = session.get_credentials().get_frozen_credentials()
def datetime_convert(o):
    if isinstance(o, datetime.datetime):
        return o.__str__()
now = datetime.datetime.today()
end_time = now.isoformat()
before = now - datetime.timedelta(seconds=900)
start_time = before.isoformat()
elb_name = []
actions = []

# Main function handler
def lambda_handler(event, context):
    aws_account_id = os.environ['AWS_ACCOUNT_ID']
    resource_arn = 'arn:aws:lambda:ap-southeast-1:'+ aws_account_id +':function:lampwebelbmetrics'
    client_lambda = boto3.client('lambda')
    client_lambda.tag_resource(Resource=resource_arn, Tags={'App-code':'PWEB','PC-code':'259S'})
    #Create Authentication
    service = 'es'
    es_url_env = os.environ['ELASTIC_SEARCH_URL']
    es_host = es_url_env
    awsauth = AWSRequestsAuth(
        aws_access_key=credentials.access_key,
        aws_secret_access_key=credentials.secret_key,
        aws_token=credentials.token,
        aws_host=es_host,
        aws_region=session.region_name,
        aws_service=service)
#Create Elastic Search Connection with auth
    es = Elasticsearch(
        hosts=[{'host': es_host, 'port': 80}],
        http_auth=awsauth,
        connection_class=RequestsHttpConnection)

    print(es.info())
    request_BackendConnectionErrors = {
        'mappings': {
            'BackendConnectionErrors': {
                'properties': {
                'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
	            'Maximum': {'index': 'not_analyzed', 'type': 'float'},
	            'Minimum': {'index': 'not_analyzed', 'type': 'float'},
	            'Average': {'index': 'not_analyzed', 'type': 'float'},
	            'Sum': {'index': 'not_analyzed', 'type': 'float'},
	            'SampleCount': {'index': 'not_analyzed', 'type': 'float'},
	            'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_HealthyHostCoun = {
        'mappings': {
            'HealthyHostCoun': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
	                'Maximum': {'index': 'not_analyzed', 'type': 'float'},
	                'Minimum': {'index': 'not_analyzed', 'type': 'float'},
	                'Average': {'index': 'not_analyzed', 'type': 'float'},
	                'Sum': {'index': 'not_analyzed', 'type': 'float'},
	                'SampleCount': {'index': 'not_analyzed', 'type': 'float'},
	                'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_UnHealthyHostCount = {
        'mappings': {
            'UnHealthyHostCount': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
	                'Maximum': {'index': 'not_analyzed', 'type': 'float'},
	                'Minimum': {'index': 'not_analyzed', 'type': 'float'},
	                'Average': {'index': 'not_analyzed', 'type': 'float'},
	                'Sum': {'index': 'not_analyzed', 'type': 'float'},
	                'SampleCount': {'index': 'not_analyzed', 'type': 'float'},
	                'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_RequestCount = {
        'mappings': {
            'RequestCount': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
	                'Maximum': {'index': 'not_analyzed', 'type': 'float'},
	                'Minimum': {'index': 'not_analyzed', 'type': 'float'},
	                'Average': {'index': 'not_analyzed', 'type': 'float'},
	                'Sum': {'index': 'not_analyzed', 'type': 'float'},
	                'SampleCount': {'index': 'not_analyzed', 'type': 'float'},
	                'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_httpcode_backend_five_hundred = {
        'mappings': {
            'RequestCount': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
	                'Maximum': {'index': 'not_analyzed', 'type': 'float'},
	                'Minimum': {'index': 'not_analyzed', 'type': 'float'},
	                'Average': {'index': 'not_analyzed', 'type': 'float'},
	                'Sum': {'index': 'not_analyzed', 'type': 'float'},
	                'SampleCount': {'index': 'not_analyzed', 'type': 'float'},
	                'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_httpcode_backend_two_hyndred = {
        'mappings': {
            'RequestCount': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
	                'Maximum': {'index': 'not_analyzed', 'type': 'float'},
	                'Minimum': {'index': 'not_analyzed', 'type': 'float'},
	                'Average': {'index': 'not_analyzed', 'type': 'float'},
	                'Sum': {'index': 'not_analyzed', 'type': 'float'},
	                'SampleCount': {'index': 'not_analyzed', 'type': 'float'},
	                'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_httpcode_backend_three_hyndred = {
        'mappings': {
            'RequestCount': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
	                'Maximum': {'index': 'not_analyzed', 'type': 'float'},
	                'Minimum': {'index': 'not_analyzed', 'type': 'float'},
	                'Average': {'index': 'not_analyzed', 'type': 'float'},
	                'Sum': {'index': 'not_analyzed', 'type': 'float'},
	                'SampleCount': {'index': 'not_analyzed', 'type': 'float'},
	                'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_httpcode_backend_four_hyndred = {
        'mappings': {
            'RequestCount': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
	                'Maximum': {'index': 'not_analyzed', 'type': 'float'},
	                'Minimum': {'index': 'not_analyzed', 'type': 'float'},
	                'Average': {'index': 'not_analyzed', 'type': 'float'},
	                'Sum': {'index': 'not_analyzed', 'type': 'float'},
	                'SampleCount': {'index': 'not_analyzed', 'type': 'float'},
	                'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_elbsurgequeuelength = {
        'mappings': {
            'RequestCount': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
	                'Maximum': {'index': 'not_analyzed', 'type': 'float'},
	                'Minimum': {'index': 'not_analyzed', 'type': 'float'},
	                'Average': {'index': 'not_analyzed', 'type': 'float'},
	                'Sum': {'index': 'not_analyzed', 'type': 'float'},
	                'SampleCount': {'index': 'not_analyzed', 'type': 'float'},
	                'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    request_elblatency = {
        'mappings': {
            'RequestCount': {
                'properties': {
                    'Timestamp': {'index': 'not_analyzed', 'type': 'string'},
	                'Maximum': {'index': 'not_analyzed', 'type': 'float'},
	                'Minimum': {'index': 'not_analyzed', 'type': 'float'},
	                'Average': {'index': 'not_analyzed', 'type': 'float'},
	                'Sum': {'index': 'not_analyzed', 'type': 'float'},
	                'SampleCount': {'index': 'not_analyzed', 'type': 'float'},
	                'Unit': {'index': 'not_analyzed', 'type': 'string'},

                }}}

    }
    # Creating the Indexs for ELB dashboard.
    es.indices.create(index = 'elbbackendconnectionerrors' ,body = request_BackendConnectionErrors, ignore=[400,404])
    es.indices.create(index = 'elbhealthyhostcoun' ,body = request_HealthyHostCoun, ignore=[400,404])
    es.indices.create(index = 'elbunhealthyhostcount' ,body = request_UnHealthyHostCount, ignore=[400,404])
    es.indices.create(index = 'elbrequestcount' ,body = request_RequestCount, ignore=[400,404])
    es.indices.create(index = 'elbhttpcodebackendfivehundred' ,body = request_httpcode_backend_five_hundred, ignore=[400,404])
    es.indices.create(index = 'elbhttpcodebackendtwohundred' ,body = request_httpcode_backend_two_hyndred, ignore=[400,404])
    es.indices.create(index = 'elbhttpcodebackendthreehundred' ,body = request_httpcode_backend_three_hyndred, ignore=[400,404])
    es.indices.create(index = 'elbhttpcodebackendfourhundred' ,body = request_httpcode_backend_four_hyndred, ignore=[400,404])
    es.indices.create(index = 'elbsurgequeuelength' ,body = request_elbsurgequeuelength, ignore=[400,404])
    es.indices.create(index = 'elblatency' ,body = request_elblatency, ignore=[400,404])
    # Get all PWEB ELB's
    client = boto3.client('elb')
    cloudwatch = boto3.client('cloudwatch')
    response = client.describe_load_balancers()
    for elb in range(len(response.get('LoadBalancerDescriptions'))):
      load_balancer_name = response.get('LoadBalancerDescriptions')[elb].get('LoadBalancerName')
      elb_name.append(load_balancer_name)
    r = re.compile(r"^.*(pweb).*$")
    pweb_elb_name = filter(r.match, elb_name)
    print(pweb_elb_name)

    # Push BackendConnectionErrors data from ELB's into ES indexes.
    for pweb_elb in pweb_elb_name:
        try:
            response_BackendConnectionErrors = cloudwatch.get_metric_statistics(
                Namespace='AWS/ELB',MetricName='BackendConnectionErrors',
                StartTime=start_time,
                EndTime=end_time, Period=900,
                Statistics=['Maximum','Minimum','Average','Sum','SampleCount'], Unit='Count',
                Dimensions=[{'Name': 'LoadBalancerName', 'Value': pweb_elb}])
            BackendConnectionErrors_metric = json.dumps(response_BackendConnectionErrors['Datapoints'],default = datetime_convert)
            BackendConnectionErrors_metric = BackendConnectionErrors_metric.strip('[]')
            if len(BackendConnectionErrors_metric) > 0 :
                BackendConnectionErrors_dict = {
                    "_index": 'elbbackendconnectionerrors',
                    "_type": pweb_elb,
                    "_id": str(datetime.datetime.now()),
                    "_source": BackendConnectionErrors_metric

                }
            actions.append(BackendConnectionErrors_dict)
            helpers.bulk(es,actions)
        except:
            pass

    # Push HealthyHostCoun data from ELB's into ES indexes.
    for pweb_elb in pweb_elb_name:
        try:
            response_HealthyHostCount = cloudwatch.get_metric_statistics(
                Namespace='AWS/ELB',MetricName='HealthyHostCoun',
                StartTime=datetime.datetime.now() - datetime.timedelta(seconds=900),
                EndTime=datetime.datetime.now(), Period=900,
                Statistics=['Maximum','Minimum','Average','Sum','SampleCount'], Unit='Count',
                Dimensions=[{'Name': 'LoadBalancerName', 'Value': pweb_elb}])
            HealthyHostCount_metric = json.dumps(response_HealthyHostCount['Datapoints'],default = datetime_convert)
            HealthyHostCount_metric = HealthyHostCount_metric.strip('[]')
            if len(HealthyHostCount_metric) > 0 :
                HealthyHostCount_dict = {
                    "_index": 'elbhealthyhostcoun',
                    "_type": pweb_elb,
                    "_id": str(datetime.datetime.now()),
                    "_source": HealthyHostCount_metric,

                }
            actions.append(HealthyHostCount_dict)
            helpers.bulk(es,actions)
        except:
            pass
    # Push UnHealthyHostCount data from ELB's into ES indexes.
    for pweb_elb in pweb_elb_name:
        try:
            response_UnHealthyHostCount = cloudwatch.get_metric_statistics(
                Namespace='AWS/ELB',MetricName='UnHealthyHostCount',
                StartTime=start_time,
                EndTime=end_time, Period=900,
                Statistics=['Maximum','Minimum','Average','Sum','SampleCount'], Unit='Count',
                Dimensions=[{'Name': 'LoadBalancerName', 'Value': pweb_elb}])
            UnHealthyHostCount_metric = json.dumps(response_UnHealthyHostCount['Datapoints'],default = datetime_convert)
            UnHealthyHostCount_metric = UnHealthyHostCount_metric.strip('[]')
            if len(UnHealthyHostCount_metric) > 0 :
                UnHealthyHostCount_dict = {
                    "_index": 'elbunhealthyhostcount',
                    "_type": pweb_elb,
                    "_id": str(datetime.datetime.now()),
                    "_source": UnHealthyHostCount_metric,

                }
                print(UnHealthyHostCount_dict)
            actions.append(UnHealthyHostCount_dict)
            helpers.bulk(es,actions)
        except:
            pass
    # Push RequestCount data from ELB's into ES indexes.
    for pweb_elb in pweb_elb_name:
        try:
            response_RequestCount = cloudwatch.get_metric_statistics(
                Namespace='AWS/ELB',MetricName='RequestCount',
                StartTime=start_time,
                EndTime=end_time, Period=900,
                Statistics=['Maximum','Minimum','Average','Sum','SampleCount'], Unit='Count',
                Dimensions=[{'Name': 'LoadBalancerName', 'Value': pweb_elb}])
            RequestCount_metric = json.dumps(response_RequestCount['Datapoints'],default = datetime_convert)
            RequestCount_metric = RequestCount_metric.strip('[]')
            if len(RequestCount_metric) > 0 :
                RequestCount_dict = {
                    "_index": 'elbrequestcount',
                    "_type": pweb_elb,
                    "_id": str(datetime.datetime.now()),
                    "_source": RequestCount_metric

                }
            actions.append(RequestCount_dict)
            helpers.bulk(es,actions)
        except:
            pass
    for pweb_elb in pweb_elb_name:
        try:
            response_httpcode_backend = cloudwatch.get_metric_statistics(
                Namespace='AWS/ELB',MetricName='HTTPCode_Backend_5XX',
                StartTime=start_time,
                EndTime=end_time, Period=900,
                Statistics=['Maximum','Minimum','Average','Sum','SampleCount'], Unit='Count',
                Dimensions=[{'Name': 'LoadBalancerName', 'Value': pweb_elb}])
            httpcode_backend_metric = json.dumps(response_httpcode_backend['Datapoints'],default = datetime_convert)
            httpcode_backend_metric = httpcode_backend_metric.strip('[]')
            if len(httpcode_backend_metric) > 0 :
                httpcode_backend_dict = {
                    "_index": 'elbhttpcodebackendfivehundred',
                    "_type": pweb_elb,
                    "_id": str(datetime.datetime.now()),
                    "_source": httpcode_backend_metric

                }
            actions.append(httpcode_backend_dict)
            helpers.bulk(es,actions)
        except:
            pass
    for pweb_elb in pweb_elb_name:
        try:
            response_httpcode_backend_two_hyndred = cloudwatch.get_metric_statistics(
                Namespace='AWS/ELB',MetricName='HTTPCode_Backend_2XX',
                StartTime=start_time,
                EndTime=end_time, Period=900,
                Statistics=['Maximum','Minimum','Average','Sum','SampleCount'], Unit='Count',
                Dimensions=[{'Name': 'LoadBalancerName', 'Value': pweb_elb}])
            httpcode_backend_two_hyndred_metric = json.dumps(response_httpcode_backend_two_hyndred['Datapoints'],default = datetime_convert)
            httpcode_backend_two_hyndred_metric = httpcode_backend_two_hyndred_metric.strip('[]')
            if len(httpcode_backend_two_hyndred_metric) > 0 :
                httpcode_backend_two_hyndred_dict = {
                    "_index": 'elbhttpcodebackendtwohundred',
                    "_type": pweb_elb,
                    "_id": str(datetime.datetime.now()),
                    "_source": httpcode_backend_two_hyndred_metric
                }
            actions.append(httpcode_backend_two_hyndred_dict)
            helpers.bulk(es,actions)
        except:
            pass
    for pweb_elb in pweb_elb_name:
        try:
            response_httpcode_backend_three_hyndred = cloudwatch.get_metric_statistics(
                Namespace='AWS/ELB',MetricName='HTTPCode_Backend_3XX',
                StartTime=start_time,
                EndTime=end_time, Period=900,
                Statistics=['Maximum','Minimum','Average','Sum','SampleCount'], Unit='Count',
                Dimensions=[{'Name': 'LoadBalancerName', 'Value': pweb_elb}])
            httpcode_backend_three_hyndred_metric = json.dumps(response_httpcode_backend_three_hyndred['Datapoints'],default = datetime_convert)
            httpcode_backend_three_hyndred_metric = httpcode_backend_three_hyndred_metric.strip('[]')
            if len(httpcode_backend_two_hyndred_metric) > 0 :
                httpcode_backend_three_hyndred_dict = {
                    "_index": 'elbhttpcodebackendthreehundred',
                    "_type": pweb_elb,
                    "_id": str(datetime.datetime.now()),
                    "_source": httpcode_backend_three_hyndred_metric

                }
            actions.append(httpcode_backend_three_hyndred_dict)
            helpers.bulk(es,actions)
        except:
            pass
    for pweb_elb in pweb_elb_name:
        try:
            response_httpcode_backend_four_hyndred = cloudwatch.get_metric_statistics(
                Namespace='AWS/ELB',MetricName='HTTPCode_Backend_4XX',
                StartTime=start_time,
                EndTime=end_time, Period=900,
                Statistics=['Maximum','Minimum','Average','Sum','SampleCount'], Unit='Count',
                Dimensions=[{'Name': 'LoadBalancerName', 'Value': pweb_elb}])
            httpcode_backend_four_hyndred_metric = json.dumps(response_httpcode_backend_four_hyndred['Datapoints'],default = datetime_convert)
            httpcode_backend_four_hyndred_metric = httpcode_backend_four_hyndred_metric.strip('[]')
            if len(httpcode_backend_four_hyndred_metric) > 0 :
                httpcode_backend_four_hyndred_dict = {
                    "_index": 'elbhttpcodebackendfourhundred',
                    "_type": pweb_elb,
                    "_id": str(datetime.datetime.now()),
                    "_source": httpcode_backend_four_hyndred_metric

                }
            actions.append(httpcode_backend_four_hyndred_dict)
            helpers.bulk(es,actions)
        except:
            pass
    for pweb_elb in pweb_elb_name:
        try:
            response_SurgeQueueLength = cloudwatch.get_metric_statistics(
                Namespace='AWS/ELB',MetricName='SurgeQueueLength',
                StartTime=start_time,
                EndTime=end_time, Period=900,
                Statistics=['Maximum','Minimum','Average','Sum','SampleCount'], Unit='Count',
                Dimensions=[{'Name': 'LoadBalancerName', 'Value': pweb_elb}])
            SurgeQueueLength_metric = json.dumps(response_SurgeQueueLength['Datapoints'],default = datetime_convert)
            SurgeQueueLength_metric = SurgeQueueLength_metric.strip('[]')
            if len(SurgeQueueLength_metric) > 0 :
                SurgeQueueLength_dict = {
                    "_index": 'elbsurgequeuelength',
                    "_type": pweb_elb,
                    "_id": str(datetime.datetime.now()),
                    "_source": SurgeQueueLength_metric
                    
                }
            actions.append(SurgeQueueLength_dict)
            helpers.bulk(es,actions)
        except:
            pass
    for pweb_elb in pweb_elb_name:
        try:
            response_Latency = cloudwatch.get_metric_statistics(
                Namespace='AWS/ELB',MetricName='Latency',
                StartTime=start_time,
                EndTime=end_time, Period=900,
                Statistics=['Maximum','Minimum','Average','Sum','SampleCount'], Unit='Count',
                Dimensions=[{'Name': 'LoadBalancerName', 'Value': pweb_elb}])
            Latency_metric = json.dumps(response_Latency['Datapoints'],default = datetime_convert)
            Latency_metric = Latency_metric.strip('[]')
            if len(Latency_metric) > 0 :
                Latency_dict = {
                    "_index": 'elblatency',
                    "_type": pweb_elb,
                    "_id": str(datetime.datetime.now()),
                    "_source": Latency_metric
                    
                }
            actions.append(Latency_dict)
            helpers.bulk(es,actions)
        except:
            pass