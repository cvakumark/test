#!/bin/bash

region_name=$5
ami_id=$1
appcode=$2
pccode=$3
name=$4
temp_snapshot_id=''
snapshots=( $(aws ec2 describe-images --image-ids $ami_id --region $region_name  --output text --query 'Images[*].BlockDeviceMappings[*].Ebs.SnapshotId') )
snapshots_length=${#snapshots[@]}

echo "Taging Snapshot"

for (( i=0; i<$snapshots_length; i++ )); do
    temp_snapshot_id=${snapshots[$i]}
    echo "Taging Snapshot: "$temp_snapshot_id
    aws ec2 create-tags --region $region_name --resource $temp_snapshot_id --tags Key=App-code,Value=$appcode
    aws ec2 create-tags --region $region_name --resource $temp_snapshot_id --tags Key=PC-code,Value=$pccode
    aws ec2 create-tags --region $region_name --resource $temp_snapshot_id --tags Key=Name,Value=$name
done
