-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_CORPORATE_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_CN_CORPORATE_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_PERSONAL_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_CN_PERSONAL_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_SME_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_CN_SME_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_TREASURES_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_CN_TREASURES_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_CN_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_CORPORATE_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_CN_CORPORATE_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_PERSONAL_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_CN_PERSONAL_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_SME_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_CN_SME_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_TREASURES_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_CN_TREASURES_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_CN_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_CORPORATE_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_CORPORATE_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_IBANKING_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_IBANKING_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PERSONAL_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_PERSONAL_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PERSONAL-ZH_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_PERSONAL-ZH_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PRIVATEBANKING_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_PRIVATEBANKING_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_SME_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_SME_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_TPC_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_TPC_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_TREASURES_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_TREASURES_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_CORPORATE_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_CORPORATE_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_IBANKING_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_IBANKING_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PERSONAL_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_PERSONAL_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PERSONAL-ZH_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_PERSONAL-ZH_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PRIVATEBANKING_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_PRIVATEBANKING_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_SME_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_SME_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_TPC_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_TPC_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_TREASURES_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_TREASURES_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_HK_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_CORPORATE_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_CORPORATE_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_PERSONAL_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_PERSONAL_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_PRIVATEBANKING_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_PRIVATEBANKING_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_SME_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_SME_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_TPC_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_TPC_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_TREASURES_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_TREASURES_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_CORPORATE_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_CORPORATE_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_PERSONAL_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_PERSONAL_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_PRIVATEBANKING_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_PRIVATEBANKING_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_SME_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_SME_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_TPC_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_TPC_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_TREASURES_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_TREASURES_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_ID_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_CORPORATE_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_CORPORATE_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_PERSONAL_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_PERSONAL_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_PRIVATEBANKING_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_PRIVATEBANKING_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_SME_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_SME_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_TPC_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_TPC_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_TREASURES_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_TREASURES_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_CORPORATE_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_CORPORATE_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_PERSONAL_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_PERSONAL_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_PRIVATEBANKING_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_PRIVATEBANKING_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_SME_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_SME_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_TPC_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_TPC_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_TREASURES_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_TREASURES_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IN_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_CORPORATE_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_CORPORATE_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_IB-XSELL_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_IB-XSELL_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_IBANKING_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_IBANKING_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_PERSONAL_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_PERSONAL_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_POSB_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_POSB_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_PRIVATEBANKING_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_PRIVATEBANKING_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_SME_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_SME_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_TPC_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_TPC_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_TREASURES_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_TREASURES_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_VICKERS_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_VICKERS_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_CORPORATE_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_CORPORATE_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_IB-XSELL_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_IB-XSELL_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_IBANKING_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_IBANKING_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_PERSONAL_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_PERSONAL_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_POSB_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_POSB_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_PRIVATEBANKING_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_PRIVATEBANKING_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_SME_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_SME_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_TPC_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_TPC_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_TREASURES_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_TREASURES_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_VICKERS_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_VICKERS_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_SG_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_CORPORATE_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_CORPORATE_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_PERSONAL_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_PERSONAL_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_PRIVATEBANKING_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_PRIVATEBANKING_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_SME_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_SME_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_TPC_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_TPC_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_TREASURES_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_TREASURES_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_CORPORATE_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_CORPORATE_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_PERSONAL_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_PERSONAL_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_PRIVATEBANKING_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_PRIVATEBANKING_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_SME_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_SME_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_TPC_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_TPC_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_TREASURES_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_TREASURES_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_TW_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_GROUP_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_GROUP_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

  

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_GROUP_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_GROUP_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_MASTER_COMPONENT_PREVIEW"
-- -----------------------------------------------------------------------
-- CREATE TABLE "TSNWCONT"."WORKFLOW_MASTER_COMPONENT_PREVIEW"(
--	"COMPONENT_NAME" VARCHAR(256) NOT NULL PRIMARY KEY
-- );

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_MASTER_COMPONENT_PRODUCTION"
-- -----------------------------------------------------------------------
CREATE TABLE `TSNWCONT`.`WORKFLOW_MASTER_COMPONENT_PRODUCTION`(
	`COMPONENT_NAME` VARCHAR(256) NOT NULL PRIMARY KEY
);

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IBA_PRODUCTION"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IBA_PRODUCTION` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);

-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IBA_PREVIEW"
-- -----------------------------------------------------------------------

CREATE TABLE `TSNWCONT`.`WORKFLOW_IBA_PREVIEW` (
	`COMPONENT_NAME` VARCHAR(256) NOT NULL,
	`LOCALE` VARCHAR(256) NOT NULL,
	`ACCESSTIME` DATETIME NOT NULL,
	`PAGEURL` VARCHAR(500) NOT NULL,
	`DCRPATH` VARCHAR(500) NOT NULL,
	PRIMARY KEY(`COMPONENT_NAME`,`PAGEURL`,`DCRPATH`)
);
  