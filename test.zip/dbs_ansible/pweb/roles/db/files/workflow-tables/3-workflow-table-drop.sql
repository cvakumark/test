-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_CORPORATE_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_CN_CORPORATE_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_PERSONAL_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_CN_PERSONAL_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_SME_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_CN_SME_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_TREASURES_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_CN_TREASURES_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_CN_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_CORPORATE_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_CN_CORPORATE_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_PERSONAL_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_CN_PERSONAL_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_SME_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_CN_SME_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_TREASURES_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_CN_TREASURES_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_CN_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_CN_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_CORPORATE_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_CORPORATE_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_IBANKING_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_IBANKING_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PERSONAL_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_PERSONAL_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PERSONAL-ZH_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_PERSONAL-ZH_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PRIVATEBANKING_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_PRIVATEBANKING_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_SME_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_SME_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_TPC_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_TPC_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_TREASURES_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_TREASURES_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_CORPORATE_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_CORPORATE_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_IBANKING_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_IBANKING_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PERSONAL_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_PERSONAL_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PERSONAL-ZH_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_PERSONAL-ZH_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PRIVATEBANKING_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_PRIVATEBANKING_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_SME_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_SME_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_TPC_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_TPC_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_TREASURES_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_TREASURES_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_HK_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_HK_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_CORPORATE_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_CORPORATE_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_PERSONAL_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_PERSONAL_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_PRIVATEBANKING_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_PRIVATEBANKING_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_SME_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_SME_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_TPC_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_TPC_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_TREASURES_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_TREASURES_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_CORPORATE_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_CORPORATE_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_PERSONAL_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_PERSONAL_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_PRIVATEBANKING_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_PRIVATEBANKING_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_SME_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_SME_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_TPC_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_TPC_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_TREASURES_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_TREASURES_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_ID_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_ID_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_CORPORATE_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_CORPORATE_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_PERSONAL_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_PERSONAL_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_PRIVATEBANKING_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_PRIVATEBANKING_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_SME_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_SME_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_TPC_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_TPC_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_TREASURES_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_TREASURES_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_CORPORATE_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_CORPORATE_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_PERSONAL_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_PERSONAL_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_PRIVATEBANKING_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_PRIVATEBANKING_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_SME_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_SME_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_TPC_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_TPC_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_TREASURES_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_TREASURES_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_IN_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_IN_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_CORPORATE_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_CORPORATE_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_IB-XSELL_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_IB-XSELL_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_IBANKING_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_IBANKING_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_PERSONAL_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_PERSONAL_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_POSB_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_POSB_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_PRIVATEBANKING_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_PRIVATEBANKING_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_SME_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_SME_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_TPC_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_TPC_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_TREASURES_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_TREASURES_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_VICKERS_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_VICKERS_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_CORPORATE_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_CORPORATE_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_IB-XSELL_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_IB-XSELL_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_IBANKING_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_IBANKING_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_PERSONAL_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_PERSONAL_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_POSB_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_POSB_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_PRIVATEBANKING_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_PRIVATEBANKING_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_SME_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_SME_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_TPC_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_TPC_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_TREASURES_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_TREASURES_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_VICKERS_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_VICKERS_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_SG_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_SG_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_CORPORATE_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_CORPORATE_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_PERSONAL_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_PERSONAL_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_PRIVATEBANKING_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_PRIVATEBANKING_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_SME_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_SME_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_TPC_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_TPC_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_TREASURES_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_TREASURES_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_PRODUCTION"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_PRODUCTION`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_CORPORATE_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_CORPORATE_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_PERSONAL_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_PERSONAL_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_PRIVATEBANKING_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_PRIVATEBANKING_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_SME_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_SME_PREVIEW`;
-- -----------------------------------------------------------------------
-- DDL Statements for table "TSNWCONT"."WORKFLOW_TW_TPC_PREVIEW"
-- -----------------------------------------------------------------------
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_TPC_PREVIEW`;
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_TREASURES_PREVIEW`;
DROP TABLE `TSNWCONT`.`WORKFLOW_TW_PREVIEW`;
DROP TABLE `TSNWCONT`.`WORKFLOW_GROUP_PRODUCTION`;
DROP TABLE `TSNWCONT`.`WORKFLOW_GROUP_PREVIEW`;
DROP TABLE `TSNWCONT`.`WORKFLOW_IBA_PRODUCTION`;
DROP TABLE `TSNWCONT`.`WORKFLOW_IBA_PREVIEW`;