DROP DATABASE IF EXISTS LSDSDB;
DROP DATABASE IF EXISTS LSCSDB;
DROP USER 'pweblsuser';

-- not supporting in the RDS MYSQL version. Available in latest version of MYSQL
-- DROP USER IF EXISTS 'pweblsuser'@'%' ;
