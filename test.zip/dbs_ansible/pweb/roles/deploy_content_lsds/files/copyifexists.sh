#!/bin/bash

src=$1
dest=$2
if [[ -d $src ]]; then
    if [[ $dest == *".ear"* ]]; then
        eardirectory=`echo $dest | sed -e 's/'".ear"'/\n/g' | head -1`
        eardirectory=$eardirectory".ear"
        if [[ -d $dest ]]; then
            echo "Ear Destination directory $dest exists"
            cp -r $src/* $dest
            echo "Copy completed"
        elif [[ -d $eardirectory ]]; then
            echo "Ear directory $eardirectory exists"
            mkdir --parents $dest
            cp -r $src/* $dest
            echo "Directory created and Copy completed"
        else
            echo "Ear directory $eardirectory does not exist"
        fi
    else
        if [[ -d $dest ]]; then
            echo "Destination directory $dest exists"
        else
            mkdir --parents $dest
            echo "Made directory with parents $dest"
        fi
        cp -r $src/* $dest
        echo "Copy completed"
    fi
fi