#!/bin/sh
# SCRIPT NAME: iscd_redhat_os.sh
# IM Version: 5.0
# Updated by:
#
#

# define variables
LOG_DIR=/var/tmp/oslix/ISCD-OS
DATE=`date +%d-%m-%y`
OH_NO=67
ROOT_UID=0
hc="ISCD.OS.`hostname`.`date '+%d.%b.%Y.%H.%M'`.html"
tdir=/var/tmp/oslix/ISCD-OS/tmp
UNAME=`uname`
SUDO=/etc/sudoers
HOSTNAME="`hostname` | cut -d . -f1"
# check if root
echo " "
echo "Checking root access"
if [ "$UID" -ne "$ROOT_UID" ]
then
  echo "Error: Must be root to run this script"
  exit $OH_NO
  else
  echo -e "\033[7mRoot Access verified\033[0m"
fi

# Checking System Platform
echo " "
echo "Checking your platform"
if [ "$UNAME" != Linux ]
        then
        echo "This is for Redhat Linux only"
        exit
        else
        echo -e "\033[7mPlatform: $UNAME\033[0m"
fi

# Checking output directory
echo " "
echo "Checking output directory"
if [  -d /var/tmp/oslix/ISCD-OS/tmp ]
        then
        echo -e "\033[7mOutput directory is /var/tmp/oslix/ISCD-OS\033[0m"
else
        mkdir -m 755 -p /var/tmp/oslix/ISCD-OS/tmp
        echo -e "\033[7mOutput directory is /var/tmp/oslix/ISCD-OS\033[0m"
fi
hostname > $TDIR/hostname
VALUE1=`rpm -qa | grep tectia`
VALUE2=`grep -i hybe $TDIR/hostname`
if [ -n "$VALUE1" ] ; then TYPE="TECTIA"
elif [ -n "$VALUE2" ] ; then TYPE="NODE"
elif [ -z "$VALUE2" ] ; then TYPE="NORM"
fi

sysinfo ()
{
echo " "
echo " "
echo "1.Hardening will be performed by IBM Support"
echo "2.Verification will be performed by IBM Security Team."
echo "3.The duly completed and signed-off IM will be kept by the system owner for filing and future reference by DBS/IBM reviewers."
echo "4.Each setting's current value must be recorded here."
echo "5.Justification(s) for deviations from the IM values must be documented under the Remarks column."
echo "6.All deviations must be raised using the DBS Deviation Form."
echo "7.Mandatory Deviations (settings in Section 1 of the IM doc) must have BU&#39;s MD and Head DBS ISS approval."
echo " "
echo " "

}
function DrawHtmlFileHead {
  FORMAT="$1"
  subnet=$(ifconfig -a | grep -i `hostname -i | awk '{print $1}'` | awk '{print $4}')
if [ "$FORMAT" == "SETTINGS" ]
then
  echo "<html>" > $LOG_DIR/$hc
  echo "<style type=text/css>" >> $LOG_DIR/$hc
  echo "td { border-bottom:1px solid #D8D8D8; } </style>" >> $LOG_DIR/$hc
  echo "<body>" >> $LOG_DIR/$hc
  echo "<table border=2 cellspacing='2' cellpadding='3' style='table-layout:fixed; width:100%;" >> $LOG_DIR/$hc
  echo "     font-size:8.0pt; font-family:Verdana; border-collapse:collapse float:left' >" >> $LOG_DIR/$hc
  echo "     <col width=24%><col width=30%><col width=40%><col width=15%>" >> $LOG_DIR/$hc
  printf "%s%s%s\n" "<tr><td bgcolor="ccffff" colspan=4> <br><b><center> ISCD-IM for Red Hat Linux Server </center></b><br> </td></tr>" >> $LOG_DIR/$hc
  printf "%s%s\n" "<tr><td colspan=1><pre><b>Version - Release Levels/applicable to: </td>" >> $LOG_DIR/$hc
  printf "                                      <td colspan=3>  RedHat Enterprise Linux Ver 5" >> $LOG_DIR/$hc
  printf "<br />                                        RedHat Enterprise Linux Ver 6" >> $LOG_DIR/$hc
  printf "<br />                                        RedHat Enterprise Linux Ver 7" >> $LOG_DIR/$hc
  printf "<br />        <br />                          F-Secure SSH Server, Reflection for Secure IT Server" >> $LOG_DIR/$hc
  printf "<br />OpenSSH Server installed in Redhat Enterprise Linux (RHEL) and IBM Virtual I/O Server  2.x (VIO) ," >> $LOG_DIR/$hc
  printf "<br />Tectia SSH Server, Attachmate Reflection for Secure IT UNIX Server, Attachmate Reflection for Secure IT Windows Server" >> $LOG_DIR/$hc
  printf "<br />Sudo running on UNIX operating systems (including AIX, SUN Solaris, VMware Infrastructure, VMware ESX and Linux)</td>" >> $LOG_DIR/$hc


  printf "%s%s\n" "<tr><td colspan=1><pre><b>Instructions: </td>" >> $LOG_DIR/$hc
  printf "%s%s\n" "<td colspan=3><pre>" >> $LOG_DIR/$hc
  sysinfo >> $LOG_DIR/$hc
  printf "</pre></td></tr>\n" >> $LOG_DIR/$hc
  printf "%s%s\n" "<tr><td colspan=4><pre><b><c>Server&#39;s General Information <c></pre></td></tr>" >> $LOG_DIR/$hc
  printf "%s%s\n" "<tr><td colspan=4><pre>Application / Project Name:  </td></tr>" >> $LOG_DIR/$hc
  printf "%s%s\n" "<tr><td colspan=1><pre>Host/Device Name: $HOSTNAME  </td>" >> $LOG_DIR/$hc
   printf "<td colspan=1>       IP Address(es): `hostname -i | awk '{print $1}'`" >> $LOG_DIR/$hc
    printf "<td colspan=2>      Subnet masks(s): $subnet " >> $LOG_DIR/$hc
        printf "</pre></td></tr>\n" >> $LOG_DIR/$hc
        printf "%s%s\n" "<tr><td colspan=2>Operating System: `cat /etc/redhat-release`  </td>" >> $LOG_DIR/$hc
        printf "<td colspan=2>OS Version : `uname -a` " >> $LOG_DIR/$hc
        printf "</pre></td></tr>\n" >> $LOG_DIR/$hc

  printf "<tr><td colspan=4><br><b>Check started at: `date`</b></td></tr>\n" >> $LOG_DIR/$hc
elif [ "$FORMAT" == "HEALTHCHECK" ]
then
  echo "<table border=2 cellspacing='2' cellpadding='3' style='table-layout:fixed; width:100%;" >> $LOG_DIR/$hc
  echo "     font-size:8.0pt; font-family:Verdana; border-collapse:collapse float:left' >" >> $LOG_DIR/$hc
  echo "     <col width=20%><col width=30%><col width=15%><col width=25%>" >> $LOG_DIR/$hc
  elif [ "$FORMAT" == "OTHER_SETTINGS" ]
then
  echo "<table border=2 cellspacing='2' cellpadding='3' style='table-layout:fixed; width:100%;" >> $LOG_DIR/$hc
  echo "     font-size:8.0pt; font-family:Verdana; border-collapse:collapse float:left' >" >> $LOG_DIR/$hc
  echo "     <col width=20%><col width=30%><col width=15%><col width=25%>" >> $LOG_DIR/$hc
  elif [ "$FORMAT" == "PROCESSCONTROL" ]
then
  echo "<table border=2 cellspacing='2' cellpadding='3' style='table-layout:fixed; width:100%;" >> $LOG_DIR/$hc
  echo "     font-size:8.0pt; font-family:Verdana; border-collapse:collapse float:left' >" >> $LOG_DIR/$hc
  echo "     <col width=20%><col width=30%><col width=15%><col width=25%>" >> $LOG_DIR/$hc
elif [ "$FORMAT" == "PROCESS" ]
then
  echo "<table border=2 cellspacing='2' cellpadding='3' style='table-layout:fixed; width:100%;" >> $LOG_DIR/$hc
  echo "     font-size:8.0pt; font-family:Verdana; border-collapse:collapse float:left' >" >> $LOG_DIR/$hc
  echo "     <col width=90%>" >> $LOG_DIR/$hc
elif [ "$FORMAT" == "DOCCONTROL" ]
then
  echo "<table border=2 cellspacing='2' cellpadding='3' style='table-layout:fixed; width:100%;" >> $LOG_DIR/$hc
  echo "     font-size:8.0pt; font-family:Verdana; border-collapse: collapse float:left' >" >> $LOG_DIR/$hc
  echo "     <col width=20%><col width=40%><col width=40%>" >> $LOG_DIR/$hc
elif [ "$FORMAT" == "DOCCONTROL1" ]
then
  echo "<table border=2 cellspacing='2' cellpadding='3' style='table-layout:fixed; width:100%;" >> $LOG_DIR/$hc
  echo "     font-size:8.0pt; font-family:Verdana; border-collapse: collapse float:left' >" >> $LOG_DIR/$hc
  echo "     <col width=100%>" >> $LOG_DIR/$hc
elif [ "$FORMAT" == "EXEPTION" ]
then
  echo "<table border=2 cellspacing='2' cellpadding='2' style='table-layout:fixed; width:100%;" >> $LOG_DIR/$hc
  echo "     font-size:8.0pt; font-family:Verdana; border-collapse: collapse float:left' >" >> $LOG_DIR/$hc
  echo "     <col width=30%><col width=70%>" >> $LOG_DIR/$hc

 elif [ "$FORMAT" == "CLUSTECH" ]
then
  echo "<table border=2 cellspacing='2' cellpadding='4' style='table-layout:fixed; width:100%;" >> $LOG_DIR/$hc
  echo "     font-size:8.0pt; font-family:Verdana; border-collapse: collapse float:left' >" >> $LOG_DIR/$hc
  echo "     <col width=20%><col width=20%><col width=30%><col width=30%>" >> $LOG_DIR/$hc
fi
return 0
}

function DrawPERptHead {
        #set -o xtrace                        # Turn on "tracing"
    head_cap="$1"         # section caption
    printf "%s%s%s\n" "<tr><td colspan=4><br><b>" "$head_cap" "</b></td></tr>"  >> $LOG_DIR/$hc
    echo "<tr bgcolor="#C0C0C0" >" >> $LOG_DIR/$hc
    echo "      <td width='20%'> System Value Parameter </td>" >> $LOG_DIR/$hc
    echo "      <td width='20%'> Required Setting </td>" >> $LOG_DIR/$hc
    echo "      <td width='30%'> Remarks </td>" >> $LOG_DIR/$hc
        echo "      <td width='30%'> <u>Mitigation: </u></td>" >> $LOG_DIR/$hc
    echo "            </tr>" >> $LOG_DIR/$hc
  return 0
}


function DrawSecRptHead {
        #set -o xtrace                        # Turn on "tracing"
    head_cap="$1"         # section caption
    printf "%s%s%s\n" "<tr><td colspan=4><br><b>" "$head_cap" "</b></td></tr>"  >> $LOG_DIR/$hc
    echo "<tr BGCOLOR='ccffff''>" >> $LOG_DIR/$hc
    echo "      <td width='20%'> System Value/ Parameter </td>" >> $LOG_DIR/$hc
    echo "      <td width='30%'> DBS-IBM Agreed Setting </td>" >> $LOG_DIR/$hc
    echo "      <td width='30%'> Current Setting </td>" >> $LOG_DIR/$hc
    echo "      <td width='20%'> Remarks </td>" >> $LOG_DIR/$hc
    echo "            </tr>" >> $LOG_DIR/$hc
  return 0
}
function DrawOSFIPHead {
        #set -o xtrace                        # Turn on "tracing"
    head_cap="$1"         # section caption
    printf "%s%s%s\n" "<tr><td colspan=5><br><b>" "$head_cap" "</b></td></tr>"  >> $LOG_DIR/$hc
    echo "<tr BGCOLOR='ccffff''>" >> $LOG_DIR/$hc
    echo "      <td width='10%'> System Value/Parameter </td>" >> $LOG_DIR/$hc
    echo "      <td width='10%'> DBS-IBM Agreed to Setting </td>" >> $LOG_DIR/$hc
    echo "      <td width='10%'> "How-to" </td>" >> $LOG_DIR/$hc
    echo "      <td width='10%'> Current Setting </td>" >> $LOG_DIR/$hc
    echo "      <td width='10%'> Remarks </td>" >> $LOG_DIR/$hc
    echo "            </tr>" >> $LOG_DIR/$hc
  return 0
}
function DrawHCRptHead {
        #set -o xtrace                        # Turn on "tracing"
    head_cap="$1"         # section caption
    printf "%s%s%s\n" "<tr><td colspan=4><br><b>" "$head_cap" "</b></td></tr>"  >> $LOG_DIR/$hc
    echo "<tr BGCOLOR='ccffff''>" >> $LOG_DIR/$hc
    echo "      <td width='20%'> Requirement </td>" >> $LOG_DIR/$hc
    echo "      <td width='30%'> Description </td>" >> $LOG_DIR/$hc
    echo "      <td width='30%'> ISCD IM Reference </td>" >> $LOG_DIR/$hc
    echo "      <td width='20%'> Specific Tests </td>" >> $LOG_DIR/$hc
    echo "            </tr>" >> $LOG_DIR/$hc
  return 0
}
function DrawPCHead {
        #set -o xtrace                        # Turn on "tracing"
    head_cap="$1"         # section caption
    printf "%s%s%s\n" "<tr><td colspan=1><br><b>" "$head_cap" "</b></td></tr>"  >> $LOG_DIR/$hc
    echo "<tr BGCOLOR='ccffff''>" >> $LOG_DIR/$hc
    echo "      <td width='100%'> Process Control  </td>" >> $LOG_DIR/$hc
    echo "            </tr>" >> $LOG_DIR/$hc
  return 0
}
function DrawPEHead {
        #set -o xtrace                        # Turn on "tracing"
    head_cap="$1"         # section caption
    printf "%s%s%s\n" "<tr><td colspan=4><br><b>" "$head_cap" "</b></td></tr>"  >> $LOG_DIR/$hc
    echo "<tr BGCOLOR='ccffff''>" >> $LOG_DIR/$hc
    echo "      <td width='30%'> System Value/Parameter </td>" >> $LOG_DIR/$hc
    echo "      <td width='70%'> Exeptions </td>" >> $LOG_DIR/$hc
    echo "            </tr>" >> $LOG_DIR/$hc
    echo "            </tr>" >> $LOG_DIR/$hc
  return 0
}
function DrawDCRpt1Head {
        #set -o xtrace                        # Turn on "tracing"
    head_cap="$1"         # section caption
    printf "%s%s%s\n" "<tr><td colspan=4><br><b>" "$head_cap" "</b></td></tr>"  >> $LOG_DIR/$hc
    echo "<tr bgcolor="#C0C0C0" >" >> $LOG_DIR/$hc
    echo "      <td width='100%'> <b>IBM Global Services -  Section Owner:</b><BR><b>Special Considerations for this section:</b><BR>1 Security administrative and system authority checks will be carried out by IBM on system where Health Checks are applicable and ID management of the systems are performed by IBM.</td>" >> $LOG_DIR/$hc
}
function DrawDCRptHead {
        #set -o xtrace                        # Turn on "tracing"
    head_cap="$1"         # section caption
    printf "%s%s%s\n" "<tr><td colspan=4><br><b>" "$head_cap" "</b></td></tr>"  >> $LOG_DIR/$hc
    echo "<tr bgcolor="#C0C0C0" >" >> $LOG_DIR/$hc
    echo "      <td width='20%'> Date Reviewed </td>" >> $LOG_DIR/$hc
    echo "      <td width='40%'> Name(s) of Individuals </td>" >> $LOG_DIR/$hc
    echo "      <td width='40%'> Review Comments </td>" >> $LOG_DIR/$hc
    echo "            </tr>" >> $LOG_DIR/$hc
  return 0
}
#For HTML Report Output
function DrawItem {
        #set -o xtrace                        # Turn on "tracing"
        item="$1"             # Item Description
        p_set="$2"  # Policy Setting
        c_set="$3"  # Current Setting
        vio="$4"    # violations
        printf "%s%s%s\n" "<tr><td valign='top' align='left'>" "$item" "</td>"  >> $LOG_DIR/$hc
        printf "%s%s%s\n" "<td valign='top' align='left'>" "$p_set" "</td>" >> $LOG_DIR/$hc
        printf "%s%s%s\n" "<td valign='top' align='left' style="word-wrap: break-word">" "$c_set" "</td>" >> $LOG_DIR/$hc
        if [[ "$vio" = "Non-Compliant" ]]
        then
          printf "%s%s%s\n" "<td valign='top' align='left'><font color='ff0000'>" "$vio" "</td></tr>" >> $LOG_DIR/$hc
        elif [[ "$vio" = "Manual Check Required" ]]
        then
          printf "%s%s%s\n" "<td valign='top' align='left'><font color='0000A0'>" "$vio" "</td></tr>" >> $LOG_DIR/$hc
        else
          printf "%s%s%s\n" "<td valign='top' align='left'>" "$vio" "</td>" >> $LOG_DIR/$hc
        fi
  return 0
}



function DrawOSFIP {
        #set -o xtrace                        # Turn on "tracing"
        item="$1"   # System Value/Parameter
        DBSAS="$2"  # DBS-IBM Agreed to Setting
        how_to="$3"  # "How-to"
        CS="$4"    # Current Setting
                rem="$5"    # Remarks
        printf "%s%s%s\n" "<tr><td valign='top' align='left'>" "$item" "</td>"  >> $LOG_DIR/$hc
        printf "%s%s%s\n" "<td valign='top' align='left'>" "$DBSAS" "</td>" >> $LOG_DIR/$hc
        printf "%s%s%s\n" "<td valign='top' align='left' style="word-wrap: break-word">" "$how_to" "</td>" >> $LOG_DIR/$hc
                printf "%s%s%s\n" "<td valign='top' align='left'>" "$CS" "</td>" >> $LOG_DIR/$hc
                printf "%s%s%s\n" "<td valign='top' align='left'>" "$rem" "</td>" >> $LOG_DIR/$hc

  return 0
}
function DrawOutput {
       item="$1"
       printf "%s%s%s\n" "<tr><td valign='top' align='left'>" "$item" "</td></tr>"  >> $LOG_DIR/$hc
    return 0
}
function DrawPE {
        #set -o xtrace                        # Turn on "tracing"
        item="$1"  # System Value
        exeption="$2"  # Exeption
        printf "%s%s%s\n" "<tr><td valign='top' align='left'>" "$item" "</td>"  >> $LOG_DIR/$hc
        printf "%s%s%s\n" "<td valign='top' align='left'>" "$exeption" "</td>" >> $LOG_DIR/$hc
  return 0
}
function DrawControl {
        #set -o xtrace                        # Turn on "tracing"
        item="$1"   # Date reviewed
        name="$2"  # Name of individuals
        remark="$3"  # Remark
        printf "%s%s%s\n" "<tr><td valign='top' align='left'>" "$item" "</td>"  >> $LOG_DIR/$hc
        printf "%s%s%s\n" "<td valign='top' align='left'>" "$name" "</td>" >> $LOG_DIR/$hc
        printf "%s%s%s\n" "<td valign='top' align='left'>" "$remark" "</td></tr>" >> $LOG_DIR/$hc
  return 0
}

echo " "
echo -e "\033[7mStarting to check your system settings..........\033[0m"

#########################################
DrawHtmlFileHead "SETTINGS"
#########################################

################################################################################################
#AD.1
DrawSecRptHead "AD.1 Settings related to Policy or Standards. These items shall be directed to Information Security (Policy Owner) for approval."
################################################################################################

# AD.1.1) Network Access Control Management (DBS ISP 4030) (e.g. FTP, Telnet and etc.)

echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>1.1) <span style="background-color:yellow">Network Access Control Management</span> <span style="background-color:green">(DBS ISP 4030)</span> (e.g. FTP, Telnet and etc.)</b></td></tr>" >> $LOG_DIR/$hc
echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>1.1.1) Network Settings</b></td></tr>" >> $LOG_DIR/$hc

# AD.1.1.1 FTP server

VALUE=`rpm -qa | grep ^ftp`
VALUE1=`grep 'ftp[[:blank:]]*21/udp' /etc/services | cut -c1`
VALUE2=`grep 'ftp[[:blank:]]*21/tcp' /etc/services |cut -c1`
if [ -z "$VALUE" ] && [ "$VALUE1" = "#" ] && [ "$VALUE2" = "#" ] ; then
        VALUE="FTP not installed<BR>$VALUE<BR>Service is disabled"
        VALUE1="grep 'ftp    21/udp' /etc/services<BR>`grep 'ftp[[:blank:]]*21/udp' /etc/services`"
        VALUE2="grep 'ftp    21/tcp' /etc/services<BR>`grep 'ftp[[:blank:]]*21/tcp' /etc/services`"
        status="Compliant"
else
        UDP=`grep 'ftp[[:blank:]]*21/udp' /etc/services`
        TCP=`grep 'ftp[[:blank:]]*21/tcp' /etc/services`
        VALUE1="grep 'ftp    21/udp' /etc/services<BR>$UDP<BR>"
        VALUE2="grep 'ftp    21/tcp' /etc/services<BR>$TCP"
        VALUE="Remove FTP package or comment the entry below at /etc/services<BR>$VALUE"
        status="Non-Compliant"
fi
DescItem="FTP server"
Policy="FTP server not allowed<BR><BR>Comment ftp  21/udp and ftp 21/tcp<BR>in /etc/services"
DrawItem "$DescItem" "$Policy" "$VALUE<BR>$VALUE1<BR><BR>$VALUE2" "$status" >> $LOG_DIR/$hc

################################################################################################
################################################################################################
#
## AD.1.1.2 TFTP server

VALUE1=`hostname | grep mxtra`
VALUE2=`rpm -qa | grep ^tftp`
VALUE3=`grep 'tftp[[:blank:]]*69/udp' /etc/services | cut -c1`
VALUE4=`grep 'tftp[[:blank:]]*69/tcp' /etc/services | cut -c1`
VALUE5=`grep 'tftp[[:blank:]]*69/udp' /etc/services`
VALUE6=`grep 'tftp[[:blank:]]*69/tcp' /etc/services`
if [ -n "$VALUE1" ]
        then
        VALUE2=`rpm -qa | grep tftp`
        VALUE7="TFTP is approved deviation on `hostname` server<BR><BR>$VALUE2<BR><BR>grep -i 'tftp 69' /etc/services<BR>$VALUE5<BR>$VALUE6"
        status="Compliant"

else
        if [ -z "$VALUE1" ] && [ -z "$VALUE2" ] && [ "$VALUE3" = "#" ] && [ "$VALUE4" = "#" ]
        then
        VALUE3="`grep 'tftp[[:blank:]]*69/udp' /etc/services`"
        VALUE4="`grep 'tftp[[:blank:]]*69/tcp' /etc/services`"
        VALUE7="TFTP not installed<BR><BR>Services not configure<BR><BR>grep 'tftp 69/udp' /etc/services<BR>$VALUE5<BR><BR>grep 'tftp 69/tcp' /etc/services<BR>$VALUE6"
        status="Compliant"

        else
        VALUE2=`rpm -qa | grep ^tftp`
        UDP=`grep 'tftp[[:blank:]]*69/udp' /etc/services`
        TCP=`grep 'tftp[[:blank:]]*69/tcp' /etc/services`
        VALUE3="grep 'tftp 69/udp' /etc/services<BR>$UDP<BR>"
        VALUE4="grep 'tftp 69/tcp' /etc/services<BR>$TCP"
        VALUE7="Remove TFTP Package or comment the entry below on /etc/services<BR>$VALUE5<BR>$VALUE6"
        status="Non-Compliant"
        fi
fi
DescItem="TFTP server"
Policy="TFTP server not allowed<BR><BR>Comment tftp  69/udp and tftp 69/tcp<BR>in /etc/services"
DrawItem "$DescItem" "$Policy" "$VALUE7" "$status" >> $LOG_DIR/$hc

################################################################################################
################################################################################################
#
## AD.1.1.3 Telnet server

VALUE=`rpm -qa | grep telnet-server`
VALUE1=`grep 'telnet[[:blank:]]*23/tcp' /etc/services | cut -c1`
VALUE2=`grep 'telnet[[:blank:]]*23/udp' /etc/services | cut -c1`
if [ -z "$VALUE" ] && [ "$VALUE1" = "#" ] && [ "$VALUE2" = "#" ] ; then
        VALUE="Telnet Server not installed<BR>$VALUE<BR>"
        VALUE1="grep 'telnet        *23/tcp' /etc/services<BR>`grep 'telnet[[:blank:]]*23/tcp' /etc/services`<BR>"
        VALUE2="grep 'telnet        *23/udp' /etc/services<BR>`grep 'telnet[[:blank:]]*23/udp' /etc/services`"
        status="Compliant"
else
        UDP=`grep 'telnet[[:blank:]]*23/tcp' /etc/services`
        TCP=`grep 'telnet[[:blank:]]*23/udp' /etc/services`
        VALUE1="grep 'telnet        *23/tcp' /etc/services<BR>$UDP<BR>"
        VALUE2="grep 'telnet        *23/udp' /etc/services<BR>$TCP"
        VALUE="Remove Telnet-Server package or comment the entry below at /etc/services<BR>$VALUE"
        status="Non-Compliant"
fi
DescItem="Telnet server"
Policy="Telnet server not allowed<BR><BR>Comment telnet  23/udp and telnet  23/tcp<BR>in /etc/services"
DrawItem "$DescItem" "$Policy" "$VALUE<BR>$VALUE1<BR>$VALUE2" "$status" >> $LOG_DIR/$hc

################################################################################################
echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>1.2) <span style="background-color:yellow">System Access Control Management</span> <span style="background-color:green">(DBS ISP 4020)</span> (e.g. Password Settings related)</b></td></tr>" >> $LOG_DIR/$hc
echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>1.2.1) Password Settings</b></td></tr>" >> $LOG_DIR/$hc
################################################################################################
# AD.1.2.1) Password Settings

VERSION=`cat /etc/redhat-release | cut -f7 -d" " | cut -f1 -d.`
VALUE1=`grep -i ^PASS_MAX_DAYS  /etc/login.defs | awk '{print $2}'`
VALUE2=`grep -i ^PASS_MIN_LEN  /etc/login.defs | awk '{print $2}'`
VALUE3=`grep -i ^PASS_WARN_AGE  /etc/login.defs | awk '{print $2}'`
VALUE4=`grep -i ^PASS_MIN_DAY  /etc/login.defs | awk '{print $2}'`
        if [ "$VERSION" = 5 ] ; then

                OUT1=`cat /etc/pam.d/system-auth | grep ^[[:blank:]]*password[[:blank:]]*required[[:blank:]]*pam_cracklib.so[[:blank:]]*dcredit=-1[[:blank:]]*ucredit=-1[[:blank:]]*lcredit=-1[[:blank:]]*`

        else
                        OUT1=`cat /etc/pam.d/system-auth | grep ^[[:blank:]]*password[[:blank:]]*required[[:blank:]]*pam_cracklib.so[[:blank:]]*retry=3[[:blank:]]*minlen=8[[:blank:]]*dcredit=-1[[:blank:]]*ucredit=-1[[:blank:]]*lcredit=-1[[:blank:]]*ocredit=-1[[:blank:]]*maxrepeat=1[[:blank:]]*difok=3`
        fi

if  [ "$VALUE1" -le '90' ] && [ "$VALUE2" -ge '8' ] && [ "$VALUE3" -le '14' ] && [ "$VALUE4" = 1 ] ; then
        VALUE1=`grep -i ^PASS_MAX_DAYS  /etc/login.defs`
        VALUE2=`grep -i ^PASS_MIN_LEN  /etc/login.defs`
        VALUE3=`grep -i ^PASS_WARN_AGE  /etc/login.defs`
        VALUE4=`grep -i ^PASS_MIN_DAY  /etc/login.defs`

        VALUE5="Password aging control meet the requirements<BR><BR>grep -i ^PASS /etc/login.defs<BR>$VALUE1<BR>$VALUE2<BR>$VALUE3<BR>$VALUE4"
        status="Compliant"
        else
        if [ "$VALUE1" != '90' ] ; then
                VALUE1=`grep -i ^PASS_MAX_DAYS  /etc/login.defs`
                VALUE5="Did not meet the maximum number of days a password may be used<BR>Entry below should set to 90 days<BR><BR>$VALUE1"
            else
                if  [ "$VALUE2" != '8' ] ; then
                VALUE2=`grep -i ^PASS_MIN_LEN  /etc/login.defs`
                VALUE5="Did not meet the minimum acceptable password length<BR>Entry below should set to < 8 character<BR><BR>$VALUE2"
                        else
                                if [ "$VALUE3" != '14' ]; then
                                VALUE3=`grep -i ^PASS_WARN_AGE  /etc/login.defs`
                                VALUE5="Did not meet the nuumber of days warning given<BR>before a password expires. Entry below should set to 14 days<BR><BR>$VALUE3"
                                        else
                                                if [  "$VALUE4" != '1' ]; then
                                                VALUE4=`grep -i ^PASS_MIN_DAY  /etc/login.defs`
                                                VALUE5="Did not meet the minimum number of days allowed<BR>between password changes. Entry below should set to 1<BR><BR>$VALUE4"
                                                fi
                                 fi
                fi
        fi
        status="Non-Compliant"
fi

if  [ "$OUT1" != "" ] ; then

                if [ "$status" == "Compliant" ] ; then
                        VALUE5=$VALUE5" <BR><BR> and /etc/pam.d/system-auth entry also met the requirements.<BR><BR>
                                                   RHEL5<BR>
                           password    required      pam_cracklib.so dcredit=-1 ucredit=-1 ocredit=-1 lcredit=-1<BR><BR>
                           RHEL6 & RHEL7<BR>
                           password    required      pam_cracklib.so retry=3 minlen=8 dcredit=-1 ucredit=-1 lcredit=-1 ocredit=-1 maxrepeat=1 difok=3<BR>"
                        status="Compliant"
                else
                    VALUE5=$VALUE5"<BR><BR>  but /etc/pam.d/system-auth entry met the requirements.<BR><BR>
                            RHEL5<BR>
                            password    required      pam_cracklib.so dcredit=-1 ucredit=-1 ocredit=-1 lcredit=-1<BR><BR>
                            RHEL6 & RHEL7<BR>
                            password    required      pam_cracklib.so retry=3 minlen=8 dcredit=-1 ucredit=-1 lcredit=-1 ocredit=-1 maxrepeat=1 difok=3<BR>"
                        status="Non-Compliant"
                        fi
else

   if [ "$status" == "Compliant" ] ; then
                        VALUE5=$VALUE5" <BR><BR>  but /etc/pam.d/system-auth entry not met the requirements.<BR><BR>
                            RHEL5<BR>
                            password    required      pam_cracklib.so dcredit=-1 ucredit=-1 ocredit=-1 lcredit=-1<BR><BR>
                            RHEL6 & RHEL7<BR>
                            password    required      pam_cracklib.so retry=3 minlen=8 dcredit=-1 ucredit=-1 lcredit=-1 ocredit=-1 maxrepeat=1 difok=3<BR>"
                        status="Non-Compliant"
                else
                    VALUE5=$VALUE5" <BR><BR>  and /etc/pam.d/system-auth entry also not met the requirements.<BR><BR>
                            RHEL5<BR>
                            password    required      pam_cracklib.so dcredit=-1 ucredit=-1 ocredit=-1 lcredit=-1<BR><BR>
                            RHEL6 & RHEL7<BR>
                            password    required      pam_cracklib.so retry=3 minlen=8 dcredit=-1 ucredit=-1 lcredit=-1 ocredit=-1 maxrepeat=1 difok=3<BR>"
                        status="Non-Compliant"
                        fi

fi


DescItem="Password Aging Controls<BR><BR>PASS_MAX_DAYS<BR>PASS_MIN_LEN<BR>PASS_WARN_AGE<BR>PASS_MIN_DAYd<BR>credit=-1
ucredit=-1<BR>
ocredit=-1<BR>
lcredit=-1
"
Policy="Requirements should be:<BR><BR>PASS_MAX_DAYS = Not more than 90 days<BR> PASS_MIN_LEN =>8<BR>PASS_WARN_AGE <=14<BR>PASS_MIN_DAY = 1
<BR><BR>
RHEL5<BR>
password    required      pam_cracklib.so dcredit=-1 ucredit=-1 ocredit=-1 lcredit=-1<BR><BR>

RHEL6 & RHEL7<BR>
password    required      pam_cracklib.so retry=3 minlen=8 dcredit=-1 ucredit=-1 lcredit=-1 ocredit=-1 maxrepeat=1 difok=3<BR>
"
DrawItem "$DescItem" "$Policy" "$VALUE5" "$status" >> $LOG_DIR/$hc



###############################################################################################
###############################################################################################
#AV.1.2.1 Username/Password Authentication<BR>Users may be allowed to authenticate using a unique username and password
echo " " > $LOG_DIR/output
echo " " > $LOG_DIR/temp
echo " " > $LOG_DIR/temp1
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^UsePAM /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^UsePAM /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^UsePAM /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^UsePAM /etc/ssh/sshd_config_ca | awk '{print $2}'`
        VALUE5=`grep ^PasswordAuthentication /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE6=`grep ^PasswordAuthentication /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE7=`grep ^PasswordAuthentication /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE8=`grep ^PasswordAuthentication /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = yes ] && [ "$VALUE2" = yes ] && [ "$VALUE3" = yes ] && [ "$VALUE4" = yes ] && [ "$VALUE5" = yes ] && [ "$VALUE6" = yes ] && [ "$VALUE7" = yes ] && [ "$VALUE8" = yes ]
                then
          VALUE="grep ^UsePAM /etc/ssh/sshd_config<BR>UsePAM $VALUE1<BR><BR>grep ^UsePAM /etc/ssh/sshd_config_vascop<BR>UsePAM $VALUE2<BR><BR>grep ^UsePAM /etc/ssh/sshd_config_vascos<BR>UsePAM $VALUE3<BR><BR>grep ^UsePAM /etc/ssh/sshd_config_ca<BR>UsePAM $VALUE4<BR><BR>grep ^PasswordAuthentication /etc/ssh/sshd_config<BR>PasswordAuthentication $VALUE5<BR><BR>grep ^PasswordAuthentication /etc/ssh/sshd_config_vascop<BR>PasswordAuthentication $VALUE6<BR><BR>grep ^PasswordAuthentication /etc/ssh/sshd_config_vascos<BR>PasswordAuthentication $VALUE7<BR><BR>grep ^PasswordAuthentication /etc/ssh/sshd_config_ca<BR>PasswordAuthentication $VALUE8"
          status="Compliant"
        else
                  VALUE="grep ^UsePAM /etc/ssh/sshd_config<BR>UsePAM $VALUE1<BR><BR>grep ^UsePAM /etc/ssh/sshd_config_vascop<BR>UsePAM $VALUE2<BR><BR>grep ^UsePAM /etc/ssh/sshd_config_vascos<BR>UsePAM $VALUE3<BR><BR>grep ^UsePAM /etc/ssh/sshd_config_ca<BR>UsePAM $VALUE4<BR><BR>grep ^PasswordAuthentication /etc/ssh/sshd_config<BR>PasswordAuthentication $VALUE5<BR><BR>grep ^PasswordAuthentication /etc/ssh/sshd_config_vascop<BR>PasswordAuthentication $VALUE6<BR><BR>grep ^PasswordAuthentication /etc/ssh/sshd_config_vascos<BR>PasswordAuthentication $VALUE7<BR><BR>grep ^PasswordAuthentication /etc/ssh/sshd_config_ca<BR>PasswordAuthentication $VALUE8"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^UsePAM /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^PasswordAuthentication /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = no ] && [ "$VALUE2" = yes ]
                then
          VALUE="grep ^UsePam /etc/ssh/sshd_config<BR>UsePam $VALUE1<BR><BR>grep ^PasswordAuthentication /etc/ssh/sshd_config<BR>PasswordAuthentication $VALUE2"
          status="Compliant"
        else
                  VALUE="grep ^UsePam /etc/ssh/sshd_config<BR>UsePam $VALUE1<BR><BR>grep ^PasswordAuthentication /etc/ssh/sshd_config<BR>PasswordAuthentication $VALUE2"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
        VALUE1=`grep -C 9 '10.197.243.88' /etc/ssh2/ssh-server-config.xml > $LOG_DIR/temp`
        VALUE2=`grep allow $LOG_DIR/temp`
        VALUE3=`egrep '10.196.243.88' $LOG_DIR/temp`
        if [ -n "$VALUE3" ] && [ -n "$VALUE3" ] && [ -n "$VALUE3" ] ;
                then
                  VALUE="grep -C 9 '10.197.243.88' /etc/ssh2/ssh-server-config.xml"
                  cat $LOG_DIR/temp | sed 's/>/\&gt;/g'  | sed 's/</\&lt;/g' > $LOG_DIR/temp1
                  while read -r line;do echo "<BR>$line" >> $LOG_DIR/output; done < $LOG_DIR/temp1
                  status="Compliant"
                else
          VALUE="grep -C 9 '10.197.243.88' /etc/ssh2/ssh-server-config.xml"
          cat $LOG_DIR/temp | sed 's/>/\&gt;/g'  | sed 's/</\&lt;/g' > $LOG_DIR/temp1
          while read -r line;do echo "<BR>$line" >> $LOG_DIR/output; done < $LOG_DIR/temp1
                  status="Non-Compliant"
        fi
fi
DescItem="<b>Username/Password Authentication</b><BR>Users may be allowed to authenticate using a unique username and password"
Policy="2 factor authentications must be used for all SSH with Shell accesses.<BR><BR>1 factor authentication may be used if the SSH is setup with restricted shell in cases where only file transfer and password change is permitted only.<BR><BR>RHEL (OpenSSH) : usePAM = yes<BR><BR>1factor authentication are allowed to use in UAT network segment not within DMZ.<BR><BR>Exception on Compute Node<BR>2 factor is not enable in compute node<BR>Refer to AV.4 Process Exception"
DrawItem "$DescItem" "$Policy" "$VALUE`cat $LOG_DIR/output`" "$status" >> $LOG_DIR/$hc
rm $LOG_DIR/output
rm $LOG_DIR/temp

###############################################################################################
#AV.1.2.2 PermitRootLogin:
echo " " > $LOG_DIR/output
echo " " > $LOG_DIR/temp
echo " " > $LOG_DIR/temp1

if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^PermitRootLogin /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^PermitRootLogin /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^PermitRootLogin /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^PermitRootLogin /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = no ] && [ "$VALUE2" = no ] && [ "$VALUE3" = no ] && [ "$VALUE4" = no ]
                then
          VALUE="grep ^PermitRootLogin /etc/ssh/sshd_config<BR>PermitRootLogin $VALUE1<BR><BR>grep ^PermitRootLogin /etc/ssh/sshd_config_vascop<BR>PermitRootLogin $VALUE2<BR><BR>grep ^PermitRootLogin /etc/ssh/sshd_config_vascos<BR>PermitRootLogin $VALUE3<BR><BR>grep ^PermitRootLogin /etc/ssh/sshd_config_ca<BR>PermitRootLogin $VALUE4"
          status="Compliant"
        else
          VALUE="grep ^PermitRootLogin /etc/ssh/sshd_config<BR>PermitRootLogin $VALUE1<BR><BR>grep ^PermitRootLogin /etc/ssh/sshd_config_vascop<BR>PermitRootLogin $VALUE2<BR><BR>grep ^PermitRootLogin /etc/ssh/sshd_config_vascos<BR>PermitRootLogin $VALUE3<BR><BR>grep ^PermitRootLogin /etc/ssh/sshd_config_ca<BR>PermitRootLogin $VALUE4"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^PermitRootLogin /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = yes ]
                then
          VALUE="grep ^PermitRootLogin /etc/ssh/sshd_config<BR>PermitRootLogin $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^PermitRootLogin /etc/ssh/sshd_config<BR>PermitRootLogin $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
        VALUE1=`grep -C 4 user-privileged /etc/ssh2/ssh-server-config.xml > $LOG_DIR/temp1`
        VALUE2=`grep yes $LOG_DIR/temp1`
        if [ -z "$VALUE2" ];
                then
                  VALUE="grep -C 4 user-privileged /etc/ssh2/ssh-server-config.xml"
                  cat $LOG_DIR/temp1 | sed 's/>/\&gt;/g'  | sed 's/</\&lt;/g' >> $LOG_DIR/temp
                  while read -r line;do echo "<br />$line" >> $LOG_DIR/output; done < $LOG_DIR/temp
                  status="Compliant"
                else
                  VALUE="grep -C 4 user-privileged /etc/ssh2/ssh-server-config.xml"
                  cat $LOG_DIR/temp1 | sed 's/>/\&gt;/g'  | sed 's/</\&lt;/g' >> $LOG_DIR/temp
                  while read -r line;do echo "<br />$line" >> $LOG_DIR/output; done < $LOG_DIR/temp
                  status="Non-Compliant"
        fi
fi

DescItem="<b>PermitRootLogin:</b><BR>Permits the root user to login remotely."
Policy="<b>NO</b><BR><BR> SSHv7 for WIN :<BR>Deny group access to Administators<BR><BR>Exception on Compute Node<BR>2 factor is not enable in compute node<BR>Refer to AV.4 Process Exception"
DrawItem "$DescItem" "$Policy" "$VALUE`cat $LOG_DIR/output`" "$status" >> $LOG_DIR/$hc
rm $LOG_DIR/output
rm $LOG_DIR/temp
rm $LOG_DIR/temp1


################################################################################################
#AV.1.2.3 PermitEmptyPasswords
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^PermitEmptyPasswords /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^PermitEmptyPasswords /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^PermitEmptyPasswords /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^PermitEmptyPasswords /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = no ] && [ "$VALUE2" = no ] && [ "$VALUE3" = no ] && [ "$VALUE4" = no ]
                then
          VALUE="grep ^PermitEmptyPasswords /etc/ssh/sshd_config<BR>PermitEmptyPasswords $VALUE1<BR><BR>grep ^PermitEmptyPasswords /etc/ssh/sshd_config_vascop<BR>PermitEmptyPasswords $VALUE2<BR><BR>grep ^PermitEmptyPasswords /etc/ssh/sshd_config_vascos<BR>PermitEmptyPasswords $VALUE3<BR><BR>grep ^PermitEmptyPasswords /etc/ssh/sshd_config_ca<BR>PermitEmptyPasswords $VALUE4"
          status="Compliant"
        else
          VALUE="grep ^PermitEmptyPasswords /etc/ssh/sshd_config<BR>PermitEmptyPasswords $VALUE1<BR><BR>grep ^PermitEmptyPasswords /etc/ssh/sshd_config_vascop<BR>PermitEmptyPasswords $VALUE2<BR><BR>grep ^PermitEmptyPasswords /etc/ssh/sshd_config_vascos<BR>PermitEmptyPasswords $VALUE3<BR><BR>grep ^PermitEmptyPasswords /etc/ssh/sshd_config_ca<BR>PermitEmptyPasswords $VALUE4"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^PermitEmptyPasswords /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = no ]
                then
          VALUE="grep ^PermitEmptyPasswords /etc/ssh/sshd_config<BR>PermitEmptyPasswords $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^PermitEmptyPasswords /etc/ssh/sshd_config<BR>PermitEmptyPasswords $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
        then
          VALUE="PermitEmptyPasswords setting not available in Tectia SSH Server"
          status="Not Applicable"
fi
DescItem="<b>PermitEmptyPasswords</b><BR>Allows login to accounts with empty password strings."
Policy="<b>NO</b><BR><BR>SSHv7 for WIN : set to False<BR><BR>PermitEmptyPasswords Setting Not Applicable for Tectia SSH Server"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc



################################################################################################
# AV.1.2.4 StrictModes
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^StrictModes /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^StrictModes /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^StrictModes /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^StrictModes /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = yes ] && [ "$VALUE2" = yes ] && [ "$VALUE3" = yes ] && [ "$VALUE4" = yes ]
        then
          VALUE="grep ^StrictModes /etc/ssh/sshd_config<BR>StrictModes $VALUE1<BR><BR>grep ^StrictModes /etc/ssh/sshd_config_vascop<BR>StrictModes $VALUE2<BR><BR>grep ^StrictModes /etc/ssh/sshd_config_vascos<BR>StrictModes $VALUE3<BR><BR>grep ^StrictModes /etc/ssh/sshd_config_ca<BR>StrictModes $VALUE4"
          status="Compliant"
        else
          VALUE="grep ^StrictModes /etc/ssh/sshd_config<BR>StrictModes $VALUE1<BR><BR>grep ^StrictModes /etc/ssh/sshd_config_vascop<BR>StrictModes $VALUE2<BR><BR>grep ^StrictModes /etc/ssh/sshd_config_vascos<BR>StrictModes $VALUE3<BR><BR>grep ^StrictModes /etc/ssh/sshd_config_ca<BR>StrictModes $VALUE4"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^StrictModes /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = yes ]
                then
          VALUE="grep ^StrictModes /etc/ssh/sshd_config<BR>StrictModes $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^StrictModes /etc/ssh/sshd_config<BR>StrictModes $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
   VALUE=`grep 'strict="yes"' /etc/ssh2/ssh-server-config.xml | awk -F\" '{print $(NF-3)}'`
   if [ "$VALUE" = yes ]
        then
          VALUE="grep 'strict' /etc/ssh2/ssh-server-config.xml<BR>`grep 'strict="yes"' /etc/ssh2/ssh-server-config.xml | sed 's/>/\&gt;/g' | sed 's/</\&lt;/g'`"
          status="Compliant"
        else
          VALUE="grep 'strict' /etc/ssh2/ssh-server-config.xml<BR>`grep 'strict="no"' /etc/ssh2/ssh-server-config.xml | sed 's/>/\&gt;/g' | sed 's/</\&lt;/g'`"
          status="Non-Compliant"
        fi
fi
DescItem="<b>StrictModes</b><BR>Configures SSH to verify ownership and permissions of user files and home directories before allowing logins."
Policy="<b>Yes</b><BR><BR>StrictModes setting not supported in SSHv7 for Windows"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc




echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>1.2.2) Password and User ID Attributes/Settings</b></td></tr>" >> $LOG_DIR/$hc
################################################################################################
# AD.1.2.2_A Passwords in /etc/shadow


 for i in `cat /etc/passwd |cut -d':' -f1 | egrep -vx 'root|bin|daemon|adm|lp|sync|shutdown|halt|mail|operator|games|ftp|nobody|avahi-autoipd|systemd-bus-proxy|systemd-network|dbus|polkitd|tss|ntp|postfix|sshd'`
 do

        PASS_LOCK_CHECK=`passwd -S  $i | cut -d' ' -f2`
        if [ "$PASS_LOCK_CHECK" != "LK" ] && [ "$PASS_LOCK_CHECK" != "PS" ]
                            then
                                        echo `passwd -S $i` >> $LOG_DIR/temp

        fi


 done
 if [ -s $LOG_DIR/temp ]
        then
          VALUE="Below are the IDs either not reset or not locked "
          status="Non-Compliant"

          else
          VALUE="All IDs are either reset or Locked"
          status="Compliant"
  fi

DescItem="ID without password must be locked"
Policy="Make sure those ID without password are locked <BR>
passwd &#45;S &#39;ID&#39; <BR>
If password is set, you will see &#39;Password Set&#39; <BR>
If ID has no password, you will see &#39;Password Locked&#39; <BR>
"
DrawItem "$DescItem" "$Policy" "$VALUE <BR> `cat $LOG_DIR/temp`" "$status" >> $LOG_DIR/$hc
rm $LOG_DIR/temp


################################################################################################
# AD.1.2.2_B Password reuse

VALUE=`grep "password[[:blank:]]*sufficient[[:blank:]]*pam_unix.so[[:blank:]]*sha512[[:blank:]]*shadow[[:blank:]]*nullok[[:blank:]]*try_first_pass[[:blank:]]*use_authtok" /etc/pam.d/system-auth | grep -v ^#`
if [ -n "$VALUE" ] ; then
        VALUE="grep 'password    sufficient    pam_unix.so sha512 shadow nullok try_first_pass use_authtok' /etc/pam.d/system-auth<BR><BR>$VALUE"
        status="Compliant"
else
        VALUE="Missing entry on /etc/pam.d/system-auth<BR><BR>grep 'password    sufficient    pam_unix.so sha512 shadow nullok try_first_pass use_authtok' /etc/pam.d/system-auth<BR>entry not found"
        status="Non-Compliant"
        fi

DescItem="Password reuse"
Policy="Prevent reuse of at least 9 passwords.<BR><BR>/etc/pam.d/system-auth must contain below line<BR>password required pam_unix.so remember=9 md5 shadow use_authtok"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc

################################################################################################
################################################################################################
#AD.2
DrawSecRptHead "AD.2 Settings related to Best Security Practices. These items are reviewed and approved by the Information Security Operations Team."


################################################################################################
# AD 2.1) System Operations and Administration (DBS ISP 5020) (e.g. Cron job, Protecting OSR, Logging and other operation related settings)

echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>2.1) <span style="background-color:yellow">System Operations and Administration</span> <span style="background-color:green">(DBS ISP 5020)</span> (e.g. Cron job, Protecting OSR, Logging and other operation related settings)</b></td></tr>" >> $LOG_DIR/$hc
echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>2.1.1) Logging</b></td></tr>" >> $LOG_DIR/$hc
###############################################################################################
#D.2.1.1_A Logging

VALUEVER=`cat /etc/redhat-release | cut -d " " -f7|cut -c1`

if [ "$VALUEVER" = '4' ]
then
        if [ -f /var/log/wtmp ] && [ -f /var/log/messages ] && [ -f /var/log/faillog ]
        then
        VALUE1=`ls -la /var/log/wtmp`
        VALUE2=`ls -la /var/log/messages`
        VALUE3=`ls -la /var/log/faillog`
        VALUE="RHEL 4<BR>Following files exist<BR><BR>ls -la /var/log/wtmp /var/log/messages /var/log/faillog<BR><BR>$VALUE1<BR>$VALUE2<BR>$VALUE3"
        status="Compliant"
        else
        if [ ! -f /var/log/wtmp ]
        then
        VALUE="`ls -la /var/log/wtmp`<BR>`ls -la /var/log/messages`<BR>`ls -la /var/log/faillog`"
        status="Non-Compliant"
        elif [ ! -f /var/log/messages ]
        then
        VALUE="`ls -la /var/log/wtmp`<BR>`ls -la /var/log/messages`<BR>`ls -la /var/log/faillog`"
        status="Non-Compliant"
        elif [ ! -f /var/log/faillog ]
        then
        VALUE="`ls -la /var/log/wtmp`<BR>`ls -la /var/log/messages`<BR>`ls -la /var/log/faillog`"
        status="Non-Compliant"
        fi
        fi
elif [ "$VALUEVER" = '5' ]
then
        if [ -f /var/log/wtmp ] && [ -f /var/log/messages ] && [ -f /var/log/faillog ]
        then
        VALUE1=`ls -la /var/log/wtmp`
        VALUE2=`ls -la /var/log/messages`
        VALUE3=`ls -la /var/log/faillog`
        VALUE="RHEL 5<BR>Following files exist<BR><BR>ls -la /var/log/wtmp /var/log/messages /var/log/faillog<BR><BR>$VALUE1<BR>$VALUE2<BR>$VALUE3"
        status="Compliant"
        else
        if [ ! -f /var/log/wtmp ]
        then
        VALUE="`ls -la /var/log/wtmp`<BR>`ls -la /var/log/messages`<BR>`ls -la /var/log/faillog`"
        status="Non-Compliant"
        elif [ ! -f /var/log/messages ]
        then
        VALUE="`ls -la /var/log/wtmp`<BR>`ls -la /var/log/messages`<BR>`ls -la /var/log/faillog`"
        status="Non-Compliant"
        elif [ ! -f /var/log/faillog ]
        then
        VALUE="`ls -la /var/log/wtmp`<BR>`ls -la /var/log/messages`<BR>`ls -la /var/log/faillog`"
        status="Non-Compliant"
        fi
        fi
elif [ "$VALUEVER" = '6' ] || [ "$VALUEVER" = '7' ]
then
        if [ -f /var/log/wtmp ] && [ -f /var/log/messages ] && [ -f /var/log/tallylog ]
        then
        VALUE1=`ls -la /var/log/wtmp`
        VALUE2=`ls -la /var/log/messages`
        VALUE3=`ls -la /var/log/tallylog`
        VALUE="RHEL $VALUEVER <BR>Following files exist<BR><BR>ls -la /var/log/wtmp /var/log/messages /var/log/tallylog<BR><BR>$VALUE1<BR>$VALUE2<BR>$VALUE3"
        status="Compliant"
        else
        if [ ! -f /var/log/wtmp ]
        then
        VALUE="`ls -la /var/log/wtmp`<BR>`ls -la /var/log/messages`<BR>`ls -la /var/log/tallylog`"
        status="Non-Compliant"
        elif [ ! -f /var/log/messages ]
        then
        VALUE="`ls -la /var/log/wtmp`<BR>`ls -la /var/log/messages`<BR>`ls -la /var/log/tallylog`"
        status="Non-Compliant"
        elif [ ! -f /var/log/tallylog ]
        then
        VALUE="`ls -la /var/log/wtmp`<BR>`ls -la /var/log/messages`<BR>`ls -la /var/log/tallylog`"
        status="Non-Compliant"
        fi
        fi
fi

DescItem="Login logs should be in the system<BR><BR>/var/log/wtmp<BR>/var/log/messages<BR>/var/log/faillog<BR>/var/log/tallylog"
Policy="System Log files must exist<BR><BR>/var/log/wtmp<BR>/var/log/messages<BR>/var/log/faillog<BR><BR>RHEL 6 and 7<BR>/var/log/faillog is updated to /var/log/tallylog"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc

################################################################################################
# AD.2.1.1_B Login success or failure

VALUEVER=`cat /etc/redhat-release | cut -d " " -f7|cut -c1`
VALUE1=`grep '*.info;mail.none;authpriv.none;cron.none[[:space:]]*/var/log/messages' /etc/syslog.conf | grep -v ^#`
VALUE2=`grep 'authpriv.*[[:space:]]*/var/log/secure' /etc/syslog.conf | grep -v ^#`
VALUE3=`ls -lt /var/log/messages | awk '{print $1}'`
VALUE4=`ls -lt /var/log/secure | awk '{print $1}'`
VALUE5=`grep '*.info;mail.none;authpriv.none;cron.none[[:space:]]*/var/log/messages' /etc/rsyslog.conf | grep -v ^#`
VALUE6=`grep 'authpriv.*[[:space:]]*/var/log/secure' /etc/rsyslog.conf | grep -v ^#`


if [ "$VALUEVER" = "4" ]
        then
        if [ -n "$VALUE1" ] && [ -n "$VALUE2" ] && [ "$VALUE3" = "-rw-r--r--" ] && [ "$VALUE4" = "-rw-r--r--" ]; then
        VALUE3=`ls -l /var/log/messages`
        VALUE4=`ls -l /var/log/secure`
        VALUE="RHEL 4<BR><BR>grep '*.info;mail.none;authpriv.none;cron.none /var/log/messages' /etc/syslog.conf<BR>$VALUE1<BR><BR>grep 'authpriv.* /var/log/secure' /etc/syslog.conf<BR>$VALUE2<BR><BR>ls -l /var/log/messages /var/log/secure<BR>$VALUE3<BR>$VALUE4"
        status="Compliant"
        else
        VALUE3=`ls -l /var/log/messages | awk '{print $1,$9}'`
        VALUE4=`ls -l /var/log/secure | awk '{print $1,$9}'`
        VALUE="RHEL 4<BR><BR>grep '*.info;mail.none;authpriv.none;cron.none /var/log/messages' /etc/syslog.conf<BR>$VALUE1<BR><BR>grep 'authpriv.* /var/log/secure' /etc/syslog.conf<BR>$VALUE2<BR><BR>Fixed the below permission to 644<BR>$VALUE3<BR>$VALUE4"
        status="Non-Compliant"
        fi
elif [ "$VALUEVER" = "5" ]
        then
        if [ -n "$VALUE1" ] && [ -n "$VALUE2" ] && [ "$VALUE3" = "-rw-r--r--" ] && [ "$VALUE4" = "-rw-r--r--" ]; then
        VALUE3=`ls -l /var/log/messages`
        VALUE4=`ls -l /var/log/secure`
        VALUE="RHEL 5<BR><BR>grep '*.info;mail.none;authpriv.none;cron.none /var/log/messages' /etc/syslog.conf<BR>$VALUE1<BR><BR>grep 'authpriv.* /var/log/secure' /etc/syslog.conf<BR>$VALUE2<BR><BR>ls -l /var/log/messages /var/log/secure<BR>$VALUE3<BR>$VALUE4"
        status="Compliant"
        else
        VALUE3=`ls -l /var/log/messages | awk '{print $1,$9}'`
        VALUE4=`ls -l /var/log/secure | awk '{print $1,$9}'`
        VALUE="RHEL 5<BR><BR>grep '*.info;mail.none;authpriv.none;cron.none /var/log/messages' /etc/syslog.conf<BR>$VALUE1<BR><BR>grep 'authpriv.* /var/log/secure' /etc/syslog.conf<BR>$VALUE2<BR><BR>Fixed the below permission to 644<BR>$VALUE3<BR>$VALUE4"
        status="Non-Compliant"
        fi
 elif [ "$VALUEVER" = "6" ] || [ "$VALUEVER" = '7' ]
        then
        if [ -n "$VALUE5" ] && [ -n "$VALUE6" ] && [ "$VALUE3" = "-rw-r--r--" ] && [ "$VALUE4" = "-rw-r--r--" ]; then
        VALUE3=`ls -l /var/log/messages`
        VALUE4=`ls -l /var/log/secure`
        VALUE="RHEL $VALUEVER<BR><BR>grep '*.info;mail.none;authpriv.none;cron.none /var/log/messages' /etc/syslog.conf<BR>$VALUE1<BR><BR>grep 'authpriv.* /var/log/secure' /etc/syslog.conf<BR>$VALUE2<BR><BR>ls -l /var/log/messages /var/log/secure<BR>$VALUE3<BR>$VALUE4"
        status="Compliant"
        else
        VALUE3=`ls -l /var/log/messages | awk '{print $1,$9}'`
        VALUE4=`ls -l /var/log/secure | awk '{print $1,$9}'`
        VALUE="RHEL $VALUEVER<BR><BR>grep '*.info;mail.none;authpriv.none;cron.none /var/log/messages' /etc/syslog.conf<BR>$VALUE1<BR><BR>grep 'authpriv.* /var/log/secure' /etc/syslog.conf<BR>$VALUE2<BR><BR>Fixed the below permission to 644<BR>$VALUE3<BR>$VALUE4"
        status="Non-Compliant"
        fi
fi

DescItem="Login success or failure"
Policy_1="RHEl 5<BR>File:/etc/syslog.conf<BR>1. *.info;mail.none;authpriv.none;cron.none /var/log/messages<BR>2. authpriv.* /var/log/secure<BR><BR>RHEl 6 and 7<BR>File:/etc/rsyslog.conf<BR>1. *.info;mail.none;authpriv.none;cron.none /var/log/messages<BR>2. authpriv.* /var/log/secure<BR><BR>Note: Log file permission must not have write for other<BR>and must not have write permission for group unless the associated group is used only only by 'set-GID'<BR>operating system programs to avoid a need for<BR>root only update privileges."
DrawItem "$DescItem" "$Policy_1" "$VALUE" "$status" >> $LOG_DIR/$hc


################################################################################################
# AD.2.1.1_C /var/log/secure permissions



VALUE4=`ls -lt /var/log/secure | awk '{print $1}'`


        if [ "$VALUE4" = "-rw-r--r--" ]; then

        VALUE4=`ls -l /var/log/secure`
        VALUE="Following file exists<BR><BR>ls -l /var/log/secure <BR> <BR>$VALUE4"
        status="Compliant"
        else

        VALUE4=`ls -l /var/log/secure | awk '{print $1,$9}'`
        VALUE="Following file does not exists<BR><BR>ls -l /var/log/secure"
        status="Non-Compliant"
        fi


DescItem="/var/log/secure"
Policy_1="File permissions must be set to 600&#58;<BR>
-rw------- /var/log/secure<BR>
"
DrawItem "$DescItem" "$Policy_1" "$VALUE" "$status" >> $LOG_DIR/$hc



################################################################################################
# AV.2.1.1a Ssh1Compatibility
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^Protocol /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^Protocol /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^Protocol /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^Protocol /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = 2 ] && [ "$VALUE2" = 2 ] && [ "$VALUE3" = 2 ] && [ "$VALUE4" = 2 ]
                then
                  VALUE="grep ^Protocol /etc/ssh/sshd_config<BR>Protocol $VALUE1<BR><BR>grep ^Protocol /etc/ssh/sshd_config_vascop<BR>Protocol $VALUE2<BR><BR>grep ^Protocol /etc/ssh/sshd_config_vascos<BR>Protocol $VALUE3<BR><BR>grep ^Protocol /etc/ssh/sshd_config_ca<BR>Protocol $VALUE4"
                  status="Compliant"
                else
                  VALUE="grep ^Protocol /etc/ssh/sshd_config<BR>Protocol $VALUE1<BR><BR>grep ^Protocol /etc/ssh/sshd_config_vascop<BR>Protocol $VALUE2<BR><BR>grep ^Protocol /etc/ssh/sshd_config_vascos<BR>Protocol $VALUE3<BR><BR>grep ^Protocol /etc/ssh/sshd_config_ca<BR>Protocol $VALUE4"
                  status="Non-Compliant"
        fi
elif [ $TYPE == "NODE" ]
then
  VALUE1=`grep ^Protocol /etc/ssh/sshd_config | awk '{print $2}'`
  if [ "$VALUE1" = 2 ]
                then
                  VALUE="grep ^Protocol /etc/ssh/sshd_config<BR>Protocol $VALUE1"
                  status="Compliant"
                else
                  VALUE="grep ^Protocol /etc/ssh/sshd_config<BR>Protocol $VALUE1"
                  status="Non-Compliant"
        fi
elif [ $TYPE == "TECTIA" ]
        then
          VALUE="Not Applicable for Tectia Server"
          status="Not Applicable"
fi

DescItem="<b>Ssh1Compatibility</b><BR>To prevent problematic and supported SSH1 connections"
policy_reco="F-Secure<BR>NO<BR><BR>OpenSSH (RHEL / VIO )<BR>Protocol 2<BR><BR>Not Applicable for Tectia SSH Server<BR>Not Applicable for Reflection for Secure Server<BR>Not Applicable for SSHv7"
DrawItem "$DescItem" "$policy_reco" "$VALUE" "$status" >> $LOG_DIR/$hc
################################################################################################
#AV.2.1.1b Restricted Shell
VALUE="Setting Applicable only for Reflection Secure SSHv7"
status="Not Applicable"
DescItem="<b>Restricted Shell</b>"
Policy="For Windows OS : PermiUserTerminal=no<BR>For Unix OS : SessionRestricted=subsystem<BR><BR>Not Applicable for SSH Tectia Server<BR>Not Applicable for OpenSSH<BR>Not Applicable for F-Secure SSH Server"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc
###############################################################################################
#V.2.1.1c LoginGraceTime
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^LoginGraceTime /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^LoginGraceTime /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^LoginGraceTime /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^LoginGraceTime /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = 120 ] && [ "$VALUE2" = 120 ] && [ "$VALUE3" = 120 ] && [ "$VALUE4" = 120 ]
        then
          VALUE="grep ^LoginGraceTime /etc/ssh/sshd_config<BR>LoginGraceTime $VALUE1<BR><BR>grep ^LoginGraceTime /etc/ssh/sshd_config_vascop<BR>LoginGraceTime $VALUE2<BR><BR>grep ^LoginGraceTime /etc/ssh/sshd_config_vascos<BR>LoginGraceTime $VALUE3<BR><BR>grep ^LoginGraceTime /etc/ssh/sshd_config_ca<BR>LoginGraceTime $VALUE4"
          status="Compliant"
        else
          VALUE="grep ^LoginGraceTime /etc/ssh/sshd_config<BR>LoginGraceTime $VALUE1<BR><BR>grep ^LoginGraceTime /etc/ssh/sshd_config_vascop<BR>LoginGraceTime $VALUE2<BR><BR>grep ^LoginGraceTime /etc/ssh/sshd_config_vascos<BR>LoginGraceTime $VALUE3<BR><BR>grep ^LoginGraceTime /etc/ssh/sshd_config_ca<BR>LoginGraceTime $VALUE4"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^LoginGraceTime /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = 120 ]
                then
          VALUE="grep ^LoginGraceTime /etc/ssh/sshd_config<BR>LoginGraceTime $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^LoginGraceTime /etc/ssh/sshd_config<BR>LoginGraceTime $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
   VALUE=`grep 'login-grace-time="120"' /etc/ssh2/ssh-server-config.xml | awk -F\" '{print $(NF-1)}'`
   if [ "$VALUE" = 120 ]
        then
                  VALUE="grep 'login-grace-time="120"' /etc/ssh2/ssh-server-config.xml<BR>`grep 'login-grace-time="120"' /etc/ssh2/ssh-server-config.xml | sed 's/>/\&gt;/g' | sed 's/</\&lt;/g'`"
          status="Compliant"
                else
                  VALUE="grep 'login-grace-time' /etc/ssh2/ssh-server-config.xml<BR>`grep 'login-grace-time' /etc/ssh2/ssh-server-config.xml | sed 's/>/\&gt;/g' | sed 's/</\&lt;/g'`"
          status="Non-Compliant"
        fi
fi

DescItem="<b>LoginGraceTime:</b><BR>The number of seconds before the server disconnect a session that has not been successfully authenticated.<BR><BR>SSHv7 for WIN : GraceLoginTimeout"
Policy="<b>120 or less and must not be 0</b>"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc
################################################################################################
#AV.2.1.1d ListenAddress
echo " " > $LOG_DIR/output
echo " " > $LOG_DIR/temp
echo " " > $LOG_DIR/temp1

if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^ListenAddress /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^ListenAddress /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^ListenAddress /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^ListenAddress /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ -n "$VALUE1" ] && [ -n "$VALUE2" ] && [ -n "$VALUE3" ] && [ -n "$VALUE4" ]
        then
          VALUE="`echo "grep ^ListenAddress /etc/ssh/sshd_config" >> $LOG_DIR/temp` `grep ^ListenAddress /etc/ssh/sshd_config >> $LOG_DIR/temp` `echo "<BR>grep ^ListenAddress /etc/ssh/sshd_config_vascop" >> $LOG_DIR/temp` `grep ^ListenAddress /etc/ssh/sshd_config_vascop >> $LOG_DIR/temp` `echo "<BR>grep ^ListenAddress /etc/ssh/sshd_config_vascos" >> $LOG_DIR/temp` `grep ^ListenAddress /etc/ssh/sshd_config_vascos >> $LOG_DIR/temp` `echo "<BR>grep ^ListenAddress /etc/ssh/sshd_config_ca" >> $LOG_DIR/temp` `grep ^ListenAddress /etc/ssh/sshd_config_ca >> $LOG_DIR/temp`"
          status="Compliant"
        else
                  VALUE="`echo "grep ^ListenAddress /etc/ssh/sshd_config" >> $LOG_DIR/temp` `grep ^ListenAddress /etc/ssh/sshd_config >> $LOG_DIR/temp` `echo "<BR>grep ^ListenAddress /etc/ssh/sshd_config_vascop" >> $LOG_DIR/temp` `grep ^ListenAddress /etc/ssh/sshd_config_vascop >> $LOG_DIR/temp` `echo "<BR>grep ^ListenAddress /etc/ssh/sshd_config_vascos" >> $LOG_DIR/temp` `grep ^ListenAddress /etc/ssh/sshd_config_vascos >> $LOG_DIR/temp` `echo "<BR>grep ^ListenAddress /etc/ssh/sshd_config_ca" >> $LOG_DIR/temp` `grep ^ListenAddress /etc/ssh/sshd_config_ca >> $LOG_DIR/temp`"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^ListenAddress /etc/ssh/sshd_config | awk '{print $2}'`
        if [ -n "$VALUE1" ]
                then
          VALUE="`echo "grep ^ListenAddress /etc/ssh/sshd_config" >> $LOG_DIR/temp` `grep ^ListenAddress /etc/ssh/sshd_config >> $LOG_DIR/temp`"
          status="Compliant"
        else
          VALUE="`echo "grep ^ListenAddress /etc/ssh/sshd_config" >> $LOG_DIR/temp` `grep ^ListenAddress /etc/ssh/sshd_config >> $LOG_DIR/temp`"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
        VALUE1=`grep 'listener id' /etc/ssh2/ssh-server-config.xml > $LOG_DIR/temp1`
        VALUE2=`grep 'listener id' $LOG_DIR/temp1`
        if [ -n "$VALUE2" ];
                then
                  VALUE="grep 'listener id' /etc/ssh2/ssh-server-config.xml"
                  cat $LOG_DIR/temp1 | sed 's/>/\&gt;/g'  | sed 's/</\&lt;/g' >> $LOG_DIR/temp
                  status="Compliant"
                else
                  VALUE="grep 'listener id' /etc/ssh2/ssh-server-config.xml<BR>not defined"
                  status="Non-Compliant"
        fi
fi
while read -r line;do echo "<br />$line" >> $LOG_DIR/output; done < $LOG_DIR/temp
DescItem="<b>ListenAddress</b><BR>To control which IP address that the SSH server should accept connections."
Policy="Must be a valid IP address on the entry"
DrawItem "$DescItem" "$Policy" "$VALUE`cat $LOG_DIR/output`" "$status" >> $LOG_DIR/$hc
rm $LOG_DIR/output
rm $LOG_DIR/temp
rm $LOG_DIR/temp1
################################################################################################
#AV.2.1.03 AllowHosts
echo " " > $LOG_DIR/output
echo " " > $LOG_DIR/temp
echo " " > $LOG_DIR/temp2
if [ $TYPE == "NORM" ] || [ $TYPE == "NODE" ]
then
        VALUE1=`grep '^sshd: ALL EXCEPT' /etc/hosts.deny > $LOG_DIR/hosts.deny`
        VALUE2=`grep -F '*' $LOG_DIR/hosts.deny | sed "s/ /\\n/g" | egrep -v '#|10.53|10.91|sshd|ALL|EXCEPT'`

        if [ -z "$VALUE2" ]
        then
           VALUE2=`grep '^sshd: ALL EXCEPT' /etc/hosts.deny > $LOG_DIR/output`
           VALUE="grep 'sshd: ALL EXCEPT' /etc/hosts.deny<BR>"
          status="Compliant"
        else
          VALUE2=`grep -F '*' $LOG_DIR/hosts.deny | sed "s/ /\\n/g" | egrep -v '#|10.53|10.91|sshd|ALL|EXCEPT'`
          VALUE="grep 'sshd: ALL EXCEPT' /etc/hosts.deny<BR>sshd /etc/hosts.deny not defined or Remove the entry below<BR><BR>$VALUE2"
          status="Non-Compliant"
    fi
    rm $LOG_DIR/hosts.deny
else [ $TYPE == "TECTIA" ]
        VALUE1=`grep 'ip address' /etc/ssh2/ssh-server-config.xml > $LOG_DIR/temp1`
        VALUE2=`grep -F 'ip address' $LOG_DIR/temp1 | awk '{print $2}' | grep '/' | egrep -v '10.53|10.91'`
        if [ -z "$VALUE2" ]
        then
                VALUE="grep 'ip address' /etc/ssh2/ssh-server-config.xml"
                cat $LOG_DIR/temp1 | sed 's/>/\&gt;/g'  | sed 's/</\&lt;/g' >> $LOG_DIR/temp
                while read -r line;do echo "<br />$line" >> $LOG_DIR/output; done < $LOG_DIR/temp
                status="Compliant"
                else
                  VALUE2=`grep -F 'ip address' $LOG_DIR/temp1 | awk '{print $2}' | grep '/' | egrep -v '10.53|10.91' > $LOG_DIR/temp2`
                  cat $LOG_DIR/temp2 | sed 's/>/\&gt;/g'  | sed 's/</\&lt;/g' >> $LOG_DIR/temp
                  while read -r line;do echo "<br />$line" >> $LOG_DIR/output; done < $LOG_DIR/temp
                  VALUE="grep 'ip address' /etc/ssh2/ssh-server-config.xml"
                  status="Non-Compliant"
        fi
fi
DescItem="<b>AllowHosts</b><BR>To control which machine is allowed to make SSH connection to this server<BR><BR>SSHv7 for WIN : ClientDomain"
Policy="Must be a valid IP address on the entry<BR><BR>For all Unix / Linux platforms, to include the following IPs in the allowhosts section:<BR><BR>Application  IP Address<BR><BR>Cyber-Ark    10.196.243.102<BR>Cyber-Ark    10.197.243.113<BR>Cyber-Ark    10.197.243.150<BR>Cyber-Ark    10.197.243.205<BR>Cyber-Ark    10.197.243.206<BR>Cyber-Ark    10.197.243.207<BR>Cyber-Ark    10.196.243.165<BR>Cyber-Ark    10.196.243.166<BR>Cyber-Ark    10.196.243.167<BR>AIM          10.197.189.181"
DrawItem "$DescItem" "$Policy" "$VALUE<BR>`cat $LOG_DIR/output`" "$status" >> $LOG_DIR/$hc
rm $LOG_DIR/output
rm $LOG_DIR/temp
rm $LOG_DIR/temp2
################################################################################################
#AV.2.1.1f Ciphers
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^Ciphers /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^Ciphers /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^Ciphers /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^Ciphers /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = aes256-cbc ] && [ "$VALUE2" = aes256-cbc ] && [ "$VALUE3" = aes256-cbc ] && [ "$VALUE4" = aes256-cbc ]
        then
          VALUE="grep ^Ciphers /etc/ssh/sshd_config<BR>Ciphers $VALUE1<BR><BR>grep ^Ciphers /etc/ssh/sshd_config_vascop<BR>Ciphers $VALUE2<BR><BR>grep ^Ciphers /etc/ssh/sshd_config_vascos<BR>Ciphers $VALUE3<BR><BR>grep ^Ciphers /etc/ssh/sshd_config_ca<BR>Ciphers $VALUE4"
          status="Compliant"
        else
          VALUE="grep ^Ciphers /etc/ssh/sshd_config<BR>Ciphers $VALUE1<BR><BR>grep ^Ciphers /etc/ssh/sshd_config_vascop<BR>Ciphers $VALUE2<BR><BR>grep ^Ciphers /etc/ssh/sshd_config_vascos<BR>Ciphers $VALUE3<BR><BR>grep ^Ciphers /etc/ssh/sshd_config_ca<BR>LoginGraceTime $VALUE4"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^Ciphers /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = aes256-cbc ]
                then
          VALUE="grep ^Ciphers /etc/ssh/sshd_config<BR>Ciphers $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^Ciphers /etc/ssh/sshd_config<BR>Ciphers $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
   VALUE=`grep 'cipher name="aes256-cbc"' /etc/ssh2/ssh-server-config.xml | awk -F\" '{print $(NF-1)}'`
   if [ "$VALUE" = aes256-cbc ]
        then
          VALUE="grep 'cipher name' /etc/ssh2/ssh-server-config.xml<BR>`grep 'cipher name="aes256-cbc"' /etc/ssh2/ssh-server-config.xml | sed 's/>/\&gt;/g' | sed 's/</\&lt;/g'`"
          status="Compliant"
        else
          VALUE="grep 'cipher name' /etc/ssh2/ssh-server-config.xml<BR>`grep 'cipher name' /etc/ssh2/ssh-server-config.xml | sed 's/>/\&gt;/g' | sed 's/</\&lt;/g'`"
          status="Non-Compliant"
        fi
fi

DescItem="<b>Ciphers</b><BR><BR>To prevent non-encrypting sessions"
Policy="<b>AnyCipher</b><BR><BR>cipher name="aes256-cbc"<BR>cipher name="aes192-cbc"<BR>cipher name="aes128-cbc"<BR>cipher name="aes256-ctr"<BR>cipher name="aes192-ctr"<BR>cipher name="aes128-ctr"<BR>cipher name="3des-cbc"<BR>cipher name="seed-cbc@ssh.com"<BR><BR>RHEL (OpenSSH) :<BR>Ciphers= aes256-cbc"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc

################################################################################################
################################################################################################
#AV.2.1.1h KeyRegenerationInterval
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^KeyRegenerationInterval /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^KeyRegenerationInterval /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^KeyRegenerationInterval /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^KeyRegenerationInterval /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = "1h" ] && [ "$VALUE2" = "1h" ] && [ "$VALUE3" = "1h" ] && [ "$VALUE4" = "1h" ]
        then
          VALUE="grep ^KeyRegenerationInterval /etc/ssh/sshd_config<BR>KeyRegenerationInterval $VALUE1<BR><BR>grep ^KeyRegenerationInterval /etc/ssh/sshd_config_vascop<BR>KeyRegenerationInterval $VALUE2<BR><BR>grep ^KeyRegenerationInterval /etc/ssh/sshd_config_vascos<BR>KeyRegenerationInterval $VALUE3<BR><BR>grep ^KeyRegenerationInterval /etc/ssh/sshd_config_ca<BR>KeyRegenerationInterval $VALUE4"
          status="Compliant"
        else
          VALUE="Value should be 1h or 3600<BR><BR>grep ^KeyRegenerationInterval /etc/ssh/sshd_config<BR>KeyRegenerationInterval $VALUE1<BR><BR>grep ^KeyRegenerationInterval /etc/ssh/sshd_config_vascop<BR>KeyRegenerationInterval $VALUE2<BR><BR>grep ^KeyRegenerationInterval /etc/ssh/sshd_config_vascos<BR>KeyRegenerationInterval $VALUE3<BR><BR>grep ^KeyRegenerationInterval /etc/ssh/sshd_config_ca<BR>KeyRegenerationInterval $VALUE4"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^KeyRegenerationInterval /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = "1h" ]
                then
          VALUE="grep ^KeyRegenerationInterval /etc/ssh/sshd_config<BR>KeyRegenerationInterval $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^KeyRegenerationInterval /etc/ssh/sshd_config<BR>KeyRegenerationInterval $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
   VALUE="Setting Applicable only for OpenSSH"
   status="Not Applicable"
fi
DescItem="<b>KeyRegenerationInterval</b>"
Policy="<b>3600</b><BR><BR>Applicable to OpenSSH/SUN SSH"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc
################################################################################################
#AV.2.1.1i GatewayPorts
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^GatewayPorts /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^GatewayPorts /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^GatewayPorts /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^GatewayPorts /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = no ] && [ "$VALUE2" = no ] && [ "$VALUE3" = no ] && [ "$VALUE4" = no ]
        then
          VALUE="grep ^GatewayPorts /etc/ssh/sshd_config<BR>GatewayPorts $VALUE1<BR><BR>grep ^GatewayPorts /etc/ssh/sshd_config_vascop<BR>GatewayPorts $VALUE2<BR><BR>grep ^GatewayPorts /etc/ssh/sshd_config_vascos<BR>GatewayPorts $VALUE3<BR><BR>grep ^GatewayPorts /etc/ssh/sshd_config_ca<BR>GatewayPorts $VALUE4"
          status="Compliant"
        else
          VALUE="Value should be No<BR><BR>grep ^GatewayPorts /etc/ssh/sshd_config<BR>GatewayPorts $VALUE1<BR><BR>grep ^GatewayPorts /etc/ssh/sshd_config_vascop<BR>GatewayPorts $VALUE2<BR><BR>grep ^GatewayPorts /etc/ssh/sshd_config_vascos<BR>GatewayPorts $VALUE3<BR><BR>grep ^GatewayPorts /etc/ssh/sshd_config_ca<BR>GatewayPorts $VALUE4"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^GatewayPorts /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = no ]
                then
          VALUE="grep ^GatewayPorts /etc/ssh/sshd_config<BR>GatewayPorts $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^GatewayPorts /etc/ssh/sshd_config<BR>GatewayPorts $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
   VALUE="Setting Applicable only for OpenSSH"
   status="Not Applicable"
fi
DescItem="<b>GatewayPorts</b>"
Policy="<b>NO</b><BR><BR>Applicable to OpenSSH/SUN SSH/Attachmate RSIT UNIX Server Only"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc
################################################################################################
#AV.2.1.1j QuietMode
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^LogLevel /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^LogLevel /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^LogLevel /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^LogLevel /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = FATAL ] && [ "$VALUE2" = FATAL ] && [ "$VALUE3" = FATAL ] && [ "$VALUE4" = FATAL ]
        then
          VALUE="grep ^LogLevel /etc/ssh/sshd_config<BR>LogLevel $VALUE1<BR><BR>grep ^LogLevel /etc/ssh/sshd_config_vascop<BR>LogLevel $VALUE2<BR><BR>grep ^LogLevel /etc/ssh/sshd_config_vascos<BR>LogLevel $VALUE3<BR><BR>grep ^LogLevel /etc/ssh/sshd_config_ca<BR>LogLevel $VALUE4"
          status="Compliant"
        else
          VALUE="grep ^LogLevel /etc/ssh/sshd_config<BR>LogLevel $VALUE1<BR><BR>grep ^LogLevel /etc/ssh/sshd_config_vascop<BR>LogLevel $VALUE2<BR><BR>grep ^LogLevel /etc/ssh/sshd_config_vascos<BR>LogLevel $VALUE3<BR><BR>grep ^LogLevel /etc/ssh/sshd_config_ca<BR>LogLevel $VALUE4"
          status="Non-Compliant"
        fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^LogLevel /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = FATAL ]
                then
          VALUE="grep ^LogLevel /etc/ssh/sshd_config<BR>LogLevel $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^LogLevel /etc/ssh/sshd_config<BR>LogLevel $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
        then
          VALUE="Not Applicable for Tectia Server"
          status="Not Applicable"
fi
DescItem="<b>QuietMode</b><BR>(F-Secure/SSH Communications Only)<BR>Specifies that only fatal errors should be logged."
Policy="<b>NO</b><BR><BR>For OpenSSH Server installed in RHEL/VIO/EXSi:<BR>LogLevel= Fatal<BR><BR>Setting not supported in SSHv7 for Windows and Tectia SSH Server"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc
################################################################################################
#AV.2.1.1k PermitUserEnvironment
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^PermitUserEnvironment /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^PermitUserEnvironment /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^PermitUserEnvironment /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^PermitUserEnvironment /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if  [ "$VALUE1" = no ] && [ "$VALUE2" = no ] && [ "$VALUE3" = no ] && [ "$VALUE4" = no ]
        then
          VALUE="grep ^PermitUserEnvironment /etc/ssh/sshd_config<BR>PermitUserEnvironment $VALUE1<BR><BR>grep ^PermitUserEnvironment /etc/ssh/sshd_config_vascop<BR>PermitUserEnvironment $VALUE2<BR><BR>grep ^PermitUserEnvironment /etc/ssh/sshd_config_vascos<BR>PermitUserEnvironment $VALUE3<BR><BR>grep ^PermitUserEnvironment /etc/ssh/sshd_config_ca<BR>PermitUserEnvironment $VALUE4"
          status="Compliant"
        else
          VALUE="Value should be No<BR><BR>grep ^PermitUserEnvironment /etc/ssh/sshd_config<BR>PermitUserEnvironment $VALUE1<BR><BR>grep ^PermitUserEnvironment /etc/ssh/sshd_config_vascop<BR>PermitUserEnvironment $VALUE2<BR><BR>grep ^PermitUserEnvironment /etc/ssh/sshd_config_vascos<BR>PermitUserEnvironment $VALUE3<BR><BR>grep ^PermitUserEnvironment /etc/ssh/sshd_config_ca<BR>PermitUserEnvironment $VALUE4"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^PermitUserEnvironment /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = no ]
                then
          VALUE="grep ^PermitUserEnvironment /etc/ssh/sshd_config<BR>PermitUserEnvironment $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^PermitUserEnvironment /etc/ssh/sshd_config<BR>PermitUserEnvironment $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
   VALUE="Setting Applicable only for OpenSSH"
   status="Not Applicable"
fi
DescItem="<b>PermitUserEnvironment</b>"
Policy="<b>NO</b><BR><BR>Applicable to OpenSSH 3.5/SunSSH 1.2 and greater - OS: Unix, Linux"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc
################################################################################################
################################################################################################
#AV.2.1.1l AcceptEnv
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^AcceptEnv /etc/ssh/sshd_config | egrep -i "TERM|PATH|HOME|MAIL|SHELL|LOGNAME|USER|USERNAME|_RLD|DYLD_|LD_|LDR_|LIBPATH|SHLIB_PATH"`
        VALUE2=`grep ^AcceptEnv /etc/ssh/sshd_config_vascop | egrep -i "TERM|PATH|HOME|MAIL|SHELL|LOGNAME|USER|USERNAME|_RLD|DYLD_|LD_|LDR_|LIBPATH|SHLIB_PATH"`
        VALUE3=`grep ^AcceptEnv /etc/ssh/sshd_config_vascos | egrep -i "TERM|PATH|HOME|MAIL|SHELL|LOGNAME|USER|USERNAME|_RLD|DYLD_|LD_|LDR_|LIBPATH|SHLIB_PATH"`
        VALUE4=`grep ^AcceptEnv /etc/ssh/sshd_config_ca | egrep -i "TERM|PATH|HOME|MAIL|SHELL|LOGNAME|USER|USERNAME|_RLD|DYLD_|LD_|LDR_|LIBPATH|SHLIB_PATH"`
        if [ -z "$VALUE1" ] && [ -z "$VALUE2" ] && [ -z "$VALUE3" ] && [ -z "$VALUE4" ]
        then
          VALUE="grep ^AcceptEnv /etc/ssh/sshd_config<BR>AcceptEnv $VALUE1<BR><BR>grep ^AcceptEnv /etc/ssh/sshd_config_vascop<BR>AcceptEnv $VALUE2<BR><BR>grep ^AcceptEnv /etc/ssh/sshd_config_vascos<BR>AcceptEnv $VALUE3<BR><BR>grep ^AcceptEnv /etc/ssh/sshd_config_ca<BR>AcceptEnv $VALUE4"
          status="Compliant"
        else
          VALUE="Value should be No<BR><BR>grep ^AcceptEnv /etc/ssh/sshd_config<BR>AcceptEnv $VALUE1<BR><BR>grep ^AcceptEnv /etc/ssh/sshd_config_vascop<BR>AcceptEnv $VALUE2<BR><BR>grep ^AcceptEnv /etc/ssh/sshd_config_vascos<BR>AcceptEnv $VALUE3<BR><BR>grep ^AcceptEnv /etc/ssh/sshd_config_ca<BR>LoginGraceTime $VALUE4"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^AcceptEnv /etc/ssh/sshd_config | egrep -i "TERM|PATH|HOME|MAIL|SHELL|LOGNAME|USER|USERNAME|_RLD|DYLD_|LD_|LDR_|LIBPATH|SHLIB_PATH" | awk '{print $2}'`
        if [ -z "$VALUE1" ]
         then
         VALUE1=`grep ^AcceptEnv /etc/ssh/sshd_config`
          VALUE="grep ^AcceptEnv /etc/ssh/sshd_config<BR>AcceptEnv $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^AcceptEnv /etc/ssh/sshd_config<BR>AcceptEnv $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
   VALUE="Setting Applicable only for OpenSSH"
   status="Not Applicable"
fi
DescItem="<b>AcceptEnv</b>"
Policy="Must not contain variables matching any of the following patterns: TERM, PATH, HOME, MAIL, SHELL, LOGNAME, USER, USERNAME, _RLD*, DYLD_*, LD_*, LDR_*, LIBPATH, SHLIB_PATH<BR><BR>Applicable to OpenSSH 3.9 and greater - OS: Unix, Linux"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc


# 2.1.12 SUDO Logging
grep '!LOGFILE' $SUDO > /dev/null 2>&1
if [ $? -eq 0 ]
        then
        status="-NonCompliant"
        VALUE2="Ensure the !LOGFILE is not set in /etc/sudoers for support ID<BR><BR>`grep '!LOGFILE' $SUDO`"
else
        status="Compliant"
        VALUE2="Ensure the !LOGFILE is not set in /etc/sudoers for support ID<BR><BR>!LOGFILE Parameter Not Found"
fi
DescItem="SUDO Logging"
Policy="Sudo logging must not be disabled. The following is NOT allowed in sudoers: !LOGFILE"
DrawItem "$DescItem" "$Policy" "$VALUE2" "$status" >> $LOG_DIR/$hc

################################################################################################
# 2.1.13 Sudo Logging to local server
VALUE1=`cat /etc/syslog.conf | grep 'local2.alert;local2.notice' | grep -v '^#' | grep sudo`
VALUE2=`ls -ltr /var/log/ | grep sudo.log`
if [ -n "$VALUE1" ] && [ -n "$VALUE2" ]
        then
        VALUE="grep 'local2.alert;local2.notice' /etc/syslog.conf<BR>$VALUE1<BR><BR>ls -ltr /var/log/sudo.log<BR>$VALUE2"
        status="Compliant"
elif [ -z "$VALUE1" ] && [ -n "$VALUE2" ]
        then
        VALUE="Missing entry on /etc/syslog<BR><BR>ls -ltr /var/log/sudo.log<BR>$VALUE2"
        status="Non-Compliant"
elif [ -n "$VALUE1" ] && [ -z "$VALUE2" ]
        then
        VALUE="grep 'local2.alert;local2.notice' /etc/syslog.conf<BR>$VALUE1<BR><BR>Missing /var/log/sudo.log file"
fi
DescItem="Sudo Logging to local server"
Policy="Apart from remote syslog, a local copy of sudo log can be stored locally. It is recommended the logging should be set via syslog.conf instead of using the sudoers file.<BR><BR>Check below setting should exist in /etc/syslog.conf<BR>local2.alert;local2.notice      /var/log/sudo.log<BR><BR>File must exist<BR>/var/log/sudo.log"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc

################################################################################################
 echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>2.1.2) System Settings</b></td></tr>" >> $LOG_DIR/$hc
################################################################################################
# AD.2.1.2_A Limit consecutive invalid login attempts to 5.

VALUE1=`grep "auth[[:blank:]]*required[[:blank:]]*pam_tally2.so[[:blank:]]*deny=5[[:blank:]]*onerr=fail" /etc/pam.d/system-auth | grep -v ^#`
VALUE2=`grep "account[[:blank:]]*required[[:blank:]]*pam_tally2.so[[:blank:]]*onerr=fail" /etc/pam.d/system-auth | grep -v ^#`
if [ -n "$VALUE1" ] && [ -n "$VALUE2" ] ; then
        VALUE="grep 'auth required pam_tally2.so deny=5 onerr=fail' /etc/pam.d/system-auth<BR>$VALUE1<BR><BR>grep 'account required pam_tally2.so onerr=fail' /etc/pam.d/system-auth<BR>$VALUE2"
        status="Compliant"
else
        VALUE="grep 'auth required pam_tally2.so deny=5 onerr=fail' /etc/pam.d/system-auth<BR>entry not found<BR><BR>grep 'account required pam_tally2.so onerr=fail' /etc/pam.d/system-auth<BR>entry not found"
        status="Non-Compliant"
fi

DescItem="Limit consecutive invalid login attempts to 5"
Policy="Limit consecutive invalid login attempts to 5.<BR><BR>auth required pam_tally2.so deny=5 onerr=fail
<BR>account required  pam_tally2.so onerr=fail"
DrawItem "$DescItem" "$Policy" "`printf "%s\n" "$VALUE"`" "$status" >> $LOG_DIR/$hc
################################################################################################
# AD.2.1.2_B Root (Super User ID)

VALUE=`cat /etc/securetty | grep console | grep -v ^#`
VALUE1=`cat /etc/securetty |grep tty | grep -v ^#`
VALUE2=`cat /etc/securetty |grep vc | grep -v ^#`


if [ "$VALUE" = 'console' ] && [ "$VALUE1" = 'tty1' ] && [ -z "$VALUE2" ]
        then
        VALUE1=`cat /etc/securetty  > $LOG_DIR/temp1`
        VALUE="cat /etc/securetty"
        while read -r line;do echo "<br />$line" >> $LOG_DIR/output1;done < $LOG_DIR/temp1
        status="Compliant"
else
        VALUE1=`cat /etc/securetty > $LOG_DIR/temp1`
        VALUE="This file should contain console and tty<BR>Remove other entry or add tty<BR><BR>cat /etc/securetty<BR>$VALUE1"

        while read -r line;do echo "<br />$line" >> $LOG_DIR/output1; done < $LOG_DIR/temp1
        status="Non-Compliant"
fi


DescItem="Root (Super User ID)"
Policy="Edit the file /etc/securetty to contain only "console" and "tty".."
DrawItem "$DescItem" "$Policy" "$VALUE<BR>`cat $LOG_DIR/output1`" "$status" >> $LOG_DIR/$hc
cat $LOG_DIR/output1
rm -rf $LOG_DIR/output1

################################################################################################
# AD.2.1.2_B2 UID & GID 0

VALUE=`getent group 0 |cut -d ":" -f4`
VALUE2=`grep :0: /etc/passwd | egrep -v 'root|sync|shutdown|halt|operator|cybadmin'`
VALUE3=`grep :0: /etc/passwd | egrep -v 'root|sync|shutdown|halt|operator|cybadmin'`
if  [ "$VALUE" = 'root,cybadmin' ] && [ -z "$VALUE2" ] && [ -z "$VALUE3" ]
        then
        VALUE2=`grep root /etc/passwd`
        VALUE3=`grep cybadmin /etc/passwd`
        VALUE="getent group 0<BR>$VALUE<BR><BR>egrep 'root|cybadmin'<BR>$VALUE2<BR>$VALUE3"
        status="Compliant"
else

        VALUE="Only root and cybadmin can use userID and groupID '0'<BR>getent group 0<BR>$VALUE<BR><BR>cat /etc/passwd |grep :0:<BR>$VALUE2<BR>$VALUE3"
        status="Non-Compliant"
        fi

DescItem="Group ID / User ID "
Policy="Only root and cybadmin is in user & group id 0 'zero'"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc

###################################################################################################
###################################################################################################
# AD.2.1.2_B3 /etc/pam.d/other (Enforce a default no access policy)

VALUE=`grep "auth[[:blank:]]*required[[:blank:]]*pam_deny.so" /etc/pam.d/other | grep -v ^#`
VALUE1=`grep "account[[:blank:]]*required[[:blank:]]*pam_deny.so" /etc/pam.d/other | grep -v ^#`
if [ -n "$VALUE" ] && [ -n "$VALUE1" ] ; then
        VALUE="grep 'auth required pam_deny.so' /etc/pam.d/other<BR>$VALUE<BR><BR>grep 'account required pam_deny.so' /etc/pam.d/other<BR>$VALUE1"
        status="Compliant"
else
        VALUE="Entry not found on /etc/pam.d/other<BR><BR>auth required pam_deny.so<BR>account required  pam_deny.so"
        status="Non-Compliant"
    fi

DescItem="Enforce a default no access policy"
Policy="The entry below should exist in /etc/pam.d/other<BR><BR>auth required pam_deny.so<BR>account required  pam_deny.so "
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc

################################################################################################
# 2.1.2.B4 Commands which allow shell escape
grep NOEXEC /etc/sudoers | grep 'ALL ALL'  > /dev/null 2>&1
if [ $? -eq 0 ]
   then
        egrep '^vi|^su|^ksh|^bash' /etc/sudoers > /dev/null 2>&1
        if [ $? -eq 1 ]
        then
        VALUE="ALL ALL=  NOEXEC:C_EXEC<BR>vi, su, ksh, bash commands not found"
        status="Compliant"
        else
        VALUE="ALL ALL=  NOEXEC:C_EXEC<BR>vi, su, ksh, bash commands found<BR>Please remove the entry"
        status="Non-Compliant"
        fi
else
        VALUE="ALL ALL=  NOEXEC:C_EXEC not found<BR>vi, su, ksh, bash commands found<BR>Please remove the entry"
        status="Non-Compliant"
fi
DescItem="Commands which allow shell escape"
Policy="Sudo access to commands which are able to escape to a shell must be limited by the implementation of the "noexec" function in software, where supported.<BR><BR>The provider of service must approve and document instances in which "noexec" is not implemented due to software limitations.<BR><BR>In situations where "noexec" is not implemented for a particular command, approval of that sudo access must include justification for the user having access to a command shell.<BR><BR>Following commands are not allowed: vi, su, ksh, bash"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status"  >> $LOG_DIR/$hc


################################################################################################
# 2.1.2.B5 Specific commands/programs executed via sudo

CKSUDO=`cksum $SUDO | awk '{print $1}'`
if [ $CKSUDO -ne 1990700224 ]
  then
        echo "SUDOERS File Checksum not matching with approved version<br />" > $TYDIR/sdrs.lst
        status="Non-Compliant"
else
        echo "SUDOERS File Checksum matching with approved version<br />" > $TYDIR/sdrs.lst
        status="Compliant"
fi

cat $SUDO >> $TYDIR/sdrs.lst
`IFS=",";while read -r line;do echo "<br />$line" >> $TYDIR/sdrs.out; done < $TYDIR/sdrs.lst`

DescItem="Specific commands/programs executed via sudo"
Policy="Commands/programs called via sudo:<BR>1.Must be listed by its full path in sudoers.<BR>2.If it will be run as root, the command/program must satisfy one of these two conditions:<BR>* Must be a standard operating system component with ownership and permissions that are compliant with the applicable OS tech spec's OSR requirements, or<BR>* Must only be writable by root.<BR>3.Check against the latest approved version<BR><BR>Note: This row does not apply to users granted access to run all commands via the ALL statement."
DrawItem "$DescItem" "$Policy" "`cat $TYDIR/sdrs.out`" "$status" >> $LOG_DIR/$hc
rm -rf $TYDIR/sdrs.lst
rm -rf $TYDIR/sdrs.out
################################################################################################
# 2.1.2.C Preventing Nested Sudo invocation
VALUE1=`grep 'Cmnd_Alias SUDOSUDO' $SUDO | awk '{print $4,$5,$6}'`
VALUE3="/usr/local/bin/sudo, /usr/bin/sudo, /bin/sudo"
VALUE2=`grep '!SUDOSUDO' $SUDO | awk '{print $3}'`
VALUE4="!SUDOSUDO"
if [ "$VALUE1" == "$VALUE3" ]
  then
   if [ "$VALUE2" == "$VALUE4"  ]
    then
   VALUE1=`grep 'Cmnd_Alias SUDOSUDO' $SUDO`
   VALUE2=`grep '!SUDOSUDO' $SUDO`
   VALUE="$VALUE1<BR>$VALUE1"
   status="Compliant"
  else
        VALUE="ALL ALL=!SUDOSUDO Not Found"
        status="Non-Compliant"
  fi
else
   VALUE="All valid paths to sudo executables not added to SUDOSUDO"
   status="Non-Compliant"
fi
DescItem="Preventing Nested Sudo invocation"
Policy="All valid paths to sudo executables must be added to SUDOSUDO<BR>The following line must be the last effective line in the sudo configuration file<BR>ALL ALL=!SUDOSUDO"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc


################################################################################################
 echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>2.1.3) Other Network Settings</b></td></tr>" >> $LOG_DIR/$hc

################################################################################################
#AD.2.2 Network File System (NFS) System Settings

VALUE1=`hostname | cut -c5-9`
VALUE2=`hostname | egrep -i "mxrap|mxtra"`
VALUE3=`ls -lt /etc/exports | awk '{print $9}'`
if [ "$VALUE1" = 'mxrap' ]
        then
        VALUE3=`ls -lt /etc/exports`
        VALUE="This is approved deviation for `hostname` server<BR><BR>$VALUE3"
elif [ "$VALUE1" = 'mxtra' ]
        then
        VALUE3=`ls -lt /etc/ |grep exports`
        VALUE="This is approved deviation for `hostname` server<BR><BR>$VALUE3"
elif [ -z "$VALUE2" ]
        then
        if [ -f /etc/exports ]
                then
                VALUE="NFS is not Allowed, otherwise get approval for deviation<BR><BR>`ls -la /etc/exports`"
                status="Non-Compliant"
        else
                VALUE="ls -la /etc/exports<BR>ls: cannot access /etc/exports: No such file or directory"
                status="Compliant"
        fi
fi

DescItem="Network File System (NFS)<BR>/etc/exports"
Policy="Not Allowed<BR><BR>/etc/exports must be removed"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc


 ################################################################################################
#AV.2.1.2b UNIX Platforms - SSH Server
if [ $TYPE == "NORM" ] || [ $TYPE == "NODE" ]
then
  VALUE1=`ls -lt /etc/ssh/sshd_config | awk '{print $1,$3}'`
  VALUE2=`ls -lt /etc/ssh/ssh_config | awk '{print $1,$3}'`
  VALUE3=`ls -lt /etc/ssh/ssh_host_dsa_key | awk '{print $1,$3}'`
  VALUE4=`ls -lt /etc/ssh/ssh_host_rsa_key | awk '{print $1,$3}'`
  VALUE5=`ls -lt /etc/ssh/ssh_host_dsa_key.pub | awk '{print $1,$3}'`
  VALUE6=`ls -lt /etc/ssh/ssh_host_rsa_key.pub | awk '{print $1,$3}'`
  VALUE7=`ls -lt /etc/pam.d/sshd | awk '{print $1,$3}'`
  if [ "$VALUE1" = "-rw------- root" ] && [ "$VALUE2" = "-r--r--r-- root" ] && [ "$VALUE3" = "-rw------- root" ] && [ "$VALUE4" = "-rw------- root" ] && [ "$VALUE5" = "-rw-r--r-- root" ] && [ "$VALUE6" = "-rw-r--r-- root" ] && [ "$VALUE7" = "-r-------- root" ]
        then
          VALUE="`ls -lt /etc/ssh/sshd_config | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh/ssh_config | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh/ssh_host_dsa_key | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh/ssh_host_rsa_key | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh/ssh_host_dsa_key.pub | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh/ssh_host_rsa_key.pub | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/pam.d/sshd | awk '{print $1,$3,$9}'`"
          status="Compliant"
        else
          VALUE="`ls -lt /etc/ssh/sshd_config | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh/ssh_config | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh/ssh_host_dsa_key | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh/ssh_host_rsa_key | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh/ssh_host_dsa_key.pub | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh/ssh_host_rsa_key.pub | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/pam.d/sshd | awk '{print $1,$3,$9}'`"
          status="Non-Compliant"
        fi
elif [ $TYPE == "TECTIA" ]
then
  VALUE1=`ls -lt /etc/ssh2/ssh-broker-config.xml | awk '{print $1,$3}'`
  VALUE2=`ls -lt /etc/ssh2/ssh-server-config.xml | awk '{print $1,$3}'`
  VALUE3=`ls -lt /etc/ssh2/hostkey | awk '{print $1,$3}'`
  VALUE4=`ls -lt /etc/ssh2/hostkey.pub | awk '{print $1,$3}'`
  VALUE5=`ls -lt /etc/ssh2/radius_config | awk '{print $1,$3}'`
  if [ "$VALUE1" = "-r--r--r-- root" ] && [ "$VALUE2" = "-rw------- root" ] && [ "$VALUE3" = "-rw------- root" ] && [ "$VALUE4" = "-rw-r--r-- root" ] && [ "$VALUE5" = "-r-------- root" ]
        then
          VALUE="`ls -lt /etc/ssh2/ssh-broker-config.xml | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh2/ssh-server-config.xml | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh2/hostkey | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh2/hostkey.pub | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh2/radius_config | awk '{print $1,$3,$9}'`"
          status="Compliant"
        else
          VALUE="`ls -lt /etc/ssh2/ssh-broker-config.xml | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh2/ssh-server-config.xml | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh2/hostkey | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh2/hostkey.pub | awk '{print $1,$3,$9}'`<BR>`ls -lt /etc/ssh2/radius_config | awk '{print $1,$3,$9}'`"
          status="Non-Compliant"
        fi
fi
DescItem="UNIX Platforms - SSH Server Configuration File<BR><BR><b>For F-Secure SSH</b><BR>/etc/ssh2/sshd2_config<BR>/etc/ssh2/ssh2_config<BR>/etc/ssh2/hostkey<BR>/etc/ssh2/hostkey.pub<BR>/etc/ssh2/subconfig<BR>/etc/ssh2/radius_config<BR><BR><b>For Tectia SSH</b><BR>/etc/ssh2/ssh-server-config.xml<BR>/etc/ssh2/ssh-broker-config.xm<BR>/etc/ssh2/hostkey<BR>/etc/ssh2/hostkey.pub<BR>/etc/ssh2/radius_config<BR><BR><b>For Redhat Linux:</b><BR>/etc/ssh/sshd_config<BR>/etc/ssh/ssh_config<BR>/etc/ssh/ssh_host_*_key<BR>/etc/ssh/ssh_host_*_key.pub<BR>/etc/ssh2/radius_config<BR><BR><b>For VIO:</b><BR>/etc/ssh/sshd_config<BR>/etc/ssh/ssh_config<BR>/etc/ssh/ssh_host_*_key<BR>c/ssh/ssh_host_*_key.pub /etc/ssh2/radius_config"
Policy="<b>For F-Secure SSH</b><BR>Owner: ROOT<BR>Must not be world writable<BR>Permission 600 : sshd2_config<BR>Permission 444 : ssh2_config<BR>Permission 600 : hostkey<BR>Permission 644 : hostkey.pub<BR>Permission 755 : subconfig<BR>Permission 400 : radius_config<BR><BR><b>For Tectia SSH</b><BR>Owner ROOT<BR>Must not be world writable<BR>Permission 600 : ssh-server-config.xml<BR>Permission 444: ssh-broker-config.xml<BR>Permission 600 : hostkey<BR>Permission 644 : hostkey.pub<BR>Permission 400 : radius_config<BR><BR><b>For  Redhat Linux:</b><BR>Owner: ROOT<BR>Must not be world writable<BR>Permission 600 : /etc/ssh/sshd_config<BR>Permission 444 : /etc/ssh/ssh_config<BR>Permission 600 : /etc/ssh/ssh_host_*_key<BR>Permission 644 : /etc/ssh/ssh_host_*_key.pub<BR>Permission 400 : radius_config<BR><BR><b>For VIO:</b><BR>Owner: ROOT<BR>Must not be world writable<BR>Permission 600 : /etc/ssh/sshd_config<BR>Permission 444 : /etc/ssh/ssh_config<BR>Permission 600 : /etc/ssh/ssh_host_*_key<BR>Permission 644 : /etc/ssh/ssh_host_*_key.pub"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc

################################################################################################
#AV.2.1.3c Encryption Type: Protection of Private Keys
echo " " > $LOG_DIR/output
if [ $TYPE == "NORM" ] || [ $TYPE == "NODE" ]
then
  VALUE=`grep 1024bit /root/.ssh/id_dsa.pub`
    if [ -n "$VALUE" ]
        then
                  VALUE="grep 1024bit /root/.ssh/id_dsa.pub<BR>$VALUE"
          status="Compliant"
        else
          VALUE="grep 1024bit /root/.ssh/id_dsa.pub<BR>public key is non 1024bit"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
   VALUE=`grep 2048-bit /root/.ssh2/id_dsa_2048_a.pub`
    if [ -n "$VALUE" ]
        then
          VALUE="cat /root/.ssh2/id_dsa_2048_a.pub"
          cat /root/.ssh2/id_dsa_2048_a.pub > $LOG_DIR/temp
          while read -r line;do echo "<BR>$line" >> $LOG_DIR/output; done < $LOG_DIR/temp
          status="Compliant"
        else
          VALUE="cat /root/.ssh2/id_dsa_2048_a.pub"
          cat /root/.ssh2/id_dsa_2048_a.pub > $LOG_DIR/temp
          while read -r line;do echo "<BR>$line" >> $LOG_DIR/output; done < $LOG_DIR/temp
          status="Non-Compliant"
    fi
fi

DescItem="Encryption Type: Protection of Private Keys<BR>Encryption Facility: DSA"
Policy="Use DSA with a minimum key length of 1024 or higher key length where supported."
DrawItem "$DescItem" "$Policy" "$VALUE`cat $LOG_DIR/output`" "$status" >> $LOG_DIR/$hc
rm -rf $LOG_DIR/output


################################################################################################
# 2.1.3.A Sudoers File
VALUE1=`ls -l /usr/sbin/visudo|awk '{print $1}'`
VALUE2="---x--x--x"
if [ "$VALUE1" = "$VALUE2" ]
then
  status="Compliant"
  VALUE="`ls -l /usr/sbin/visudo`"
else
 VALUE="`ls -l /usr/sbin/visudo`"
  status="Non-Compliant"
fi
DescItem="sudoers file <BR>
&#40;Or, the active visudo file if it is stored elsewhere.&#41;"
Policy="MUST be edited with the 'visudo' command as root"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status"  >> $LOG_DIR/$hc


################################################################################################
# 2.1.3.B /etc/sudoers /usr/bin/sudo
VALUE1=`ls -l /etc/sudoers|awk '{print $1}'`
VALUE2="-r--r-----"
VALUE3=`ls -l /usr/bin/sudo|awk '{print $1}'`
VALUE4="---s--x--x"
if [ $VALUE1 == $VALUE2 ] && [ $VALUE3 == $VALUE4 ]
then
  status="Compliant"
else
  status="Non-Compliant"
fi
DescItem="/etc/sudoers, /usr/bin/sudo &#40;Or, the active sudoers file if it is stored elsewhere.&#41;"
Policy="File must be treated as an OSR subject to the requirements in GSD331, and in the applicable OS Technical Specification<BR>Permission of /etc/sudoers and /usr/bin/sudo<BR>/etc/sudoers:  -r--r-----     root:root<BR>/usr/bin/sudo: ---s--x--x   root:root"
DrawItem "$DescItem" "$Policy" "`ls -ltr /etc/sudoers`<BR>`ls -ltr /usr/bin/sudo`" "$status"  >> $LOG_DIR/$hc



################################################################################################

 echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>2.1.4) Berkeley Remote Access Commands</b></td></tr>" >> $LOG_DIR/$hc

#AD.2.1.4_A /etc/hosts.equiv
#
echo "<tr><td colspan=4><br><b>Berkeley Remote Access Commands System Settings</b></td></tr>" >> $LOG_DIR/$hc

VALUE=`ls -l /etc/|grep -i equiv | awk '{print $9}'`
if [ -z "$VALUE" ]; then VALUE="ls: /etc/hosts.equiv: No such file or directory"
        status="Compliant"
else
        VALUE=`ls -la /etc/hosts.equiv`
        status="Non-Compliant"
        fi

DescItem="Remove host trust relationship"
Policy="Remove host trust relationship, Remove the file<BR>/etc/hosts.equiv"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc

################################################################################################
#AD.2.1.4_B /etc/pam.d/rlogin, /etc/pam.d/rsh

VALUE1=`ls -l /etc/pam.d/ |grep rlogin | awk '{print $9}'`
VALUE2=`ls -l /etc/pam.d/ | grep rsh | awk '{print $9}'`
VALUE3=`rpm -qa |grep rsh`
VALUE4=`rpm -qa |grep rlogin`
if [ -z "$VALUE1" ] && [ -z "$VALUE2" ] && [ -z "$VALUE3" ] && [ -z "$VALUE4" ]; then
    VALUE1="ls -la /etc/pam.d/rlogin<BR>ls: /etc/pam.d/rlogin: No such file or directory"
        VALUE2="ls -la /etc/pam.d/rsh<BR>ls: /etc/pam.d/rsh: No such file or directory"
        VALUE3="rpm -qa |egrep rsh<BR>No Packages installed"
        VALUE4="rpm -qa |grep rlogin<BR>No Packages installed"
        VALUE5="$VALUE3<BR>$VALUE4<BR>$VALUE1<BR>$VALUE2"
        status="Compliant"
else
        VALUE1=`ls -l /etc/pam.d/* |grep rlogin`
        VALUE2=`ls -l /etc/pam.d/* |grep rsh`
        VALUE3=`rpm -qa |grep rsh`
        VALUE4=`rpm -qa |grep rlogin`
        VALUE5="Remove the following:<BR><BR>rpm -qa |egrep 'rsh|rlogin'<BR>$VALUE3<BR>$VALUE4<BR>$VALUE1<BR>$VALUE2"
    status="Non-Compliant"
fi

DescItem="Remote login not allowed."
Policy="Remove remote login related packages<BR><BR>/etc/pam.d/rlogin<BR>/etc/pam.d/rsh"
DrawItem "$DescItem" "$Policy" "$VALUE5" "$status" >> $LOG_DIR/$hc

################################################################################################
# AD.2.1.4_C  <$HOME>/.rhosts
VALUE=`find /home/* -maxdepth 2 -name .rhosts`
VALUE1=`find /home/* -maxdepth 2 -name .netrc`
if [ -z "$VALUE" ] && [ -z "$VALUE1" ] ; then
        VALUE="find /home/* -maxdepth 2 -name .rhosts<BR>Not found<BR><BR>find /home/* -maxdepth 2 -name .netrc<BR>Not found"
        VALUE1="find /root/* -maxdepth 2 -name .rhosts<BR>Not found<BR><BR>find /root/* -maxdepth 2 -name .netrc<BR>Not found"
        status="Compliant"
else
        status="Non-Compliant"
        fi
DescItem="< HOME>/.netrc file<BR>< HOME>/.rhosts file<BR>/root/.rhosts<BR>/root/.netrc"
Policy="Not Allowed<BR><BR>(delete the hidden file .netrc and . rhosts<BR>in all user home folders and /root folder )"
DrawItem "$DescItem" "$Policy" "$VALUE<BR><BR>$VALUE1" "$status" >> $LOG_DIR/$hc


#AV.2.1.4a TCPKeepAlive
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^TCPKeepAlive /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^TCPKeepAlive /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^TCPKeepAlive /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^TCPKeepAlive /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = yes ] && [ "$VALUE2" = yes ] && [ "$VALUE3" = yes ] && [ "$VALUE4" = yes ]
        then
        VALUE="grep ^TCPKeepAlive /etc/ssh/sshd_config<BR>TCPKeepAlive $VALUE1<BR><BR>grep ^TCPKeepAlive /etc/ssh/sshd_config_vascop<BR>TCPKeepAlive $VALUE2<BR><BR>grep ^TCPKeepAlive /etc/ssh/sshd_config_vascos<BR>TCPKeepAlive $VALUE3<BR><BR>grep ^TCPKeepAlive /etc/ssh/sshd_config_ca<BR>TCPKeepAlive $VALUE4"
          status="Compliant"
        else
         VALUE="grep ^TCPKeepAlive /etc/ssh/sshd_config<BR>TCPKeepAlive $VALUE1<BR><BR>grep ^TCPKeepAlive /etc/ssh/sshd_config_vascop<BR>TCPKeepAlive $VALUE2<BR><BR>grep ^TCPKeepAlive /etc/ssh/sshd_config_vascos<BR>TCPKeepAlive $VALUE3<BR><BR>grep ^TCPKeepAlive /etc/ssh/sshd_config_ca<BR>TCPKeepAlive $VALUE4"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^TCPKeepAlive /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = yes ]
                then
          VALUE="grep ^TCPKeepAlive /etc/ssh/sshd_config<BR>TCPKeepAlive $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^TCPKeepAlive /etc/ssh/sshd_config<BR>TCPKeepAlive $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
   VALUE=`grep 'tcp-keepalive' /etc/ssh2/ssh-server-config.xml | awk -F\" '{print $(NF-1)}'`
    if [ "$VALUE" = yes ]
        then
          VALUE="grep 'tcp-keepalive' /etc/ssh2/ssh-server-config.xml<BR>`grep 'tcp-keepalive' /etc/ssh2/ssh-server-config.xml | sed 's/>/\&gt;/g' | sed 's/</\&lt;/g'`"
          status="Compliant"
        else
          VALUE="grep 'tcp-keepalive' /etc/ssh2/ssh-server-config.xml<BR>`grep 'tcp-keepalive' /etc/ssh2/ssh-server-config.xml | sed 's/>/\&gt;/g' | sed 's/</\&lt;/g'`"
          status="Non-Compliant"
    fi
fi
DescItem="<b>KeepAlive:</b><BR>Configures the server to send TCP TCPKeepAlive messages to the client and cleanup crashed sessions to prevent indefinitely hanging sessions<BR><BR>SSHv7 for WIN : TCPKeepAlive"
Policy="<b>YES</b><BR><BR>SSHv7 for WIN : set to 60 (seconds)"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc



################################################################################################
#AV.2.1.4b MaxConnections
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^MaxStartups /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^MaxStartups /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^MaxStartups /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^MaxStartups /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = 50 ] && [ "$VALUE2" = 50 ] && [ "$VALUE3" = 50 ] && [ "$VALUE4" = 50 ]
        then
                  VALUE="grep ^MaxStartups /etc/ssh/sshd_config<BR>MaxStartups $VALUE1<BR><BR>grep ^MaxStartups /etc/ssh/sshd_config_vascop<BR>MaxStartups $VALUE2<BR><BR>grep ^MaxStartups /etc/ssh/sshd_config_vascos<BR>MaxStartups $VALUE3<BR><BR>grep ^MaxStartups /etc/ssh/sshd_config_ca<BR>MaxStartups $VALUE4"
          status="Compliant"
        else
                  VALUE="grep ^MaxStartups /etc/ssh/sshd_config<BR>MaxStartups $VALUE1<BR><BR>grep ^MaxStartups /etc/ssh/sshd_config_vascop<BR>MaxStartups $VALUE2<BR><BR>grep ^MaxStartups /etc/ssh/sshd_config_vascos<BR>MaxStartups $VALUE3<BR><BR>grep ^MaxStartups /etc/ssh/sshd_config_ca<BR>MaxStartups $VALUE4"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^MaxStartups /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = 50 ]
                then
          VALUE="grep ^MaxStartups /etc/ssh/sshd_config<BR>MaxStartups $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^MaxStartups /etc/ssh/sshd_config<BR>MaxStartups $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
   VALUE=`grep 'max-connections' /etc/ssh2/ssh-server-config.xml | awk -F\" '{print $(NF-3)}'`
    if [ "$VALUE" = 50 ]
        then
          VALUE="grep 'max-connections' /etc/ssh2/ssh-server-config.xml<BR>`grep 'max-processes' /etc/ssh2/ssh-server-config.xml | sed 's/>/\&gt;/g' | sed 's/</\&lt;/g'`"
          status="Compliant"
        else
          VALUE="grep 'max-connections' /etc/ssh2/ssh-server-config.xml<BR>`grep 'max-processes' /etc/ssh2/ssh-server-config.xml | sed 's/>/\&gt;/g' | sed 's/</\&lt;/g'`"
          status="Non-Compliant"
    fi
fi
DescItem="<b>MaxConnections</b><BR>(F-Secure/SSH Communications Only):<BR>The maximum number of simultaneous sessions that can be open to the server.<BR><BR>SSHv7 for WIN : MaximumConnection"
Policy="<b>50</b>"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc
################################################################################################
#AV.2.1.4c Business Use Notice
if [ $TYPE == "NORM" ]
then
        VALUE1=`grep ^PrintMotd /etc/ssh/sshd_config | awk '{print $2}'`
        VALUE2=`grep ^PrintMotd /etc/ssh/sshd_config_vascop | awk '{print $2}'`
        VALUE3=`grep ^PrintMotd /etc/ssh/sshd_config_vascos | awk '{print $2}'`
        VALUE4=`grep ^PrintMotd /etc/ssh/sshd_config_ca | awk '{print $2}'`
        if [ "$VALUE1" = yes ] && [ "$VALUE2" = yes ] && [ "$VALUE3" = yes ] && [ "$VALUE4" = yes ]
        then
                  VALUE="grep ^PrintMotd /etc/ssh/sshd_config<BR>PrintMotd $VALUE1<BR><BR>grep ^PrintMotd /etc/ssh/sshd_config_vascop<BR>PrintMotd $VALUE2<BR><BR>grep ^PrintMotd /etc/ssh/sshd_config_vascos<BR>PrintMotd $VALUE3<BR><BR>grep ^PrintMotd /etc/ssh/sshd_config_ca<BR>PrintMotd $VALUE4"
          status="Compliant"
        else
                  VALUE="grep ^PrintMotd /etc/ssh/sshd_config<BR>PrintMotd $VALUE1<BR><BR>grep ^PrintMotd /etc/ssh/sshd_config_vascop<BR>PrintMotd $VALUE2<BR><BR>grep ^PrintMotd /etc/ssh/sshd_config_vascos<BR>PrintMotd $VALUE3<BR><BR>grep ^PrintMotd /etc/ssh/sshd_config_ca<BR>PrintMotd $VALUE4"
          status="Non-Compliant"
    fi
elif [ $TYPE == "NODE" ]
then
        VALUE1=`grep ^PrintMotd /etc/ssh/sshd_config | awk '{print $2}'`
        if [ "$VALUE1" = yes ]
                then
          VALUE="grep ^PrintMotd /etc/ssh/sshd_config<BR>PrintMotd $VALUE1"
          status="Compliant"
        else
          VALUE="grep ^PrintMotd /etc/ssh/sshd_config<BR>PrintMotd $VALUE1"
          status="Non-Compliant"
    fi
elif [ $TYPE == "TECTIA" ]
then
   VALUE=`grep 'print-motd' /etc/ssh2/ssh-server-config.xml | awk -F\" '{print $(NF-1)}'`
    if [ "$VALUE" = yes ]
        then
          VALUE="grep 'print-motd' /etc/ssh2/ssh-server-config.xml<BR>`grep 'print-motd' /etc/ssh2/ssh-server-config.xml | sed 's/>/\&gt;/g' | sed 's/</\&lt;/g'`"
          status="Compliant"
        else
          VALUE="grep 'print-motd' /etc/ssh2/ssh-server-config.xml<BR>`grep 'print-motd' /etc/ssh2/ssh-server-config.xml | sed 's/>/\&gt;/g' | sed 's/</\&lt;/g'`"
          status="Non-Compliant"
    fi
fi

DescItem="<b>Business Use Notice</b>"
Policy="The PrintMotd option must be set to "yes".<BR><BR>SSHv7 for WIN : BannerMessageFile"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc





################################################################################################
 echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>2.1.5)  Unnecessary Services</b></td></tr>" >> $LOG_DIR/$hc
################################################################################################
# AD.2.1.5_A Services must be disabled

/sbin/chkconfig --list > $tdir/chk_out

VALUE1=`hostname | grep mxtra`
VALUE2=`egrep -w 'pop2|pop3|tftp|pop-2|nntp|chargen|daytime|discard|echo|finger|talk|who|whois|new-rwho|klogin|eklogin|rlogin|systat|netstat|time|finger|talk|who|whois|new-rwho|klogin|eklogin|systat|bootps|bootpc|kerberos|imap|ldap|netbios-ns|netbios-dgm|netbios-ssn|NeWS|mobile-ip|exec|login|shell|printer|courier|uucp|biff|ripng|kshell|rmonitor|^monitor|fs|kerberos-adm|kerberos-iv|krb5_prop|ike|ldaps|iso-tsap|uucp-path|^snmpd|www-ldap-gw|lockd|^nfsd|yppasswd|nis+|ypserv|ypbind|dovecot|nntp' $tdir/chk_out|grep -i on | awk '{print $1}'`
VALUE3=`egrep -w 'pop2|pop3|tftp|pop-2|nntp|chargen|daytime|discard|echo|finger|talk|who|whois|new-rwho|klogin|eklogin|rlogin|systat|netstat|time|finger|talk|who|whois|new-rwho|klogin|eklogin|systat|bootps|bootpc|kerberos|imap|ldap|netbios-ns|netbios-dgm|netbios-ssn|NeWS|mobile-ip|exec|login|shell|printer|courier|uucp|biff|ripng|kshell|rmonitor|^monitor|fs|kerberos-adm|kerberos-iv|krb5_prop|ike|ldaps|iso-tsap|uucp-path|^snmpd|www-ldap-gw|lockd|^nfsd|yppasswd|nis+|ypserv|ypbind|dovecot|nntp' $tdir/chk_out|grep -i on`

if [ -n "$VALUE1" ] && [ "$VALUE2" == "tftp:" ]
                then
                VALUE1="TFTP service is approved deviation on `hostname` server"
                VALUE2="chkconfig --list| egrep -w 'pop2|pop3|tftp|pop-2|nntp|chargen|daytime|discard|echo|finger|talk|who|whois|new-rwho|klogin|eklogin|rlogin|systat|netstat|time|finger|talk|who|whois|new-rwho|klogin|eklogin|systat|bootps|bootpc|kerberos|imap|ldap|netbios-ns|netbios-dgm|netbios-ssn|NeWS|mobile-ip|exec|login|shell|printer|courier|uucp|biff|ripng|kshell|rmonitor|^monitor|fs|kerberos-adm|kerberos-iv|krb5_prop|ike|ldaps|iso-tsap|uucp-path|snmpd|www-ldap-gw|lockd|^nfsd|yppasswd|nis+|ypserv|ypbind|dovecot|nntp'<BR><BR>Service running<BR><BR>$VALUE3"
                VALUE="$VALUE1<BR><BR>$VALUE2"
                status="Compliant"

        elif [ -z "$VALUE1" ] && [ -z "$VALUE2" ]
                then
                VALUE="chkconfig --list| egrep -w 'pop2|pop3|tftp|pop-2|nntp|chargen|daytime|discard|echo|finger|talk|who|whois|new-rwho|klogin|eklogin|rlogin|systat|netstat|time|finger|talk|who|whois|new-rwho|klogin|eklogin|systat|bootps|bootpc|kerberos|imap|ldap|netbios-ns|netbios-dgm|netbios-ssn|NeWS|mobile-ip|exec|login|shell|printer|courier|uucp|biff|ripng|kshell|rmonitor|^monitor|fs|kerberos-adm|kerberos-iv|krb5_prop|ike|ldaps|iso-tsap|uucp-path|snmpd|www-ldap-gw|lockd|^nfsd|yppasswd|nis+|ypserv|ypbind|dovecot|nntp'<BR><BR>No service found running"
                status="Compliant"
        elif [ -z "$VALUE1" ] && [ -n "$VALUE2" ]
                then
                VALUE2="chkconfig --list| egrep -w 'pop2|pop3|tftp|pop-2|nntp|chargen|daytime|discard|echo|finger|talk|who|whois|new-rwho|klogin|eklogin|rlogin|systat|netstat|time|finger|talk|who|whois|new-rwho|klogin|eklogin|systat|bootps|bootpc|kerberos|imap|ldap|netbios-ns|netbios-dgm|netbios-ssn|NeWS|mobile-ip|exec|login|shell|printer|courier|uucp|biff|ripng|kshell|rmonitor|^monitor|fs|kerberos-adm|kerberos-iv|krb5_prop|ike|ldaps|iso-tsap|uucp-path|snmpd|www-ldap-gw|lockd|^nfsd|yppasswd|nis+|ypserv|ypbind|dovecot|nntp'<BR><BR>Service must be disable<BR><BR>$VALUE3"
                VALUE="$VALUE2 "
                status="Non-Compliant"
fi

DescItem="Services must be disabled"
Policy="Following services must be disabled or removed<BR><BR>pop2 pop3 pop-2 nntp chargen daytime discard echo finger talk who whois new-rwho klogin eklogin rlogin systat netstat time finger talk who whois new-rwho klogin eklogin systat bootps bootpc kerberos imap ldap netbios-ns netbios-dgm netbios-ssn NeWS mobile-ip exec login shell printer courier uucp biff ripng kshell rmonitor monitor fs kerberos-adm kerberos-iv krb5_prop ike ldaps iso-tsap uucp-path snmpd www-ldap-gw lockd nfsd yppasswd nis+ ypserv ypbind dovecot nntp"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc

################################################################################################
echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>2.1.6) Other Settings</b></td></tr>" >> $LOG_DIR/$hc
################################################################################################
# AD 2.1.6_A /etc/sysctl.conf

VALUE=`grep -i net.ipv4.tcp_syncookies /etc/sysctl.conf|cut -d"=" -f2`
VALUE1=`grep -i net.ipv4.icmp_echo_ignore_broadcasts /etc/sysctl.conf| cut -d"=" -f2`
VALUE2=`grep -i net.ipv4.conf.all.accept_redirects /etc/sysctl.conf| cut -d"=" -f2`

if [ "$VALUE" == " 1" ] && [ "$VALUE1" == " 1" ] && [ "$VALUE2" == " 0" ] ; then
        VALUE=`grep -i net.ipv4.tcp_syncookies /etc/sysctl.conf`
        VALUE1=`grep -i net.ipv4.icmp_echo_ignore_broadcasts /etc/sysctl.conf`
        VALUE2=`grep -i net.ipv4.conf.all.accept_redirects /etc/sysctl.conf`
        VALUE3="grep -i net.ipv4.tcp_syncookies /etc/sysctl.conf<BR>$VALUE<BR><BR>grep -i net.ipv4.icmp_echo_ignore_broadcasts /etc/sysctl.conf<BR>$VALUE1<BR><BR>grep -i net.ipv4.conf.all.accept_redirects /etc/sysctl.conf<BR>$VALUE2"
        status="Compliant"
else
        VALUE=`grep -i net.ipv4.tcp_syncookies /etc/sysctl.conf`
        VALUE1=`grep -i net.ipv4.icmp_echo_ignore_broadcasts /etc/sysctl.conf`
        VALUE2=`grep -i net.ipv4.conf.all.accept_redirects /etc/sysctl.conf`
        VALUE3="grep -i net.ipv4.tcp_syncookies /etc/sysctl.conf<BR>$VALUE<BR><BR>grep -i net.ipv4.icmp_echo_ignore_broadcasts /etc/sysctl.conf<BR>$VALUE1<BR><BR>grep -i net.ipv4.conf.all.accept_redirects /etc/sysctl.conf<BR>$VALUE2"
    status="Non-Compliant"
fi

DescItem="/etc/sysctl.conf"
Policy="Note:<BR>Enable tcp syncookies to prevent syn flooding<BR><b>net.ipv4.tcp_syncookies = 1</b><BR><BR>Note:<BR>Turn off ICMP broadcasts<BR><b>net.ipv4.icmp_echo_ignore_broadcasts = 1</b><BR><BR>Note:<BR>Disable ICMP Redirect Acceptance<BR><b>net.ipv4.conf.all.accept_redirects = 0</b>"
DrawItem "$DescItem" "$Policy" "$VALUE3" "$status" >> $LOG_DIR/$hc

################################################################################################
# AD.2.1.6_B Disable Hardware (USB & CD/DVD Rom)
# Disable by ensuring that cdrom.ko do not exists in /lib/modules/*


VALUE=`find /lib/modules/ -name cdrom.ko`
VALUE2=`grep '^blacklist usb_storage' /etc/modprobe.d/blacklist`
if [ -z "$VALUE" ] && [ -n "$VALUE2" ] ; then
        VALUE3="cdrom.ko kernel object not found" >> $LOG_DIR/output1
        VALUE4="USB drive disabled" >> $LOG_DIR/output1
        VALUE1="<BR>$VALUE3<BR><BR>$VALUE4"
        status="Compliant"
else

        VALUE3=`find /lib/modules/ -name cdrom.ko > $LOG_DIR/temp2`
        while read -r line; do echo "<br />$line" >> $LOG_DIR/output1; done < $LOG_DIR/temp2
        VALUE4=`grep '^blacklist usb_storage' /etc/modprobe.d/blacklist`
        VALUE1="$VALUE3<BR><BR>$VALUE4<BR> Found on the blacklist file"
        status="Non-Compliant"
        fi

DescItem="Disable Hardware"
Policy="<b>USB drive</b> - Disable access to USB drive<BR>Add the following line 'blacklist usb_storage'<BR>in the file /etc/modprobe.d/blacklist<BR><BR><b>CD/DVD drive,</b> - Disable CD/DVD drive<BR>Disable by ensuring that cdrom.ko<BR>do not exists in /lib/modules/*"
DrawItem "$DescItem" "$Policy" "find /lib/modules/ -name cdrom.ko<BR>`cat $LOG_DIR/output1`<BR>$VALUE1" "$status" >> $LOG_DIR/$hc
rm -rf $LOG_DIR/output1
rm -rf $LOG_DIR/temp2

################################################################################################
# AD.2.1.6_C /etc/login.defs Must include this line: UMASK=077


VALUE=`cat /etc/login.defs|grep ^UMASK |awk '{print $2}'`

if [ "$VALUE" = "077" ] ; then
        VALUE1="UMASK 077"
        VALUE2="cat /etc/login.defs|grep ^UMASK<BR><BR>$VALUE1"
        status="Compliant"
else
        VALUE1=`cat /etc/login.defs|grep ^UMASK |awk '{print $2}'`
        VALUE2="cat /etc/login.defs|grep ^UMASK<BR><BR>$VALUE1"
        status="Non-Compliant"
        fi

DescItem="UMASK"
Policy="Must include this line:  UMASK=077 in /etc/login.defs"
DrawItem "$DescItem" "$Policy" "$VALUE2" "$status" >> $LOG_DIR/$hc

################################################################################################
echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>2.1.7) Protecting Resources - OSRs</b></td></tr>" >> $LOG_DIR/$hc
################################################################################################
# AD.2.1.7_A World writable files
# Find all orphans files and reassign ownership or delete them
# Ensure there are no Orphan Files in OSR /root /etc /usr /sbin /bin /lib

OSR="/root /etc /usr /usr/local /var /var/log /opt /sbin /bin"
APPDIR="murex|foglight|home|ego|ssim|jboss|icall|ismo|stcm|emctool|app|CA|DatacapApp|devt"
VALUE1=`find $OSR -perm -002 -type f -ls |egrep -v $APPDIR | awk '{print $3,$11}'`
if [ -z "$VALUE1" ] ; then
        status="Compliant"
        VALUE1="No world writable files/directories found" >> $LOG_DIR/output1

else
        VALUE1="Fix the world writable permission"
        VALUE2=`find $OSR -perm -002 -type f -ls |egrep -v $APPDIR | awk '{print $3,$11}'  > $LOG_DIR/temp1`
        while read -r line; do echo "<br />$line" >> $LOG_DIR/output1; done < $LOG_DIR/temp1
        status="Non-Compliant"
fi

DescItem="World writable files on OSR Directories<BR><BR>/root/*<BR>/etc/*<BR>/usr/*<BR>/usr/local/*<BR>/var/*<BR>/var/log/*<BR>/opt/*<BR>/sbin/*<BR>/bin/*"
Policy="Ensure there are no world writable files except in<BR><BR>/tmp/<BR>/var/tmp/<BR>/dev/shm/<BR>/proc/<BR>User Home Directories<BR>/home/"
DrawItem "$DescItem" "$Policy" "$VALUE1<BR><BR>`cat $LOG_DIR/output1`" "$status" >> $LOG_DIR/$hc
rm -rf $LOG_DIR/output1
rm -rf $LOG_DIR/temp1

################################################################################################
################################################################################################
# AD.2.1.7_B Orphan Files
# Find all orphans files and reassign ownership or delete them
# Ensure there are no Orphan Files in OSR /root /etc /usr /sbin /bin /lib

OSR="/root /etc /usr /usr/local /var /var/log /opt /sbin /bin"
APPDIR="murex|foglight|home|ego|ssim|jboss|icall|ismo|stcm|emctool|app|CA|DatacapApp|devt"
VALUE1=`find $OSR  \( -nogroup -o  -nouser \) -ls |egrep -v $APPDIR `
if [ -z "$VALUE1" ] ; then
        status="Compliant"
        VALUE1="No Orphan Files found on OSR Directories<BR>/root/*<BR>/etc/*<BR>/usr/*<BR>/usr/local/*<BR>/var/*<BR>/var/log/*<BR>/opt/*<BR>/sbin/*<BR>/bin/*" >> $LOG_DIR/output1
else

        VALUE1=`find $OSR \( -nogroup -o  -nouser \) -ls |egrep -v $APPDIR | awk '{print $3,$5,$6,$11}'  > $LOG_DIR/temp1`
        while read -r line; do echo "<br />$line" >> $LOG_DIR/output1; done < $LOG_DIR/temp1
        status="Non-Compliant"
fi

DescItem="Orphan Files on OSR Directories<BR><BR>/root/*<BR>/etc/*<BR>/usr/*<BR>/usr/local/*<BR>/var/*<BR>/var/log/*<BR>/opt/*<BR>/sbin/*<BR>/bin/*"
Policy="Find all orphans files and reassign ownership or delete them."
DrawItem "$DescItem" "$Policy" "`cat $LOG_DIR/output1`<BR>$VALUE1" "$status" >> $LOG_DIR/$hc
rm -rf $LOG_DIR/output1
rm -rf $LOG_DIR/temp1

################################################################################################
# AD.2.1.7_C OSR Directories
# Settings for other on this directory must be r-x or more stringent.

OSR="/root /etc /usr /usr/local /var /var/log /opt /sbin /bin"
VALUE=`find $OSR -type d  -a \( -perm -002 \) ! -perm 1777 -exec ls -ld {} \;`

if [ -z "$VALUE" ]
        then
        status="Compliant"
        VALUE1=`find $OSR -type d  -a \( -perm -002  \) ! -perm 1777 -exec ls -ld {} \; > $LOG_DIR/temp1`
        while read -r line; do echo "<br />$line" >> $LOG_DIR/output1; done < $LOG_DIR/temp1
else

        VALUE1=`find $OSR -type d  -a \( -perm -002 \) ! -perm 1777 -exec ls -ld {} \; > $LOG_DIR/temp1`
        while read -r line; do echo "<br />$line" >> $LOG_DIR/output1; done < $LOG_DIR/temp1
        status="Non-Compliant"
fi

DescItem="OSR Directories<BR><BR>/root/*<BR>/etc/*<BR>/usr/*<BR>/usr/local/*<BR>/var/*<BR>/var/log/*<BR>/opt/*<BR>/sbin/*<BR>/bin/*"
Policy="Settings for others on this Directory must be r-x or more stringent"
DrawItem "$DescItem" "$Policy" "`cat $LOG_DIR/output1`<BR>$VALUE1" "$status" >> $LOG_DIR/$hc
rm -rf $LOG_DIR/output1
rm -rf $LOG_DIR/temp1

################################################################################################
# Settings for directory below must be rwxrwxrwt (1777) /tmp /var/tmp
# AD.2.1.7_D /tmp /var/tmp

VALUE=`ls -ld /tmp | cut -c1-10`
VALUE1=`ls -ld /var/tmp | cut -c1-10`
if [ "$VALUE" = "drwxrwxrwt" ] && [ "$VALUE1" = "drwxrwxrwt" ] ; then
                VALUE=`ls -ld /tmp`
                VALUE1=`ls -ld /var/tmp`
                VALUE2="ls -ld /tmp /var/tmp<BR><BR>$VALUE<BR>$VALUE1"
                status="Compliant"
else
                VALUE=`ls -ld /tmp`
                VALUE1=`ls -ld /var/tmp`
                VALUE2="ls -ld /tmp /var/tmp<BR><BR>$VALUE<BR>$VALUE1"
        status="Non-Compliant"
        fi

DescItem="<b>Sticky Bit Settings</b><BR>/tmp<BR>/var/tmp"
Policy="Settings for this directory must be rwxrwxrwt (1777).<BR><BR>/tmp<BR>/var/tmp"
DrawItem "$DescItem" "$Policy" "<BR>$VALUE2" "$status" >> $LOG_DIR/$hc

################################################################################################
# The files must exist, and File permissions must be set:
# rw- --- --- (or more restrictive)
# AD.2.1.7_E  /etc/security/opasswd /var/log/faillog /var/log/tallylog

VALUEVER=`cat /etc/redhat-release | cut -d " " -f7|cut -c1`
VALUE=`ls -l /etc/security/opasswd | cut -c5-10`
VALUE2=`ls -l /var/log/faillog | cut -c5-10`
VALUE3=`ls -l /var/log/tallylog | cut -c5-10`

if [ "$VALUEVER" = "4" ]
        then
        if [ "$VALUE" = "------" ] && [ "$VALUE2" = "------" ] && [ "$VALUE3" = "------" ] ; then
                VALUE=`ls -l /etc/security/opasswd`
                VALUE1=`ls -l /etc/shadow`
                VALUE2=`ls -l /var/log/faillog`
                VALUE3=`ls -l /var/log/tallylog`
                VALUE4="RHEL 4<BR>ls -l /etc/security/opasswd /var/log/faillog /var/log/tallylog<BR><BR>$VALUE<BR>$VALUE2<BR>$VALUE3"
                status="Compliant"

        else
                VALUE=`ls -l /etc/security/opasswd`
                VALUE2=`ls -l /var/log/faillog`
                VALUE3=`ls -l /var/log/tallylog`
                VALUE4="RHEL 4<BR>ls -l /etc/security/opasswd /var/log/faillog /var/log/tallylog<BR><BR>$VALUE<BR>$VALUE2<BR>$VALUE3"
                status="Non-Compliant"
        fi
elif [ "$VALUEVER" = "5" ]
        then
        if [ "$VALUE" = "------" ] && [ "$VALUE2" = "------" ] && [ "$VALUE3" = "------" ] ; then
                VALUE=`ls -l /etc/security/opasswd`
                VALUE1=`ls -l /etc/shadow`
                VALUE2=`ls -l /var/log/faillog`
                VALUE3=`ls -l /var/log/tallylog`
                VALUE4="RHEL 5<BR>ls -l /etc/security/opasswd /var/log/faillog /var/log/tallylog<BR><BR>$VALUE<BR>$VALUE2<BR>$VALUE3"
                status="Compliant"

        else
                VALUE=`ls -l /etc/security/opasswd`
                VALUE2=`ls -l /var/log/faillog`
                VALUE3=`ls -l /var/log/tallylog`
                VALUE4="RHEL 5<BR>ls -l /etc/security/opasswd /var/log/faillog /var/log/tallylog<BR><BR>$VALUE<BR>$VALUE2<BR>$VALUE3"
                status="Non-Compliant"
        fi
elif [ "$VALUEVER" = "6" ] || [ "$VALUEVER" = "7" ]
        then
        if [ "$VALUE" = "------" ] && [ "$VALUE3" = "------" ] ; then
                VALUE=`ls -l /etc/security/opasswd`
                VALUE1=`ls -l /etc/shadow`
                VALUE3=`ls -l /var/log/tallylog`
                VALUE4="RHEL $VALUEVER<BR>ls -l /etc/security/opasswd /var/log/tallylog<BR><BR>$VALUE<BR>$VALUE3"
                status="Compliant"

        else
                VALUE=`ls -l /etc/security/opasswd`
                VALUE2=`ls -l /var/log/faillog`
                VALUE3=`ls -l /var/log/tallylog`
                VALUE4="RHEL <BR>ls -l /etc/security/opasswd /var/log/faillog /var/log/tallylog<BR><BR>$VALUE<BR>$VALUE2<BR>$VALUE3"
                status="Non-Compliant"
        fi
fi
DescItem="<BR>/etc/security/opasswd<BR>/var/log/faillog<BR>/var/log/tallylog"
Policy="<BR>The files must exist, and File permissions must be set:<BR>rw- --- --- (or more restrictive)<BR><BR>/etc/security/opasswd<BR>/var/log/faillog<BR>/var/log/tallylog<BR><BR>RHEL 6 and 7<BR>/var/log/faillog is updated to /var/log/tallylog"
DrawItem "$DescItem" "$Policy" "<BR>$VALUE4" "$status" >> $LOG_DIR/$hc

################################################################################################
# AD.2.1.7_F Login log files
# File permissions must be set:
# rwx r-x r-x (or more restrictive)

VALUE1=`ls -la /var/log/messages | cut -c6,9`
VALUE2=`ls -la /var/log/secure | cut -c6,9`
if [ "$VALUE1" = '--' ] && [ "$VALUE2" = '--' ] ; then
        VALUE1=`ls -la /var/log/messages`
        VALUE2=`ls -la /var/log/secure`
        VALUE3="Following files exist<BR><BR>ls -la /var/log/messages /var/log/secure<BR>$VALUE1<BR>$VALUE2"
    status="Compliant"
else
        if  [ "$VALUE1" != '--' ] ; then
        VALUE3="Missing File below or fix permission of below<BR>`ls -la /var/log/messages`"
        elif [ -z "$VALUE2" != '--' ]; then
        VALUE3="Missing File below or fix permission of below<BR>`ls -la /var/log/secure`"
        fi
        status="Non-Compliant"
fi

DescItem="<BR>/var/log/messages<BR>/var/log/secure"
Policy="File permissions must be set:<BR>rwx r-x r-x (or more restrictive)<BR><BR>/var/log/messages<BR>/var/log/secure"
DrawItem "$DescItem" "$Policy" "$VALUE4" "$status" >> $LOG_DIR/$hc

################################################################################################
# AD.2.1.7_G /etc/passwd /etc/shadow /etc/group
# Ownership & permission

VALUE1=`ls -la /etc/passwd | awk '{print $1}'`
VALUE2=`ls -la /etc/shadow | awk '{print $1}'`
VALUE3=`ls -la /etc/group | awk '{print $1}'`
if [ "$VALUE1" = '-rw-r--r--' ] && [ "$VALUE2" = '-r--------' ] && [ "$VALUE3" = '-rw-r--r--' ] ; then
        VALUE1=`ls -la /etc/passwd`
        VALUE2=`ls -la /etc/shadow`
        VALUE3=`ls -la /etc/group`
        VALUE="ls -la /etc/passwd /etc/shadow /etc/group<BR><BR>$VALUE1<BR>$VALUE2<BR>$VALUE3"
    status="Compliant"
else
        VALUE1=`ls -la /etc/passwd`
        VALUE2=`ls -la /etc/shadow`
        VALUE3=`ls -la /etc/group`
        VALUE="Fix the permission or ownership of below:<BR><BR>$VALUE1<BR>$VALUE2<BR>$VALUE3"
    status="Non-Compliant"
        fi

DescItem="<BR>/etc/passwd<BR>/etc/shadow<BR>/etc/group"
Policy="<BR>-rw-r--r-- (644) / belongs to root and root group<BR>-r-------- (400) / belongs to root and sys group<BR>-rw-r--r-- (644) / belongs to root and root group"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc

################################################################################################
# AD.2.1.7_F.1 /var/log/wtmp
# File permissions must be set 664 as recommended by redhat<BR>rw- rw- rÃ 664)

VALUE1=`ls -la /var/log/wtmp | cut -c9`

if [ "$VALUE1" = '-' ] ; then
        VALUE1=`ls -la /var/log/wtmp`
        VALUE="Following files exist<BR><BR>ls -la /var/log/wtmp<BR>$VALUE1"
    status="Compliant"
else
        VALUE="Missing File below or fix permission of below<BR>`ls -la /var/log/wtmp`"
        status="Non-Compliant"
fi

DescItem="<BR>/var/log/wtmp"
Policy="File permissions must be set 664 as recommended by redhat<BR>rw- rw- r--( 664)<BR><BR>/var/log/wtmp"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc

################################################################################################
# AD.2.1.7_H /etc/hosts /etc/services
# Ownership & permission

VALUE1=`ls -la /etc/hosts | awk '{print $1}'`
VALUE2=`ls -la /etc/services | awk '{print $1}'`
if [ "$VALUE1" = '-rw-r--r--' ] && [ "$VALUE2" = '-rw-r--r--' ] ; then
        VALUE1=`ls -la /etc/hosts`
        VALUE2=`ls -la /etc/services`
        VALUE="ls -la /etc/hosts /etc/services<BR><BR>$VALUE1<BR>$VALUE2"
    status="Compliant"
else
        VALUE1=`ls -la /etc/hosts`
        VALUE2=`ls -la /etc/services`
        VALUE="Fix the permission or ownership of below:<BR><BR>$VALUE1<BR>$VALUE2"
    status="Non-Compliant"
        fi

DescItem="<BR>/etc/hosts<BR>/etc/services"
Policy="<BR>Permission should be 644<BR><BR>-rw-r--r-- (644) /etc/hosts<BR>-rw-r--r-- (644) /etc/services"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc


################################################################################################
# AD.2.1.7_I /etc/profile TIMEOUT value


PROFTMOUT=`cat /etc/profile | grep -v grep |egrep 'TMOUT|TIMEOUT|readonly' | wc -l`
TMOUT=`cat /etc/profile | grep '^TMOUT'  | cut -f2 -d'='`
TIMEOUT=`cat /etc/profile | grep '^TIMEOUT' | cut -f2 -d'='`

if [ "$PROFTMOUT" = "4" ];      then
        if [ "$TMOUT" = "600" ];        then
                if [ "$TIMEOUT" = "600" ];      then
                        status="Compliant"
                        VALUE="TMOUT set to $TMOUT<BR>TIMEOUT set to $TIMEOUT"
                else
                        status="Non-Compliant"
                        VALUE="TMOUT set to $TMOUT<BR>TIMEOUT set to $TIMEOUT"
                fi
        else
                status="Non-Compliant"
                VALUE="TMOUT set to $TMOUT<BR>TIMEOUT set to $TIMEOUT"
        fi
else
        status="Non-Compliant"
        VALUE="Timeout not set properly.<BR>TMOUT set to $TMOUT<BR>TIMEOUT set to $TIMEOUT"
fi
DescItem="/etc/profile TIMEOUT value"
Policy="Define a timeout value in /etc/profile for all users.<BR>
Edit /etc/profile and add/update the following &#58;<BR>
TMOUT=600       (for Korn Shell)<BR>
TIMEOUT=600     (for Borne Shell)<BR>
export  TIMEOUT  TMOUT<BR>
readonly TIMEOUT TMOUT<BR>"
DrawItem "$DescItem" "$Policy" "$VALUE" "$status" >> $LOG_DIR/$hc


################################################################################################
# AD.2.1.7_H /etc/inittab /var/spool/cron/root /etc/crontab /etc/xinetd.conf /etc/cron.d/
# Ownership & permission

VALUEVER=`cat /etc/redhat-release | cut -d " " -f7|cut -c1`
VALUE=`ls -l /etc/inittab | cut -c1-10`
VALUE2=`ls -l /var/spool/cron/root | cut -c1-10`
VALUE3=`ls -l /etc/crontab | cut -c1-10`
VALUE4=`ls -ld /etc/cron.d | cut -c1-10`
VALUE5=`ls -l /etc/xinetd.conf  | cut -c1-10`

if [ "$VALUEVER" = "5" ]
        then
        if [ "$VALUE" = "-rw-r--r--" ] && [ "$VALUE2" = "-rw-------" ] && [ "$VALUE3" = "-rw-r--r--" ] && [ "$VALUE4" = "drwxr-xr-x" ] && [ "$VALUE5" = "-rw-r--r--" ] ; then
                VALUE=`ls -l /etc/inittab`
                                VALUE2=`ls -l /var/spool/cron/root`
                                VALUE3=`ls -l /etc/crontab`
                                VALUE4=`ls -ld /etc/cron.d`
                                VALUE5=`ls -l /etc/xinetd.conf`
                VALUE4="RHEL 5<BR>ls -ld /etc/inittab /var/spool/cron/root /etc/crontab /etc/cron.d/ /etc/xinetd.conf <BR><BR>$VALUE<BR>$VALUE2<BR>$VALUE3<BR>$VALUE4<BR>$VALUE5"
                status="Compliant"

        else
                VALUE=`ls -l /etc/inittab`
                                VALUE2=`ls -l /var/spool/cron/root`
                                VALUE3=`ls -l /etc/crontab`
                                VALUE4=`ls -ld /etc/cron.d`
                                VALUE5=`ls -l /etc/xinetd.conf`
                VALUE4="RHEL 5<BR>ls -ld /etc/inittab /var/spool/cron/root /etc/crontab /etc/cron.d/ /etc/xinetd.conf <BR><BR>$VALUE<BR>$VALUE2<BR>$VALUE3<BR>$VALUE4<BR>$VALUE5"
                status="Non-Compliant"
        fi
elif [ "$VALUEVER" = "6" ] || [ "$VALUEVER" = "7" ]
        then
        if [ "$VALUE" = "-rw-r--r--" ] && [ "$VALUE2" = "-rw-------" ] && [ "$VALUE3" = "-rw-r--r--" ] && [ "$VALUE4" = "drwxr-xr-x" ] ; then
                 VALUE=`ls -l /etc/inittab`
                                VALUE2=`ls -l /var/spool/cron/root`
                                VALUE3=`ls -l /etc/crontab`
                                VALUE4=`ls -ld /etc/cron.d`

                VALUE4="RHEL 5<BR>ls -ld /etc/inittab /var/spool/cron/root /etc/crontab /etc/cron.d/ <BR><BR>$VALUE<BR>$VALUE2<BR>$VALUE3<BR>$VALUE4"
                status="Compliant"

        else
                VALUE=`ls -l /etc/inittab`
                                VALUE2=`ls -l /var/spool/cron/root`
                                VALUE3=`ls -l /etc/crontab`
                                VALUE4=`ls -ld /etc/cron.d`

                VALUE4="RHEL $VALUEVER<BR>ls -ld /etc/inittab /var/spool/cron/root /etc/crontab /etc/cron.d/ <BR><BR>$VALUE<BR>$VALUE2<BR>$VALUE3<BR>$VALUE4"
                status="Non-Compliant"
        fi
fi
DescItem="<BR>/etc/inittab<BR>
/var/spool/cron/root<BR>
/etc/crontab<BR>
/etc/xinetd.conf<BR>
/etc/cron.d/ directory structure.
"
Policy="
-rw-r--r-- (644) /etc/inittab<BR>
-rw------- (600) /var/spool/cron/root<BR>
-rw-r--r-- (644) /etc/crontab<BR>
drwxr-xr-x (755) /etc/cron.d/<BR>
-rw-r--r-- (644) /etc/xinetd.conf &#40;For RHEL5&#41;
"
DrawItem "$DescItem" "$Policy" "$VALUE4" "$status" >> $LOG_DIR/$hc





################################################################################################
# AD.1.2.19 Business Use Notice
#

echo "<tr><td bgcolor="#C0C0C0" colspan=4><br><b>2.1.8) Business Use Notice</b></td></tr>" >> $LOG_DIR/$hc

VALUE01=`sed -n 1p /etc/motd`
VALUE02=`sed -n 2p /etc/motd`
VALUE03=`sed -n 3p /etc/motd`
VALUE04=`sed -n 4p /etc/motd`
VALUE05=`sed -n 5p /etc/motd`
VALUE06=`sed -n 6p /etc/motd`
VALUE07=`sed -n 7p /etc/motd`
VALUE08=`sed -n 8p /etc/motd`
VALUE09=`sed -n 9p /etc/motd`
VALUE10=`sed -n 10p /etc/motd`
VALUE11=`sed -n 11p /etc/motd`
VALUE12=`sed -n 12p /etc/motd`
VALUE13=`sed -n 13p /etc/motd`
VALUE14=`sed -n 14p /etc/motd`
VALUE15=`sed -n 15p /etc/motd`
VALUE16=`sed -n 16p /etc/motd`
if (   grep -q "This system is for the use of authorized users only." /etc/motd &&
       grep -q "Individuals using this computer system without authority, or in" /etc/motd &&
       grep -q "excess of their authority, are subject to having all of their" /etc/motd &&
       grep -q "activities on this system monitored and recorded by system" /etc/motd &&
       grep -q "personnel." /etc/motd &&
       grep -q "In the course of monitoring individuals improperly using this" /etc/motd &&
       grep -q "system, or in the course of system maintenance, the activities" /etc/motd &&
       grep -q "of authorized users may also be monitored." /etc/motd &&
       grep -q "Anyone using this system expressly consents to such monitoring" /etc/motd &&
       grep -q "and is advised that if such monitoring reveals possible" /etc/motd &&
       grep -q "evidence of criminal activity, system personnel may provide the" /etc/motd &&
       grep -q "evidence of such monitoring to law enforcement officials" /etc/motd)
then status="Compliant"
VALUE=`cat /etc/motd > $LOG_DIR/motd`
while read -r line;do echo "<br />$line" >> $LOG_DIR/output2 ; done < $LOG_DIR/motd

else
        status="Non-Compliant"
        VALUE="cat /etc/motd<BR><BR>entry not found"
fi

DescItem="Business Use Notice"
Policy17=""
Policy01="###################################################################"
Policy02="# This system is for the use of authorized users only.            #"
Policy03="# Individuals using this computer system without authority, or in #"
Policy04="# excess of their authority, are subject to having all of their   #"
Policy05="# activities on this system monitored and recorded by system      #"
Policy06="# personnel.                                                      #"
Policy07="#                                                                 #"
Policy08="# In the course of monitoring individuals improperly using this   #"
Policy09="# system, or in the course of system maintenance, the activities  #"
Policy10="# of authorized users may also be monitored.                      #"
Policy11="#                                                                 #"
Policy12="# Anyone using this system expressly consents to such monitoring  #"
Policy13="# and is advised that if such monitoring reveals possible         #"
Policy14="# evidence of criminal activity, system personnel may provide the #"
Policy15="# evidence of such monitoring to law enforcement officials.       #"
Policy16="###################################################################"
DrawItem "$DescItem" "$Policy17<BR>$Policy01<BR>$Policy02<BR>$Policy03<BR>$Policy04<BR>$Policy05<BR>$Policy06<BR>$Policy07<BR>$Policy08<BR>$Policy09<BR>$Policy10<BR>$Policy11<BR>$Policy12<BR>$Policy13<BR>$Policy14<BR>$Policy15<BR>$Policy16" "`cat $LOG_DIR/output2` " "$status" >> $LOG_DIR/$hc
rm -rf $LOG_DIR/output2

###############################################################################################
DrawHtmlFileHead "OTHER_SETTINGS"
echo "<tr><td colspan=4><br><b>AD.3 Other Settings - For inventory purposes</b> </td></tr>" >> $LOG_DIR/$hc

DrawHtmlFileHead "HEALTHCHECK"
echo "<tr><td colspan=4><br><b>AD.4 Health Check</b> </td></tr>" >> $LOG_DIR/$hc
echo "<tr><td colspan=4><br>Health Check must be done 100% compliant base on the approved ISCD-IM. </td></tr>" >> $LOG_DIR/$hc
DrawHtmlFileHead "PROCESSCONTROL"
echo "<tr><td colspan=4><br><b>AD.5 Process Control</b> </td></tr>" >> $LOG_DIR/$hc
DrawHtmlFileHead "AD.5 Process Control"

################################################################################################
# AD.4 Process Exception
DrawHtmlFileHead "EXEPTION"
echo "<tr><td colspan=4><br><b>AD.6 Process Exception</b> </td></tr>" >> $LOG_DIR/$hc
echo "<tr><td colspan=4><br>IM setting which has more stringent value implemented is acceptable and no longer require to submit, or seek a deviation approval.</td></tr>" >> $LOG_DIR/$hc

item="Protecting Resources - OSR's"
exeption="Default system generated files of the following file types will contain world writeable and Orphan Files:<BR>socket (s)<BR>named pipe (p)<BR>block special file (b)<BR>character special file (c)<BR>symbolic links (l)<BR><BR>Ignore Orphan Files and world writeable files for these system generated directories and application.<BR>/dev/shm<BR>/proc<BR>/sys<BR>/var/foglight<BR>/var/core/murex"

DrawPE "$item" "$exeption" >> $LOG_DIR/$hc

DrawHtmlFileHead "CLUSTECH"
DrawPERptHead "Required settings for Linux Clustech compute nodes -- SSH" >> $LOG_DIR/$hc
ReqItem="<b>PermitRootLogin</b>"
DescItem="Yes"
ISCDItem="Due to the nature of cluster computing - large number of identical servers in the environment, it is impossible to individually log in to the servers to administer one at a time.<BR><BR>All administrations of the compute nodes are done via management node , which requires PermitRoot Login in SSH and no 2FA required."
TestItem="All password login, including root account, are disallowed in all Compute Nodes. Root password removed.<BR><BR>Root log in to these compute nodes are based on key-exchange via the management node, which in turn, is hardened and auth by 2FA Vasco.<BR>
<BR>Host-based access control has also been implemented to restrict access<BR>
<BR>Restrict access to compute node via same VLAN<BR>"
DrawItem "$ReqItem" "$DescItem" "$ISCDItem" "$TestItem"



################################################################################################
# AD.5 Document Control
DrawHtmlFileHead "DOCCONTROL1"
DrawDCRpt1Head "AD.7 Document Control"
DrawHtmlFileHead "DOCCONTROL"
DrawDCRptHead

DrawControl "January 2014" "Foong wai , Richard Tan , Dexter Gerada, Guru J Dhinahar Raj , Argie Arizala Boquilon, Mun Siong Voon" "<b>IM 4.0 Released</b>"
DrawControl "May 2014" "Richard Tan ,  Nam Cheong , Guru J Dhinahar Raj , Argie Arizala Boquilon, Ashok Kumar , Mun  Siong Voon" "<b>2.1.1) Logging</b><BR>Add in File : /etc/rsyslog.conf for RHEL 6.x and above<BR><BR><b>2.1.6) Other Settings</b><BR> Reviewed and agreed Turn off ICMP broadcasts , setting in /etc/sysctl.conf<BR>net.ipv4.icmp_echo_ignore_broadcasts = 1<BR><BR><b>2.1.2) System Settings</b><BR>Group ID check<BR>Edit the file /etc/securetty to contain only 'console' and 'tty'.<BR><BR><b>2.1.7) Protecting Resources - OSRs</b><BR>/var/log/wtmp set permission to 664 as per recommend  by Redhat.com<BR>To allow system group ( sys , bin , utmp ) write  system event log to system.<BR><BR>User's home directory /home/<userid>:<BR>Default permission: 755. Must be owned by the userid. Others<BR>may be given execute authority on the directory to allow traversal to public web pages."
DrawControl "February 2017" "Richard Tan , Sandeep Arora, Argie Boquilon" "IM 5.0 Released"

rm -rf $LOG_DIR/motd
rm -rf $LOG_DIR/output
echo "<tr><td colspan=4><BR><b>Check Ended at: `date` </b></td></tr>" >> $LOG_DIR/$hc
echo "</table>" >> $LOG_DIR/$hc
echo " "
echo " "
echo -e "\033[7mReport completed and save on $hc\033[0m"