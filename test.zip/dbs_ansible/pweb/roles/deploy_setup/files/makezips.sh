!/bin/bash
baseDir=$1
origin=$(pwd)
cd $baseDir/

zip -r Teamsite.zip Teamsite/
rm -rf Teamsite/

zip -r LSDS.zip LSDS/
rm -rf LSDS/

zip -r Web.zip Web/
rm -rf Web/

cd $origin
