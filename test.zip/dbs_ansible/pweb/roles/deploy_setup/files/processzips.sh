#!/bin/bash
baseDir=$1
origin=$(pwd)
cd $baseDir/

#Teamsite
rm -rf Teamsite/
rm -rf *_src/
rm Teamsite.zip
mkdir Teamsite
for z in *Teamsite*.zip
  do 
    unzip $z; 
  done;
for z in *_src*/
  do 
    yes|cp -rf $z* Teamsite/;
  done;
#zip -r Teamsite.zip Teamsite/
rm -rf *_src/
#rm -rf Teamsite/

#LSDS
rm -rf LSDS/
rm -rf *_src/
rm LSDS.zip
mkdir LSDS
for z in *LSDS*.zip
  do 
    unzip $z; 
  done;
for z in *_src*/
  do 
    yes|cp -rf $z* LSDS/;
  done;
#zip -r LSDS.zip LSDS/
rm -rf *_src/
#rm -rf LSDS/

#Web
rm -rf Web/
rm -rf *_src/
rm Web.zip
mkdir Web
for z in *Web*.zip
  do 
    unzip $z; 
  done;
for z in *_src*/
  do 
    yes|cp -rf $z* Web/;
  done;
#zip -r Web.zip Web/
rm -rf *_src/
#rm -rf Web/

cd $origin


