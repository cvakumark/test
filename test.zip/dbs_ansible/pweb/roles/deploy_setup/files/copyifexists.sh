#!/bin/bash

src=$1
dest=$2

if [[ -d $src ]]; then
    if [[ $dest == *".ear"* ]]; then
        if [[ -d "$dest" ]]; then
            echo "ear dir. Exists"
            cp -r $src/* "$dest"
        else
            echo "ear dir. Doesn't exist. Stop"
        fi
    else
        if [[ -d "$dest" ]]; then
            echo "target directory exists"
        else
            mkdir --parents $dest
            echo "Made directory with parents"
        fi
        cp -r $src/* "$dest"
    fi
fi
