#!/bin/bash
volumename=$1
instanceId=`curl http://169.254.169.254/latest/meta-data/instance-id`
#echo $instanceId
logincommand=`/usr/local/bin/softnas-cmd login softnas $instanceId --base_url https://localhost/softnas --pretty_print`
#echo $logincommand
snapshot_create=`/usr/local/bin/softnas-cmd snapcommand create pool_name=pool1 volume_name=$volumename`
echo $snapshot_create >> /tmp/tempsnapname.txt
snapshotname=`cat /tmp/tempsnapname.txt | cut -d "'" -f2`
echo $snapshotname