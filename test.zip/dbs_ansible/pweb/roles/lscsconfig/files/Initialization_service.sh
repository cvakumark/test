#!/bin/bash

JBOSS_USER=$1

#restart OD server if running
if [ -e /etc/init.d/iwodserver ]; then
    su $JBOSS_USER - /etc/init.d/iwodserver stop
    sleep 2
    su $JBOSS_USER - /etc/init.d/iwodserver start
 fi

sleep 5

#restart DIH service
if [ -e /etc/systemd/system/iwlscsdih.service ]; then
    systemctl stop iwlscsdih.service
    sleep 2
    systemctl start iwlscsdih.service
fi

sleep 5

if [ -e /etc/systemd/system/iwlscscontent.service ]; then
    systemctl stop iwlscscontent.service
    sleep 2
    systemctl start iwlscscontent.service
fi
