#!/bin/bash

#load the env variables
source /pwebcma/scripts/lscsenv.properties

#get instance id
instanceId=$(curl --silent "http://169.254.169.254/latest/meta-data/instance-id")

#remove ping file
`rm -f $jboss_eap_app_base_dir/$jboss_app_name_lscs/deployments/lscs.war/ping.html`

#configure dih
xmlRemoveStatus=$(curl --silent "http://${masterHostname}:8080/lscs/admin/Util.jsp?action=REMOVE&instId=${instanceId}")

#Restart dih master
xmlDIHStart=($(curl --silent "http://${masterHostname}:16001/action=Restart"))
