#!/bin/bash

ACTION=$1
cd /etc/init.d/

case "$1" in
start)
        ./iwlscsdih start
        ;;
stop)
        ./iwlscsdih stop
        ;;
restart)
        ./iwlscsdih stop
        sleep 10
        ./iwlscsdih start
        ;;
*)
        echo "Usage: $0 {start|stop|restart}"
        exit 2
esac
