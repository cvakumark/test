#!/bin/bash

#load the env variables
source /pwebcma/scripts/lscsenv.properties

#pid
pid=$$
idxExpName="expdih${pid}"

#get instance id
instanceId=$(curl --silent "http://169.254.169.254/latest/meta-data/instance-id")

#get slave hostname
slaveHostname=$(curl --silent "http://169.254.169.254/latest/meta-data/local-hostname")


#get master idol config
xmlIdolConfig=$(curl --silent "http://${masterHostname}:10012/action=GetConfig");
result=$(grep -oPm1 "(?<=<RESPONSE>)[^<]+" <<< "$xmlIdolConfig");
idolConfig=${xmlIdolConfig#<ACTION>GETCONFIG</ACTION><RESPONSE>*</RESPONSE><RESPONSEDATA>}
idolConfig=${idolConfig%</RESPONSEDATA>}

# Stop jboss
service $jboss_service_name stop 

sleep 2

#stop idol
service iwlscscontent stop

sleep 6

#backup and update
`cp -p /pwebcma/LiveSiteCSRT/idol/IWLSCSContent.cfg /pwebcma/LiveSiteCSRT/idol/IWLSCSContent.bak`
echo "${idolConfig}" >/pwebcma/LiveSiteCSRT/idol/IWLSCSContent.cfg

#start idol
service iwlscscontent start


sleep 2

# start jboss
service $jboss_service_name start 

sleep 2

#stop dih master
xmlDIH=($(curl --silent "http://${masterHostname}:16001/action=Stop"))

#idxexport in softnas
idxexport_dir=$nas_mnt_lscs'/idxexport'
if [ ! -d "$idxexport_dir" ]; then
  	mkdir -m 755 -p $nas_mnt_lscs/idxexport
fi

#export idx
xmlExport=($(curl --silent "http://${masterHostname}:10011/DREEXPORTIDX?FileName=${nas_mnt_lscs}/idxexport/${idxExpName}&Compress=true&BatchSize=100000"))
xmlExpId=${xmlExport#*=}

#check export index status
expStatus="0"
expCount="0"

while [ $expStatus -ne -1 ]
do
xmlExpStatus=$(curl --silent "http://${masterHostname}:8080/lscs/v1/util-command/idolpt?action=IndexerGetStatus&Index=${xmlExpId}")
expResult=$(grep -oPm1 "(?<=<status>)[^<]+" <<< "$xmlExpStatus");
expStatus=$(( expResult ))
expCount=$(( expCount+1 ))
if [ $expCount -eq 10 ]; then
expStatus="-1"
fi
sleep 2
done

#check import index status
impStatus="0"
impCount="0"
xmlImportId=""

#import idx
idxFiles=($(find "${nas_mnt_lscs}/idxexport" -type f -name "${idxExpName}-*.idx.gz"))
for idx in ${idxFiles[@]}
do
urlImport="http://${slaveHostname}:10011/DREADD?FileName=${idx}&Delete=true";
xmlImport=$(curl --silent "${urlImport}");
xmlImportId=${xmlImport#*=}
done

while [ $impStatus -ne -1 ]
do
xmlImpStatus=$(curl --silent "http://${slaveHostname}:8080/lscs/v1/util-command/idolpt?action=IndexerGetStatus&Index=${xmlImportId}")
impResult=$(grep -oPm1 "(?<=<status>)[^<]+" <<< "$xmlImpStatus");
impStatus=$(( impResult ))
impCount=$(( impCount+1 ))
if [ $impCount -eq 10 ]; then
impStatus="-1"
fi
sleep 2
done

#touch ping file
`touch $jboss_eap_app_base_dir/$jboss_app_name_lscs/deployments/lscs.war/ping.html`

#configure dih
xmlAddStatus=$(curl --silent "http://${masterHostname}:8080/lscs/admin/Util.jsp?action=ADD&instId=${instanceId}")
