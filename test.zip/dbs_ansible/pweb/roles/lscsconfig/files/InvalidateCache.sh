#!/bin/bash

#load the env variables
source /pwebcma/scripts/lscsenv.properties

# group name loaded from env properties
group_name=$asg_name

STDIN=$(cat -)

grep_cache_file=$(grep -oPm1 "(?<=<item path=\")(sites/)?(cache\.)[^\"]+" <<< "$STDIN");
grep_cache_dir=$(grep -oPm1 "(?<=trgDir=\")[^\"]+" <<< "$STDIN");
grep_cache_path="${grep_cache_dir}/${grep_cache_file}"
cache_base="${grep_cache_path%/*}"
cache_name="${grep_cache_path##*/}"
cache_path="${cache_base}/${cache_name}"

[[ !  -z  $cache_name  ]] && echo $cache_path >>./dnr.log

if [[ $cache_path == *"SG.ear"* ]]; then
        port=$sg_port
elif [[ $cache_path == *"SGPOSB.ear"* ]]; then
        port=$posb_port
else
        port='8080'
fi

export HTTPS_PROXY=$https_proxy_url

if [ -f $cache_path ];
then

instances=($(${aws_cli} autoscaling describe-auto-scaling-groups --auto-scaling-group-name $group_name --region $region --query AutoScalingGroups[].Instances[].InstanceId --output text))

ipaddress=($(${aws_cli} ec2 describe-instances --instance-ids ${instances[@]} --region $region --query Reservations[].Instances[].PrivateIpAddress --output text))

for IP in ${ipaddress[@]};
do
url="http://$IP:${port}/iw/admin/Cache.jsp?action=COPY&cacheName=${cache_name}";
echo "$url " >>./dnr.log
xml=$(curl -k --silent "${url}");
result=$(grep -oPm1 "(?<=<result>)[^<]+" <<< "$xml");

echo ": $result" >>./dnr.log
done
fi

if [ -f $cache_path ];
then
   echo "File $cache_path exists."
   rm -f "$cache_path"
fi

exit
