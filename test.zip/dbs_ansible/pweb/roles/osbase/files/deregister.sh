#!/bin/bash

config=/etc/info.dbs

# copy user data to file
if [ -f /root/config ]; then
   cat /root/config > $config
else
   curl http://169.254.169.254/latest/user-data > $config
fi
echo >> $config

HOSTNAME=`hostname`
HOSTED_ZONE_ID=`grep "^HOSTED_ZONE_ID=" $config | awk -F"=" '{print $2}'`
PRIVATEIP=`hostname -i`

## Puppet master cert cleanup
logger "[PWEB: Bootstrap] Cleaning up puppet master certs for hostname $hostname"
curl --connect-timeout 60 --max-time 30  http://10.114.2.18/bin/postcleanup_pweb.sh?$hostname
logger "[PWEB: Bootstrap] waiting 10sec for puppet master cert cleanup"
sleep 10

# Deregistring Route 53
logger "[PWEB: Bootstrap] removing route 53 entry"
RECORDSET=$HOSTNAME.
TTL=300
COMMENT="Update R53 for Deployment Server"
TYPE="A"
TMPFILE=$(mktemp /tmp/temporary-ip.XXXXXX)
cat > ${TMPFILE} << EOF
{
    "Comment": "$COMMENT",
    "Changes": [{
        "Action": "DELETE",
        "ResourceRecordSet": {
            "ResourceRecords": [{
                "Value": "$PRIVATEIP"
            }],
            "Name": "$RECORDSET",
            "Type": "$TYPE",
            "TTL": $TTL
        }
    }]
}
EOF
aws route53 change-resource-record-sets --hosted-zone-id $HOSTED_ZONE_ID --change-batch file://"$TMPFILE"
rm -rf $TMPFILE

sleep 10